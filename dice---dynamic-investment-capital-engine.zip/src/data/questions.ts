/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 20 Comprehensive DICE Investor Profiling Questions
 * Grounded in NISM Series V-A (Chapter 1, 10, 12) & DICE Project Master Document
 */

import { Question } from '../types';

export const DICE_QUESTIONS: Question[] = [
  {
    id: 1,
    title: 'Primary Goal & Investment Horizon',
    category: 'Context & Holdings',
    question: 'What is the primary financial goal for this capital, and by when will you need it?',
    explanationWhyAsked: 'NISM Ch 1.1 dictates "Start with Why": Scheme suitability is driven first by goal horizon and purpose rather than chasing random market returns.',
    behaviouralConcept: 'Mental Accounting & Goal Anchoring',
    holdingAspect: 'Separates core long-term capital from short-term liquidity pools to prevent premature liquidation.',
    options: [
      {
        id: 'q1_a',
        label: 'Short-term emergency or parking cash (Under 1 year)',
        subtext: 'Need absolute capital safety and zero lock-in',
        scoreImpact: { riskCapacity: -2, riskWillingness: -2, horizonYears: 1, liquidityNeed: 'High' },
        holdingInsight: 'Holding capital in volatile equity or high-duration debt exposes short-term funds to market timing loss.',
        aiGuidance: 'The DICE Engine strictly routes sub-1-year goals to Liquid, Overnight, or Ultra Short Duration debt funds to protect principal.'
      },
      {
        id: 'q1_b',
        label: 'Medium-term goal (2 to 4 years, e.g. down payment or car)',
        subtext: 'Seeking moderate growth without extreme drawdowns',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0, horizonYears: 3, liquidityNeed: 'Moderate' },
        holdingInsight: 'Pure equity runs market-cycle risk over 2-4 years; balanced hybrid or short-duration debt preserves capital better.',
        aiGuidance: 'DICE suitability prioritizes Conservative Hybrid, Balanced Advantage, or Short Duration Debt where duration matches your horizon.'
      },
      {
        id: 'q1_c',
        label: 'Long-term wealth creation (5 to 9 years, e.g. child education)',
        subtext: 'Can withstand intermediate market cycles for inflation-beating growth',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1, horizonYears: 7, liquidityNeed: 'Low' },
        holdingInsight: 'Long holding periods allow equity compounding to smooth out short-term market volatility.',
        aiGuidance: 'DICE Engine identifies Diversified Equity (Flexi Cap / Large & Mid Cap) as suitable core portfolio anchors.'
      },
      {
        id: 'q1_d',
        label: 'Very long-term / Retirement (10+ years)',
        subtext: 'Maximizing compounding power across multiple market cycles',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2, horizonYears: 12, liquidityNeed: 'Low' },
        holdingInsight: 'Sensex historical compounding of ~15.4% p.a. proves equity is required to beat long-term inflation.',
        aiGuidance: 'DICE assigns highest equity allocation potential (Flexi Cap, Mid Cap, Multi Cap) with systematic rebalancing rules.'
      }
    ]
  },
  {
    id: 2,
    title: 'Emergency Buffer & Cash Reserves',
    category: 'Context & Holdings',
    question: 'How many months of committed living expenses do you currently hold in liquid bank accounts or FDs?',
    explanationWhyAsked: 'Having no emergency buffer forces investors to liquidate equities at market troughs during unforeseen personal shocks.',
    behaviouralConcept: 'Liquidity Panic & Forced Capitulation',
    holdingAspect: 'Assesses unencumbered cash buffer before deploying surplus into market-linked instruments.',
    options: [
      {
        id: 'q2_a',
        label: 'Less than 1 month or no dedicated emergency fund',
        subtext: 'Living paycheck to paycheck or fully committed',
        scoreImpact: { riskCapacity: -2, riskWillingness: -1, liquidityNeed: 'High', behavioralBiasDetected: 'Hyperbolic Discounting' },
        holdingInsight: 'Without an emergency reserve, even a minor expense will force you to break investments or take expensive loans.',
        aiGuidance: 'DICE Engine flags high liquidity risk. Priority must be creating a 3-6 month liquid fund buffer before high-risk equity.'
      },
      {
        id: 'q2_b',
        label: '1 to 3 months of expenses saved',
        subtext: 'Basic buffer, but vulnerable to extended disruption',
        scoreImpact: { riskCapacity: -1, riskWillingness: 0, liquidityNeed: 'Moderate' },
        holdingInsight: 'Partial buffer exists, but sudden shocks could still spill into your investment portfolio.',
        aiGuidance: 'DICE recommends a balanced hybrid strategy with partial liquid allocation to buffer emergencies.'
      },
      {
        id: 'q2_c',
        label: '3 to 6 months of expenses in safe deposits',
        subtext: 'Healthy emergency reserve as recommended by financial planners',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1, liquidityNeed: 'Low' },
        holdingInsight: 'Standard recommended safety net. Insulates your investments from forced premature redemption.',
        aiGuidance: 'DICE Engine unlocks full core equity allocation since emergency liquidity needs are comfortably secured.'
      },
      {
        id: 'q2_d',
        label: 'Over 6 months to 1 year+ of expenses in liquid savings',
        subtext: 'Substantial liquidity buffer with zero debt pressure',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1, liquidityNeed: 'Low', behavioralBiasDetected: 'Cash Drag / Loss Aversion' },
        holdingInsight: 'High cash holdings offer total safety but suffer from inflation risk where purchasing power declines over time.',
        aiGuidance: 'DICE indicates strong risk capacity to deploy excess idle cash into inflation-beating mutual fund assets.'
      }
    ]
  },
  {
    id: 3,
    title: 'Current Asset Holdings Distribution',
    category: 'Context & Holdings',
    question: 'Where is the majority of your existing accumulated wealth currently stored?',
    explanationWhyAsked: 'Identifies portfolio skew and Familiarity Bias—many investors overweight physical assets like gold or self-occupied real estate without realizing liquidity drags.',
    behaviouralConcept: 'Familiarity Bias & Mental Partitioning',
    holdingAspect: 'Measures existing asset class weights across Fixed Income, Equity, Real Estate, and Gold.',
    options: [
      {
        id: 'q3_a',
        label: 'Mainly Bank Savings, Fixed Deposits (FDs), PPF, or Post Office schemes',
        subtext: 'Over 70% in guaranteed fixed income products',
        scoreImpact: { riskCapacity: 0, riskWillingness: -2, behavioralBiasDetected: 'Familiarity Bias (Safe Assets)' },
        holdingInsight: 'Post-tax fixed income returns often fail to beat real inflation (6-8%), leading to stealth erosion of wealth.',
        aiGuidance: 'DICE will introduce you to conservative/balanced hybrid schemes to gradually build equity comfort without high volatility shock.'
      },
      {
        id: 'q3_b',
        label: 'Heavily locked in Physical Real Estate (land, rental, or family home)',
        subtext: 'Over 60% in property and immovable assets',
        scoreImpact: { riskCapacity: 1, riskWillingness: 0, behavioralBiasDetected: 'Illiquidity Illusion' },
        holdingInsight: 'Real estate is indivisible, illiquid, has high stamp duty/brokerage, and self-occupied homes are lifestyle expenses, not investments.',
        aiGuidance: 'DICE Engine recommends liquid financial mutual fund assets to provide portfolio divisibility and rapid liquidity.'
      },
      {
        id: 'q3_c',
        label: 'A balanced mix of Mutual Funds, Stocks, FDs, and Gold',
        subtext: 'Diversified across multiple financial categories',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'A diversified holding structure reduces unsystematic risk and protects against single-asset downturns.',
        aiGuidance: 'DICE Engine can optimize tactical or core-satellite scheme selection to enhance risk-adjusted alpha.'
      },
      {
        id: 'q3_d',
        label: 'Predominantly direct stocks, crypto, or trading positions',
        subtext: 'High concentration in volatile or speculative assets',
        scoreImpact: { riskCapacity: 0, riskWillingness: 2, behavioralBiasDetected: 'Overconfidence / Concentration Risk' },
        holdingInsight: 'High portfolio concentration in individual equities magnifies company-specific risk which can be diversified away.',
        aiGuidance: 'DICE Engine will recommend disciplined, professionally managed diversified equity funds with strict single-stock limits.'
      }
    ]
  },
  {
    id: 4,
    title: 'Monthly Savings Rate & Investible Surplus',
    category: 'Context & Holdings',
    question: 'What percentage of your regular monthly income remains as free investible surplus after expenses and EMIs?',
    explanationWhyAsked: 'Determines financial capability to sustain recurring Systematic Investment Plans (SIPs) across economic cycles.',
    behaviouralConcept: 'Cash Flow Discipline vs Over-Commitment',
    holdingAspect: 'Evaluates the stability and size of periodic capital inflows.',
    options: [
      {
        id: 'q4_a',
        label: 'Under 10% of monthly income',
        subtext: 'Tight monthly cash flow with high fixed overheads',
        scoreImpact: { riskCapacity: -2, riskWillingness: -1 },
        holdingInsight: 'A low margin of safety makes large SIP commitments risky; missing SIP debits can lead to bank bounce charges.',
        aiGuidance: 'DICE suggests starting with modest SIPs or Micro-SIPs (up to Rs 50,000 p.a. PAN-exempt category) to build investing habit.'
      },
      {
        id: 'q4_b',
        label: '10% to 25% of monthly income',
        subtext: 'Moderate recurring surplus available regularly',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0 },
        holdingInsight: 'Sufficient buffer to fund consistent monthly SIPs without impacting daily lifestyle.',
        aiGuidance: 'DICE recommends steady monthly SIPs with an annual SIP Top-Up facility of 5-10%.'
      },
      {
        id: 'q4_c',
        label: '25% to 50% of monthly income',
        subtext: 'Strong savings habit with significant wealth creation power',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'High savings rate substantially accelerates reaching financial goals and absorbs market shocks.',
        aiGuidance: 'DICE Engine allocates higher weight to wealth-builder equity schemes and suggests multi-asset allocation.'
      },
      {
        id: 'q4_d',
        label: 'Over 50% of monthly income',
        subtext: 'Exceptional surplus, low personal liabilities',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2 },
        holdingInsight: 'Significant investible surplus provides high risk capacity to take calculated long-term equity exposure.',
        aiGuidance: 'DICE scores flexi-cap, large & mid-cap, and strategic growth schemes highly for aggressive compounding.'
      }
    ]
  },
  {
    id: 5,
    title: 'Emotional Reaction to a 20% Market Crash',
    category: 'Behavioral Biases',
    question: 'If the stock market falls 20% in 3 months and your Rs 5 Lakh investment drops to Rs 4 Lakh, what is your first impulse?',
    explanationWhyAsked: 'Kahneman & Tversky discovered Loss Aversion: the pain of losing Rs 1 is psychologically twice as intense as the joy of gaining Rs 1.',
    behaviouralConcept: 'Loss Aversion Bias (Kahneman & Tversky Nobel Prize insight, NISM Ch 1.6)',
    holdingAspect: 'Exposes risk of selling at the bottom, permanently turning paper losses into realized capital loss.',
    options: [
      {
        id: 'q5_a',
        label: 'Panic and redeem everything immediately to stop further bleeding',
        subtext: 'Cannot sleep peacefully with portfolio in the red',
        scoreImpact: { riskCapacity: 0, riskWillingness: -2, behavioralBiasDetected: 'Extreme Loss Aversion' },
        holdingInsight: 'Exiting during a drawdown crystallizes temporary mark-to-market fluctuations into irreversible cash losses.',
        aiGuidance: 'DICE will exclude high-volatility pure equity funds and recommend Conservative Hybrid or Arbitrage schemes with steady NAVs.'
      },
      {
        id: 'q5_b',
        label: 'Feel anxious, pause my ongoing investments and wait for recovery',
        subtext: 'Wary of adding more until market turns green again',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1, behavioralBiasDetected: 'Omission Bias / Inertia' },
        holdingInsight: 'Pausing investments during market dips defeats Rupee Cost Averaging, where you get more units at lower NAVs.',
        aiGuidance: 'DICE pairs you with Balanced Advantage or Multi-Asset schemes that dynamically reduce equity allocation automatically.'
      },
      {
        id: 'q5_c',
        label: 'Stay calm, ignore short-term noise, and let my automated SIP run',
        subtext: 'Understand that market corrections are standard cyclical phenomena',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Long holding periods are great levelers; remaining disciplined yields higher long-term CAGR.',
        aiGuidance: 'DICE qualifies you for diversified equity funds (Large & Mid Cap, Flexi Cap) with systematic monthly investments.'
      },
      {
        id: 'q5_d',
        label: 'View it as a discount sale and deploy additional lump-sum capital',
        subtext: 'Eager to accumulate high-quality fund units at lower NAV',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2, behavioralBiasDetected: 'Contrarian Willingness' },
        holdingInsight: 'Contrarian buying lowers the weighted average cost of acquisition, boosting future CAGR upon recovery.',
        aiGuidance: 'DICE scores high-growth equity and value-oriented funds at top tier for aggressive wealth building.'
      }
    ]
  },
  {
    id: 6,
    title: 'Recency Bias & Market Timing Urge',
    category: 'Behavioral Biases',
    question: 'A specific sector fund (e.g. Defense or PSU) delivered 65% return last year. How do you evaluate it today?',
    explanationWhyAsked: 'Investors suffer from Recency Bias—extrapolating the recent bull run into indefinite future returns.',
    behaviouralConcept: 'Recency Bias & Past Performance Fallacy',
    holdingAspect: 'Prevents holding overheated thematic portfolios prone to severe post-rally mean reversion.',
    options: [
      {
        id: 'q6_a',
        label: 'I want to invest all my new money there to catch the momentum',
        subtext: 'Assuming high past returns will repeat next year',
        scoreImpact: { riskCapacity: 0, riskWillingness: 1, behavioralBiasDetected: 'Severe Recency Bias / Return Chasing' },
        holdingInsight: 'SEBI mandated disclaimer: "Past performance does not guarantee future results." The top fund in year 1 rarely stays top in year 2.',
        aiGuidance: 'DICE penalizes thematic/sector concentration and enforces diversified multi-cap or flexi-cap core allocation.'
      },
      {
        id: 'q6_b',
        label: 'I might take a small tactical bet, but keep the bulk in diversified funds',
        subtext: 'Core and satellite portfolio strategy',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'NISM Ch 12.1 recommends the Core & Satellite approach: 80% core diversified funds + up to 20% tactical satellite exposure.',
        aiGuidance: 'DICE Engine supports a disciplined core-satellite structure while keeping portfolio overlap strictly under 50%.'
      },
      {
        id: 'q6_c',
        label: 'I prefer funds with steady, consistent 5-year rolling returns over 1-year spikes',
        subtext: 'Evaluating consistency rather than single-year anomalies',
        scoreImpact: { riskCapacity: 1, riskWillingness: 0 },
        holdingInsight: 'Rolling returns eliminate endpoint distortion and reveal the true consistency of fund manager alpha.',
        aiGuidance: 'DICE Performance Scoring gives high weight to 3Y/5Y rolling consistency and Information Ratio.'
      },
      {
        id: 'q6_d',
        label: 'I avoid hyped thematic/sector funds entirely due to cyclicality',
        subtext: 'Strictly stick to broad market indices or diversified active funds',
        scoreImpact: { riskCapacity: 1, riskWillingness: -1 },
        holdingInsight: 'Sector funds require timing the entry and exit; wrong timing can result in multi-year stagnation.',
        aiGuidance: 'DICE filters out sector funds and ranks well-diversified index or flexi-cap funds at top tier.'
      }
    ]
  },
  {
    id: 7,
    title: 'Herd Mentality & Social Influence',
    category: 'Behavioral Biases',
    question: 'Your colleagues or family group are excitedly investing in a newly launched scheme or stock. What do you do?',
    explanationWhyAsked: 'Herd mentality induces investors to enter crowded trades near market peaks, buying high and selling low.',
    behaviouralConcept: 'Herd Mentality Bias',
    holdingAspect: 'Protects holdings from speculative fads and unvetted NFOs.',
    options: [
      {
        id: 'q7_a',
        label: 'Follow them and invest immediately to avoid missing out (FOMO)',
        subtext: 'Trust the crowd wisdom over individual analysis',
        scoreImpact: { riskCapacity: -1, riskWillingness: 1, behavioralBiasDetected: 'Herd Mentality / FOMO' },
        holdingInsight: 'Entering assets based on social buzz usually coincides with the late stage of a bull run, maximizing downside vulnerability.',
        aiGuidance: 'DICE Engine relies on rules-based suitability algorithms, insulating your financial roadmap from peer pressure.'
      },
      {
        id: 'q7_b',
        label: 'Research the scheme’s SID, KIM, and portfolio before deciding',
        subtext: 'Perform objective verification as mandated by SEBI',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Reading mandatory documents (SID, SAI, KIM) ensures true suitability and eliminates hidden risk surprises.',
        aiGuidance: 'DICE Engine audits all SID investment mandates, asset allocation limits, and historical risk indicators for you.'
      },
      {
        id: 'q7_c',
        label: 'Consult a professional Registered Investment Advisor (RIA) or Distributor (MFD)',
        subtext: 'Prefer professional diligence over amateur tips',
        scoreImpact: { riskCapacity: 1, riskWillingness: 0 },
        holdingInsight: 'the value of professional help: eliminating behavioral mistakes that destroy individual returns.',
        aiGuidance: 'DICE Engine acts as an objective suitability auditor following AMFI Code of Ethics and SEBI suitability norms.'
      },
      {
        id: 'q7_d',
        label: 'Completely ignore social noise and stick strictly to my financial plan',
        subtext: 'Disciplined adherence to target asset allocation',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Disciplined asset allocation accounts for over 85% of long-term portfolio return variation.',
        aiGuidance: 'DICE scores this high for strategic asset allocation stability and portfolio rebalancing discipline.'
      }
    ]
  },
  {
    id: 8,
    title: 'Existing Debt & Loan Obligations',
    category: 'Context & Holdings',
    question: 'What is your current total debt obligation (Home loan, car loan, personal loan, credit card balances)?',
    explanationWhyAsked: 'High fixed debt servicing severely impairs risk capacity, regardless of high emotional risk willingness.',
    behaviouralConcept: 'Risk Capacity vs Willingness Decoupling',
    holdingAspect: 'Measures financial leverage and fixed cash outflow commitments.',
    options: [
      {
        id: 'q8_a',
        label: 'Heavy debt (EMIs consume > 40% of my monthly income)',
        subtext: 'High recurring fixed outflow burden',
        scoreImpact: { riskCapacity: -2, riskWillingness: 0, liquidityNeed: 'High' },
        holdingInsight: 'Carrying high-interest debt while chasing market equity creates negative net returns; interest on debt often outpaces fund returns.',
        aiGuidance: 'DICE prioritizes conservative liquid holdings and recommends debt reduction before taking aggressive equity risks.'
      },
      {
        id: 'q8_b',
        label: 'Moderate debt (EMIs are 20% to 40% of monthly income, e.g. home loan)',
        subtext: 'Manageable structured debt with stable income',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0 },
        holdingInsight: 'Stable mortgage debt is manageable, provided an emergency fund and insurance cover are intact.',
        aiGuidance: 'DICE balances growth equity with debt mutual funds to maintain liquidity comfort.'
      },
      {
        id: 'q8_c',
        label: 'Low debt (EMIs < 20% of income)',
        subtext: 'Minimal financial leverage, comfortable surplus',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Low debt burden frees up discretionary cash flow for regular wealth-building compounding.',
        aiGuidance: 'DICE Engine allocates higher equity weighting to maximize goal achievement.'
      },
      {
        id: 'q8_d',
        label: 'Completely debt-free (Zero loans, zero credit card dues)',
        subtext: 'Total financial flexibility and ownership',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Being debt-free grants maximum risk capacity to withstand equity volatility without forced liquidation.',
        aiGuidance: 'DICE unlocks highest strategic equity allocation according to your time horizon.'
      }
    ]
  },
  {
    id: 9,
    title: 'Investment Knowledge & Confidence Calibration',
    category: 'Behavioral Biases',
    question: 'How familiar are you with mutual fund metrics such as Beta, Sharpe Ratio, Modified Duration, and Total Expense Ratio (TER)?',
    explanationWhyAsked: 'Overconfidence bias causes investors to take complex derivative or duration risks without understanding underlying mechanics.',
    behaviouralConcept: 'Overconfidence Bias',
    holdingAspect: 'Determines whether complex hybrid/debt funds or simple broad-based index funds are suitable.',
    options: [
      {
        id: 'q9_a',
        label: 'Beginner: I know mutual funds pool money, but I don’t follow financial ratios',
        subtext: 'Prefer simple, transparent, easy-to-understand funds',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1 },
        holdingInsight: 'Complex specialized funds (like credit risk or long-short SIFs) carry subtleties that require continuous monitoring.',
        aiGuidance: 'DICE Engine recommends transparent Large Cap, Flexi Cap, or Index Funds with low complexity and clear mandates.'
      },
      {
        id: 'q9_b',
        label: 'Intermediate: I understand NAV, CAGR, SIP, and basic asset classes',
        subtext: 'Comfortable with standard equity and hybrid fund operations',
        scoreImpact: { riskCapacity: 1, riskWillingness: 0 },
        holdingInsight: 'Solid foundation for diversified active and passive mutual fund strategies.',
        aiGuidance: 'DICE Engine incorporates 3-year performance, TER comparisons, and SEBI Riskometer levels in your matches.'
      },
      {
        id: 'q9_c',
        label: 'Advanced: I track Sharpe ratios, Beta, standard deviation, and portfolio holdings',
        subtext: 'Experienced investor evaluating risk-adjusted returns and manager alpha',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Able to evaluate fund manager alpha, tracking error, and interest rate duration risk.',
        aiGuidance: 'DICE Engine presents full quantitative metrics (500-day Sharpe, Beta, Max Drawdown) on your results dashboard.'
      },
      {
        id: 'q9_d',
        label: 'Professional / Trader: I actively analyze macro yields, credit spreads, and derivatives',
        subtext: 'Capable of handling complex multi-asset or tactical allocation',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2, behavioralBiasDetected: 'Potential Overconfidence Check' },
        holdingInsight: 'Ensure that active confidence does not translate to excessive portfolio turnover, which incurs high broking costs.',
        aiGuidance: 'DICE Engine validates that the fund manager remains true-to-label and adheres to SEBI investment restrictions.'
      }
    ]
  },
  {
    id: 10,
    title: 'Guaranteed Return vs Inflation Purchasing Power',
    category: 'Risk Capacity & Willingness',
    question: 'How do you view guaranteed low-return instruments (like traditional bank FDs) versus market-linked funds?',
    explanationWhyAsked: 'Many investors mistakenly consider bank deposits risk-free, ignoring that inflation (6-8%) erodes purchasing power over time.',
    behaviouralConcept: 'Money Illusion & Inflation Risk Neglect',
    holdingAspect: 'Evaluates balance between nominal safety and real purchasing power protection.',
    options: [
      {
        id: 'q10_a',
        label: 'I only want guaranteed principal, even if returns are lower than inflation',
        subtext: 'Zero tolerance for any negative mark-to-market number',
        scoreImpact: { riskCapacity: -1, riskWillingness: -2, behavioralBiasDetected: 'Inflation Blindness' },
        holdingInsight: 'NISM Table 1.1 reveals Rs 10,000 needs Rs 21,589 in 10 years at 8% inflation. Guaranteed 6% FD after 30% tax yields negative real return.',
        aiGuidance: 'DICE respects your risk aversion, routing to Liquid/Overnight schemes, but highlights the purchasing power shortfall.'
      },
      {
        id: 'q10_b',
        label: 'I want stability first, but willing to allocate 20-30% to equity to beat inflation',
        subtext: 'Conservative hybrid approach',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1 },
        holdingInsight: 'Conservative Hybrid funds (10-25% equity, 75-90% debt, NISM Ch 2.2.4) provide inflation cushion with low volatility.',
        aiGuidance: 'DICE recommends Conservative Hybrid or Equity Savings funds with tax-efficient equity arbitrage components.'
      },
      {
        id: 'q10_c',
        label: 'I prioritize real inflation-beating wealth over nominal safety',
        subtext: 'Accepting intermediate fluctuations for superior long-term purchasing power',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Sensex compounding at 15.4% p.a. since 1979 has historically outpaced inflation by over 8% p.a..',
        aiGuidance: 'DICE matches you with diversified equity funds (Large Cap & Flexi Cap) designed for inflation-beating capital growth.'
      },
      {
        id: 'q10_d',
        label: 'I actively seek high risk-adjusted alpha and maximum real compounding',
        subtext: 'Willing to hold through market drawdowns for peak long-term returns',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2 },
        holdingInsight: 'Maximizes long-term terminal wealth if held across 7-10+ years through disciplined SIPs.',
        aiGuidance: 'DICE qualifies Mid Cap, Multi Cap, and Flexi Cap schemes with top Sharpe and Information ratios.'
      }
    ]
  },
  {
    id: 11,
    title: 'Real Estate & Physical Asset Liquidity Perspective',
    category: 'Context & Holdings',
    question: 'How do you view your real estate holdings in relation to your financial investment portfolio?',
    explanationWhyAsked: 'self-occupied residential property is the largest life expense, not an investment, because selling it disrupts lifestyle.',
    behaviouralConcept: 'Illiquidity Bias & Real Estate Mental Accounting',
    holdingAspect: 'Divisibility and liquidity of total family asset base.',
    options: [
      {
        id: 'q11_a',
        label: 'I believe real estate is the only true wealth; financial funds are paper assets',
        subtext: 'Heavy emotional attachment to physical brick-and-mortar',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1, behavioralBiasDetected: 'Tangibility Bias' },
        holdingInsight: 'Real estate is indivisible, takes months to liquidate, incurs 7-10% transaction costs (brokerage/registration), and carries high maintenance.',
        aiGuidance: 'DICE emphasizes that mutual funds offer daily liquidity, fractional divisibility (even Rs 500), and zero property maintenance hassle.'
      },
      {
        id: 'q11_b',
        label: 'I own my home, but realize I need liquid financial investments for life goals',
        subtext: 'Separating self-occupied residence from liquid wealth',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Clear separation between consumption assets (home) and wealth-generating financial portfolios.',
        aiGuidance: 'DICE creates a liquid, goal-aligned mutual fund portfolio to fund education, retirement, and travel independently.'
      },
      {
        id: 'q11_c',
        label: 'I hold commercial/rental property and want mutual funds to balance liquidity',
        subtext: 'Using mutual funds to offset illiquidity of physical properties',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Financial assets provide the liquidity buffer that physical property rental delays or vacancies cannot offer.',
        aiGuidance: 'DICE recommends high-quality liquid, short duration, and equity funds to complement rental income.'
      },
      {
        id: 'q11_d',
        label: 'I prefer financial assets (Mutual Funds, REITs) over physical property entirely',
        subtext: 'Valuing transparency, divisibility, and instant electronic execution',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2 },
        holdingInsight: 'REITs and mutual funds provide transparent fair valuation and professional management without tenant issues.',
        aiGuidance: 'DICE unlocks complete modern asset allocation across diversified equity, debt, and liquid funds.'
      }
    ]
  },
  {
    id: 12,
    title: 'Gold & Commodities Allocation Role',
    category: 'Context & Holdings',
    question: 'What role does gold or silver play in your current investment holdings?',
    explanationWhyAsked: 'Gold does not generate interest or dividends (only capital appreciation) and functions primarily as a crisis safe-haven.',
    behaviouralConcept: 'Safe-Haven Illusion vs Opportunity Cost',
    holdingAspect: 'Assesses physical jewelry versus financial Gold ETFs / Sovereign Gold Bonds.',
    options: [
      {
        id: 'q12_a',
        label: 'Hold large quantities of physical gold jewelry/coins as primary wealth store',
        subtext: 'Traditional family holding for emergency security',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1, behavioralBiasDetected: 'Cultural Endowment Bias' },
        holdingInsight: 'Physical gold incurs making charges (10-25%), purity risks, locker charges, and generates zero periodic cash flow.',
        aiGuidance: 'DICE recommends capping gold at 5-10% of portfolio and shifting to Gold ETFs for transparent LBMA-linked NAV without making charges.'
      },
      {
        id: 'q12_b',
        label: 'Hold 5% to 10% in Gold ETFs / Multi-Asset funds as a portfolio hedge',
        subtext: 'Prudent allocation for crisis and currency depreciation hedging',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Gold acts as a counterweight during geopolitical conflict or currency weakness; 5-10% is optimal for portfolio diversification.',
        aiGuidance: 'DICE matches Multi-Asset Allocation funds (minimum 10% in 3 asset classes: equity, debt, gold/silver) for automatic rebalancing.'
      },
      {
        id: 'q12_c',
        label: 'Minimal or zero gold; prefer productive productive assets (equity & debt)',
        subtext: 'Focusing on companies that create economic value and earnings growth',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Productive businesses reinvest profits to compound earnings, whereas gold relies solely on commodity price speculation.',
        aiGuidance: 'DICE prioritizes diversified equity funds that capture economic growth across expanding Indian industries.'
      },
      {
        id: 'q12_d',
        label: 'I trade commodity futures and precious metals actively',
        subtext: 'Leveraged short-term commodity speculation',
        scoreImpact: { riskCapacity: 0, riskWillingness: 2, behavioralBiasDetected: 'Gambler’s Tendency' },
        holdingInsight: 'that commodity derivatives are leveraged short-term contracts unsuitable for long-term goal funding.',
        aiGuidance: 'DICE redirects you toward disciplined long-term mutual fund schemes to anchor your core wealth safely.'
      }
    ]
  },
  {
    id: 13,
    title: 'Familiarity & Concentration Bias in Sector Holdings',
    category: 'Behavioral Biases',
    question: 'If you work in a specific sector (like IT, Pharma, or Banking), do you prefer investing mostly in that same sector?',
    explanationWhyAsked: '"Interest of the investors" bias: an IT engineer investing only in tech stocks concentrates both human capital and financial capital in one basket.',
    behaviouralConcept: 'Familiarity & Double-Exposure Concentration Bias',
    holdingAspect: 'Checks for correlation between employment income and investment risk.',
    options: [
      {
        id: 'q13_a',
        label: 'Yes, I prefer investing heavily in my own industry because I understand it best',
        subtext: 'Holding company stock or sector funds in my profession',
        scoreImpact: { riskCapacity: -1, riskWillingness: 1, behavioralBiasDetected: 'Double-Exposure Concentration Bias' },
        holdingInsight: 'If an industry downturn hits, you face simultaneous salary risks and severe portfolio drops (e.g. tech layoff + stock crash).',
        aiGuidance: 'DICE strictly flags this concentration risk and enforces multi-sector diversification to decouple investments from your paycheck.'
      },
      {
        id: 'q13_b',
        label: 'I like my sector, but I understand the need to diversify across other industries',
        subtext: 'Open to broad market diversification',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Diversification across uncorrelated sectors reduces unsystematic risk without sacrificing long-term returns.',
        aiGuidance: 'DICE selects Flexi Cap or Multi Cap funds that automatically distribute weight across Banking, IT, Auto, Pharma, FMCG, and Industrials.'
      },
      {
        id: 'q13_c',
        label: 'I deliberately avoid my own sector to ensure total risk independence',
        subtext: 'Hedging employment risk with contrasting investment sectors',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Sophisticated risk hedging strategy that shields family finances from single-industry shocks.',
        aiGuidance: 'DICE scores broad-based equity schemes with balanced sector weightings at highest tier.'
      },
      {
        id: 'q13_d',
        label: 'I leave all sector allocations entirely to professional fund managers',
        subtext: 'Relying on research analysts and bottom-up/top-down EIC frameworks',
        scoreImpact: { riskCapacity: 2, riskWillingness: 1 },
        holdingInsight: 'Professional fund managers use the Economy-Industry-Company (EIC) framework to optimize sector rotation.',
        aiGuidance: 'DICE prioritizes actively managed diversified funds with proven alpha track records.'
      }
    ]
  },
  {
    id: 14,
    title: 'Discipline in Systematic Investing (SIP) vs Timing Market',
    category: 'Strategy & Discipline',
    question: 'How do you intend to deploy your ongoing investment capital?',
    explanationWhyAsked: 'Timing the market causes investors to miss the strongest rally days; Rupee Cost Averaging via SIP guarantees discipline.',
    behaviouralConcept: 'Market Timing Trap vs Rupee Cost Averaging',
    holdingAspect: 'Mechanism of capital infusion: automated debit (NACH/OTM) vs discretionary lumpsum.',
    options: [
      {
        id: 'q14_a',
        label: 'Automated monthly SIP via Bank Mandate (NACH / OTM)',
        subtext: 'Invest fixed amount on a fixed date every month regardless of market noise',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Rupee Cost Averaging automatically buys more units when NAV is low and fewer when high.',
        aiGuidance: 'DICE Engine strongly favors SIP-friendly open-ended schemes with low minimum SIP tickets (Rs 500 - Rs 1,000).'
      },
      {
        id: 'q14_b',
        label: 'Automated SIP plus annual Step-Up (increasing 10% each year)',
        subtext: 'Scaling investments in tandem with expected salary/income increments',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2 },
        holdingInsight: 'NISM Ch 9.12 SIP Top-up facility: increases terminal wealth significantly (e.g. Rs 2,500 + Rs 500/yr tops up disciplined corpus).',
        aiGuidance: 'DICE calculates future value using the Step-Up compounding engine to demonstrate exponential wealth acceleration.'
      },
      {
        id: 'q14_c',
        label: 'Lump-sum whenever I accumulate a surplus or see a market dip',
        subtext: 'Discretionary lump-sum entries without fixed monthly schedule',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0, behavioralBiasDetected: 'Market Timing Urge' },
        holdingInsight: 'Lump-sum deployment in equity carries entry point risk; if market enters correction right after entry, regret aversion triggers.',
        aiGuidance: 'DICE recommends deploying large lump-sums via Systematic Transfer Plan (STP) from a Liquid Fund into Equity over 6-12 months.'
      },
      {
        id: 'q14_d',
        label: 'Hold cash until a massive market crash occurs, then buy all at once',
        subtext: 'Waiting on the sidelines for the "perfect bottom"',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1, behavioralBiasDetected: 'Cash Drag / Analysis Paralysis' },
        holdingInsight: 'Sitting in cash incurs heavy opportunity loss; historical data shows markets often climb for years before correcting to levels higher than entry point.',
        aiGuidance: 'DICE suggests initiating immediate baseline SIPs to participate in growth while keeping dry powder.'
      }
    ]
  },
  {
    id: 15,
    title: 'Plan Selection: Direct vs Regular & Expense Drag',
    category: 'Strategy & Discipline',
    question: 'What is your preference regarding Mutual Fund Direct Plans versus Regular Plans?',
    explanationWhyAsked: 'SEBI mandates two distinct plans: Direct Plans have lower Total Expense Ratio (TER) without distribution commission; Regular Plans include distributor trail fees.',
    behaviouralConcept: 'Cost Consciousness vs Advisory Value Trade-off',
    holdingAspect: 'Directly impacts the net NAV compounding over 10-20 years.',
    options: [
      {
        id: 'q15_a',
        label: 'Direct Plan: I do my own research and want lowest Total Expense Ratio (TER)',
        subtext: 'Zero distributor commission; higher NAV compounding over time',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'A 0.5% - 1.0% lower TER in Direct Plans can compound to 15-20% higher terminal portfolio value over 20 years.',
        aiGuidance: 'DICE displays verified Direct Plan NAVs and lower TER structures with complete transparency.'
      },
      {
        id: 'q15_b',
        label: 'Regular Plan: I value ongoing handholding, paperwork assistance, and distributor guidance',
        subtext: 'Comfortable with distributor earning trail commission from scheme expenses',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0 },
        holdingInsight: 'Trail commission is paid to MFDs from scheme AUM to service folios, assist KYC, and prevent behavioral panics.',
        aiGuidance: 'DICE evaluates Regular Plan performance while disclosing full trail commission rules as mandated by SEBI Master Circular 2026.'
      },
      {
        id: 'q15_c',
        label: 'Not sure: I don’t know the difference between Direct and Regular plans',
        subtext: 'Seeking educational clarity on how expense ratios work',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1 },
        holdingInsight: 'Under SEBI regulations, every mutual fund scheme has both Direct and Regular options with identical portfolios but different NAVs.',
        aiGuidance: 'DICE Engine highlights the exact TER difference and net return delta between Direct and Regular plans in every scheme breakdown.'
      }
    ]
  },
  {
    id: 16,
    title: 'Option Selection: Growth vs IDCW (Dividend Payout)',
    category: 'Strategy & Discipline',
    question: 'Which distribution option aligns with your financial cash flow need: Growth or IDCW?',
    explanationWhyAsked: 'Since April 2020, IDCW (Dividend) is taxed at the investor’s marginal slab rate (up to 35%+), whereas Growth option enables pre-tax compounding and tax deferral.',
    behaviouralConcept: 'Dividend Fallacy vs Compounding Awareness',
    holdingAspect: 'Cash flow structure: regular bank credit vs uninterrupted NAV compounding.',
    options: [
      {
        id: 'q16_a',
        label: 'Growth Option: Reinvest all profits to compound tax-efficiently until redemption',
        subtext: 'No periodic payouts; maximum wealth accumulation',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Growth option defers capital gains tax until actual redemption, enabling compounding on the gross pre-tax value.',
        aiGuidance: 'DICE scores Growth option as the most tax-efficient choice for wealth accumulation goals.'
      },
      {
        id: 'q16_b',
        label: 'IDCW (Payout): I want regular dividend payouts credited into my bank account',
        subtext: 'Seeking periodic cash inflow from the scheme',
        scoreImpact: { riskCapacity: -1, riskWillingness: -1, behavioralBiasDetected: 'Dividend Fallacy' },
        holdingInsight: 'Dividends are NOT guaranteed, only paid from distributable surplus, cause NAV to drop, and are taxed at your income slab.',
        aiGuidance: 'DICE advises that if you need regular income, a Systematic Withdrawal Plan (SWP) from a Growth fund is much more tax-efficient than IDCW.'
      },
      {
        id: 'q16_c',
        label: 'IDCW (Reinvestment): Reinvest dividends into more units automatically',
        subtext: 'Allotted additional units at ex-dividend NAV',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0 },
        holdingInsight: 'You pay tax on the reinvested dividend in the year of declaration even though no cash entered your bank account.',
        aiGuidance: 'DICE recommends switching to pure Growth option to avoid unnecessary annual taxation on phantom payouts.'
      }
    ]
  },
  {
    id: 17,
    title: 'Tax Saving Requirement (Section 80C & ELSS Lock-in)',
    category: 'Context & Holdings',
    question: 'Are you seeking Section 80C tax deductions under the Old Tax Regime, and can you lock capital for 3 years?',
    explanationWhyAsked: 'ELSS schemes offer up to Rs 1.5 Lakh 80C deduction but carry a mandatory 3-year statutory lock-in where money cannot be touched.',
    behaviouralConcept: 'Commitment Device vs Lock-in Anxiety',
    holdingAspect: 'Evaluates tax regime choice (Old vs New Regime) and capital lock-in readiness.',
    options: [
      {
        id: 'q17_a',
        label: 'Yes, I use Old Tax Regime and need 80C tax saving with 3-year lock-in (ELSS)',
        subtext: 'Want up to Rs 1.5 Lakh deduction with equity growth',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1, horizonYears: 3 },
        holdingInsight: 'ELSS has the shortest lock-in (3 years) among all 80C options (PPF 15 yrs, NSC 5 yrs) and provides equity returns.',
        aiGuidance: 'DICE Engine activates ELSS Tax Saver Fund eligibility checks and highlights the 3-year lock-in per SIP instalment rule.'
      },
      {
        id: 'q17_b',
        label: 'No, I have opted for the New Tax Regime (Section 80C deductions do not apply)',
        subtext: 'Prefer unrestricted liquidity without any mandatory 3-year lock-in',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Under the New Tax Regime, 80C deductions are not available; ELSS acts merely as an equity fund with an inconvenient 3-year freeze.',
        aiGuidance: 'DICE filters out ELSS and prioritizes open-ended Flexi Cap or Large & Mid Cap funds with full daily liquidity.'
      },
      {
        id: 'q17_c',
        label: 'Already exhausted 80C limit through EPF/PPF/Insurance; no extra tax benefit needed',
        subtext: 'Looking for optimal wealth growth without lock-in constraints',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Investing in ELSS beyond the 80C Rs 1.5L ceiling provides zero tax deduction while still locking up capital for 3 years.',
        aiGuidance: 'DICE routes your capital to diversified open-ended schemes for flexible goal-based rebalancing.'
      }
    ]
  },
  {
    id: 18,
    title: 'Liquidity Needs & Exit Load Sensitivity',
    category: 'Risk Capacity & Willingness',
    question: 'How critical is the ability to withdraw your money on short notice without exit penalties?',
    explanationWhyAsked: 'Mutual fund schemes charge exit loads (typically 1% if redeemed within 1 year for equity) to discourage short-term churn.',
    behaviouralConcept: 'Liquidity Preference & Exit Friction',
    holdingAspect: 'Matches withdrawal horizon with fund exit load schedules.',
    options: [
      {
        id: 'q18_a',
        label: 'Extremely critical: I may need this capital within 3 to 6 months',
        subtext: 'Must have zero exit load, T+1 settlement, or instant access',
        scoreImpact: { riskCapacity: -2, riskWillingness: -2, liquidityNeed: 'High' },
        holdingInsight: 'Equity exit loads (1%) and short-term capital gains tax (20% as per Budget 2024) make short holding periods uneconomical.',
        aiGuidance: 'DICE Engine restricts recommendations to Liquid Funds (which have zero exit load after day 7) or Overnight Funds.'
      },
      {
        id: 'q18_b',
        label: 'Moderate: I intend to stay invested for 1-3 years, but want an exit route if an emergency strikes',
        subtext: 'Comfortable with standard 1-year exit load thresholds',
        scoreImpact: { riskCapacity: 0, riskWillingness: 0, liquidityNeed: 'Moderate' },
        holdingInsight: 'Most open-ended schemes allow redemption anytime at prevailing NAV, subject to exit load if redeemed early.',
        aiGuidance: 'DICE matches open-ended Short Duration, Banking & PSU, or Balanced Advantage schemes with transparent exit load disclosures.'
      },
      {
        id: 'q18_c',
        label: 'Not critical at all: This money is committed for 5 to 10+ years',
        subtext: 'Zero expectation of early withdrawal; comfortable letting it compound',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2, liquidityNeed: 'Low' },
        holdingInsight: 'Holding past 12 months completely eliminates exit loads on equity funds and qualifies gains for 12.5% LTCG rate.',
        aiGuidance: 'DICE Engine fully optimizes for long-term compounders with high equity participation.'
      }
    ]
  },
  {
    id: 19,
    title: 'Market Capitalization Comfort (Large vs Mid vs Small Cap)',
    category: 'Risk Capacity & Willingness',
    question: 'How do you view company size and volatility across Large Cap, Mid Cap, and Small Cap stocks?',
    explanationWhyAsked: 'SEBI categorizes Large Cap (top 100), Mid Cap (101-250), and Small Cap (251st onwards). Small caps have higher growth potential but much steeper drawdowns.',
    behaviouralConcept: 'Size Volatility Tolerance & Downside Containment',
    holdingAspect: 'Underlying equity market capitalization allocation.',
    options: [
      {
        id: 'q19_a',
        label: 'Prefer stable giants: Top 100 blue-chip companies with established track records',
        subtext: 'Lower volatility, steady market leaders (Large Cap)',
        scoreImpact: { riskCapacity: 0, riskWillingness: -1 },
        holdingInsight: 'Large-cap stocks have resilient balance sheets to withstand economic downturns and provide steady downside protection.',
        aiGuidance: 'DICE matches Large Cap or Nifty 50 / Nifty 100 Index Funds with minimum 80% large cap exposure.'
      },
      {
        id: 'q19_b',
        label: 'Balanced blend: Want a mix of solid large caps with high-growth mid caps',
        subtext: 'Best of both worlds: stability plus growth potential',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Multi Cap (min 25% each in Large, Mid, Small) or Flexi Cap funds dynamically balance risk and return across cycles.',
        aiGuidance: 'DICE gives top score to Flexi Cap and Large & Mid Cap schemes with seasoned fund managers.'
      },
      {
        id: 'q19_c',
        label: 'Aggressive growth: Enthusiastic about Mid Cap and Small Cap champions',
        subtext: 'Comfortable with 30-40% volatility swings for potential multibaggers',
        scoreImpact: { riskCapacity: 2, riskWillingness: 2 },
        holdingInsight: 'Small caps carry liquidity risk and business fragility during downturns; requires a strict 7-10+ year holding period.',
        aiGuidance: 'DICE qualifies Mid Cap & Small Cap funds only when your investment horizon is at least 7 years.'
      }
    ]
  },
  {
    id: 20,
    title: 'Active Fund Management vs Passive Index Investing',
    category: 'Strategy & Discipline',
    question: 'Do you prefer an active fund manager trying to beat the benchmark, or low-cost passive index tracking?',
    explanationWhyAsked: 'Industry guidelines contrast Active vs Passive funds. Active managers aim to beat TRI benchmarks but charge higher TER; Index funds mimic indices at minimal cost.',
    behaviouralConcept: 'Alpha Expectation vs Cost Certainty',
    holdingAspect: 'Portfolio management style: active stock picking vs index replication.',
    options: [
      {
        id: 'q20_a',
        label: 'Active Management: Willing to pay higher TER for proven fund manager alpha',
        subtext: 'Seek professional research, stock selection, and downside protection',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Active funds allow fund managers to adjust sector allocations and pick undervalued growth stocks.',
        aiGuidance: 'DICE evaluates active schemes with 3Y/5Y rolling alpha and low portfolio turnover.'
      },
      {
        id: 'q20_b',
        label: 'Passive Indexing: Low-cost index fund or ETF replicating Nifty 50 / BSE Sensex',
        subtext: 'Minimal expense ratio (0.1% - 0.3%), zero fund manager selection risk',
        scoreImpact: { riskCapacity: 1, riskWillingness: 0 },
        holdingInsight: 'Index funds hold 95%+ in benchmark constituents; tracking error is the primary evaluation metric.',
        aiGuidance: 'DICE matches low-cost Index Funds and ETFs compliant with SEBI MF Lite and benchmark TRI tracking.'
      },
      {
        id: 'q20_c',
        label: 'Hybrid / Rule-Based: Want a dynamic asset allocation fund that switches between equity and debt',
        subtext: 'Automated valuation model (e.g. PE / PB ratio triggers)',
        scoreImpact: { riskCapacity: 1, riskWillingness: 1 },
        holdingInsight: 'Dynamic Asset Allocation (Balanced Advantage) funds increase debt when equity is expensive and buy equity when cheap.',
        aiGuidance: 'DICE scores Balanced Advantage Funds highly for investors seeking automated market rebalancing.'
      }
    ]
  }
];
