/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE Engine - Dynamic Investment Capital Engine
 * Deterministic, explainable, rules-based calculation & suitability engine
 * Grounded in NISM Series V-A & DICE Master Document
 */

import {
  UserResponses,
  InvestorProfile,
  MutualFundScheme,
  DICEScoringResult,
  SchemeDimensionScore,
  MatchLabel
} from '../types';
import { DICE_QUESTIONS } from '../data/questions';

export function calculateInvestorProfile(responses: UserResponses): InvestorProfile {
  let riskCapacityTotal = 0;
  let riskWillingnessTotal = 0;
  let maxCapacity = 0;
  let maxWillingness = 0;
  
  let horizonYears = 5;
  let goalName = 'Wealth Creation';
  let liquidityNeed: 'High' | 'Moderate' | 'Low' = 'Moderate';
  let hasEmergencyFund = true;
  let savingsRatePercentage = 25;
  let primaryExistingHolding = 'Balanced Portfolio';
  let liabilityLevel = 'Low';
  
  const detectedBiases: { bias: string; description: string; mitigationStrategy: string }[] = [];

  // Iterate over each question and evaluate selected option
  for (const q of DICE_QUESTIONS) {
    const selectedOptionId = responses.answers[q.id];
    const option = q.options.find(o => o.id === selectedOptionId) || q.options[0];
    
    // Track weights
    maxCapacity += 2;
    maxWillingness += 2;
    riskCapacityTotal += (option.scoreImpact.riskCapacity + 2); // 0 to 4 range
    riskWillingnessTotal += (option.scoreImpact.riskWillingness + 2); // 0 to 4 range
    
    if (option.scoreImpact.horizonYears !== undefined) {
      horizonYears = option.scoreImpact.horizonYears;
    }
    if (option.scoreImpact.liquidityNeed) {
      liquidityNeed = option.scoreImpact.liquidityNeed;
    }
    if (option.scoreImpact.behavioralBiasDetected) {
      detectedBiases.push({
        bias: option.scoreImpact.behavioralBiasDetected,
        description: option.holdingInsight,
        mitigationStrategy: option.aiGuidance
      });
    }

    // Specific question metadata
    if (q.id === 1) {
      goalName = option.label.split('(')[0].trim();
    }
    if (q.id === 2) {
      hasEmergencyFund = option.id === 'q2_c' || option.id === 'q2_d';
    }
    if (q.id === 3) {
      primaryExistingHolding = option.label.split('(')[0].trim();
    }
    if (q.id === 4) {
      savingsRatePercentage = option.id === 'q4_a' ? 8 : option.id === 'q4_b' ? 18 : option.id === 'q4_c' ? 35 : 55;
    }
    if (q.id === 8) {
      liabilityLevel = option.id === 'q8_a' ? 'Heavy (>40% EMI)' : option.id === 'q8_b' ? 'Moderate (20-40% EMI)' : option.id === 'q8_c' ? 'Low (<20% EMI)' : 'Debt-Free (0%)';
    }
  }

  // Normalize scores to 0-100
  const riskCapacityScore = Math.round((riskCapacityTotal / (maxCapacity * 2)) * 100);
  const riskWillingnessScore = Math.round((riskWillingnessTotal / (maxWillingness * 2)) * 100);
  
  // NISM Ch 1.7: Capacity (financial ability) carries 60% weight, Willingness (psychological) carries 40%
  const overallRiskScore = Math.round((0.60 * riskCapacityScore) + (0.40 * riskWillingnessScore));
  
  let riskProfileCategory: InvestorProfile['riskProfileCategory'] = 'Moderate';
  if (overallRiskScore >= 80) riskProfileCategory = 'Aggressive';
  else if (overallRiskScore >= 65) riskProfileCategory = 'Moderately Aggressive';
  else if (overallRiskScore >= 45) riskProfileCategory = 'Moderate';
  else if (overallRiskScore >= 30) riskProfileCategory = 'Moderately Conservative';
  else riskProfileCategory = 'Conservative';

  // Target asset allocation based on NISM Age/Horizon/Risk matrix (Ch 1.8)
  let targetAssetAllocation = { equity: 50, debt: 40, gold: 5, cash: 5 };
  if (riskProfileCategory === 'Aggressive') {
    targetAssetAllocation = { equity: 80, debt: 10, gold: 5, cash: 5 };
  } else if (riskProfileCategory === 'Moderately Aggressive') {
    targetAssetAllocation = { equity: 65, debt: 25, gold: 5, cash: 5 };
  } else if (riskProfileCategory === 'Moderate') {
    targetAssetAllocation = { equity: 50, debt: 35, gold: 10, cash: 5 };
  } else if (riskProfileCategory === 'Moderately Conservative') {
    targetAssetAllocation = { equity: 25, debt: 60, gold: 5, cash: 10 };
  } else {
    targetAssetAllocation = { equity: 10, debt: 70, gold: 0, cash: 20 };
  }

  // Deduplicate biases
  const uniqueBiases = detectedBiases.filter((b, idx, self) => 
    indexOrFirst(self, b.bias) === idx
  );

  return {
    name: responses.investorName.trim() || 'Valued Investor',
    riskCapacityScore,
    riskWillingnessScore,
    overallRiskScore,
    riskProfileCategory,
    goal: goalName,
    timeHorizonYears: horizonYears,
    investmentAmount: 10000,
    mode: 'SIP',
    liquidityNeed,
    detectedBiases: uniqueBiases,
    financialHoldingsSummary: {
      hasEmergencyFund,
      savingsRatePercentage,
      primaryExistingHolding,
      liabilityLevel
    },
    targetAssetAllocation
  };
}

function indexOrFirst(arr: { bias: string }[], bias: string): number {
  return arr.findIndex(item => item.bias === bias);
}

/**
 * Hard Eligibility Filtering (DICE Master Document Sec 6)
 * A scheme failing critical eligibility is eliminated before ranking.
 */
export function checkSchemeEligibility(scheme: MutualFundScheme, profile: InvestorProfile, responses: UserResponses): { isEligible: boolean; reasons: string[] } {
  const reasons: string[] = [];

  // 1. Horizon Check
  if (profile.timeHorizonYears < scheme.recommendedMinHorizonYears) {
    if (scheme.broadCategory === 'Equity' && profile.timeHorizonYears <= 1) {
      reasons.push(`Incompatible horizon: Goal requires liquidity in ${profile.timeHorizonYears} yr, but ${scheme.name} is an equity fund requiring ${scheme.recommendedMinHorizonYears}+ yrs.`);
    } else if (profile.timeHorizonYears < scheme.recommendedMinHorizonYears - 1) {
      reasons.push(`Horizon deficit: Investment horizon (${profile.timeHorizonYears} yrs) is shorter than scheme minimum recommended period (${scheme.recommendedMinHorizonYears} yrs).`);
    }
  }

  // 2. Lock-in & Liquidity conflict
  const lockInYears = scheme.lockInPeriod.includes('3 Years') ? 3 : 0;
  if (profile.timeHorizonYears < lockInYears) {
    reasons.push(`Mandatory statutory lock-in of ${scheme.lockInPeriod} conflicts with your ${profile.timeHorizonYears}-year goal.`);
  }

  if (profile.liquidityNeed === 'High' && lockInYears > 0) {
    reasons.push(`High liquidity requirement directly conflicts with statutory lock-in (${scheme.lockInPeriod}).`);
  }

  // 3. Severe Risk Mismatch
  if (profile.riskProfileCategory === 'Conservative' && scheme.riskometerScore >= 5) {
    reasons.push(`Severe risk mismatch: Conservative profile cannot be subjected to ${scheme.riskometer} riskometer level.`);
  }

  // 4. Tax Regime preference vs ELSS
  const q17Answer = responses.answers[17];
  if (scheme.categoryCode === 'EQ-ELSS' && q17Answer === 'q17_b') {
    reasons.push(`ELSS is ineligible because you selected the New Tax Regime where Section 80C deductions do not apply.`);
  }

  return {
    isEligible: reasons.length === 0,
    reasons
  };
}

/**
 * Proposed DICE 5-Dimension Scoring Model (DICE Master Document Sec 7)
 * Suitability: 30%, Risk: 25%, Performance: 20%, Return: 15%, Tax & Exit: 10%
 * Total = 0.30(S) + 0.25(R) + 0.20(P) + 0.15(T) + 0.10(X)
 */
export function evaluateSchemeDICE(
  scheme: MutualFundScheme,
  profile: InvestorProfile,
  responses: UserResponses
): DICEScoringResult {
  const eligibility = checkSchemeEligibility(scheme, profile, responses);

  // 1. Suitability Dimension (30%)
  let sScore = 70;
  const exactMatches: string[] = [];
  const partialMatches: string[] = [];
  const mismatches: string[] = [];

  // Goal & Horizon fit
  if (profile.timeHorizonYears >= scheme.recommendedMinHorizonYears) {
    sScore += 15;
    exactMatches.push(`Horizon match: Your ${profile.timeHorizonYears}-year horizon fully accommodates the ${scheme.recommendedMinHorizonYears}+ year mandate.`);
  } else {
    sScore -= 20;
    partialMatches.push(`Horizon strain: Recommended holding period is ${scheme.recommendedMinHorizonYears} years vs your ${profile.timeHorizonYears} years.`);
  }

  // Category fit with target allocation
  if (profile.targetAssetAllocation.equity > 50 && scheme.broadCategory === 'Equity') {
    sScore += 15;
    exactMatches.push(`Asset class match: Matches your target ${profile.targetAssetAllocation.equity}% equity wealth creation allocation.`);
  } else if (profile.targetAssetAllocation.debt > 50 && scheme.broadCategory === 'Debt') {
    sScore += 15;
    exactMatches.push(`Asset class match: Aligns with your capital preservation priority of ${profile.targetAssetAllocation.debt}% in debt.`);
  } else if (scheme.broadCategory === 'Hybrid') {
    sScore += 10;
    exactMatches.push(`Multi-asset balance: Provides automated equity/debt diversification suitable for moderate risk profiles.`);
  }

  // 2. Risk Dimension (25%)
  let rScore = 75;
  const riskDelta = Math.abs(
    (profile.overallRiskScore / 100 * 6) - scheme.riskometerScore
  );
  if (riskDelta <= 0.8) {
    rScore = 95;
    exactMatches.push(`Riskometer alignment: Scheme risk level (${scheme.riskometer}) precisely matches your ${profile.riskProfileCategory} profile.`);
  } else if (riskDelta <= 1.8) {
    rScore = 75;
    partialMatches.push(`Acceptable risk boundary: Scheme risk score (${scheme.riskometerScore}/6) is within tolerance of your profile.`);
  } else {
    rScore = 40;
    mismatches.push(`Risk volatility divergence: Scheme carries ${scheme.riskometer} risk vs ${profile.riskProfileCategory} investor comfort.`);
  }

  // Volatility adjustment based on Standard Deviation & Beta
  if (scheme.beta < 0.85 && profile.overallRiskScore < 60) {
    rScore += 5;
  }
  if (scheme.maxDrawdown < -20 && profile.financialHoldingsSummary.hasEmergencyFund === false) {
    rScore -= 10;
    mismatches.push(`Drawdown warning: Historical maximum drawdown (${scheme.maxDrawdown}%) poses high liquidation risk without emergency fund.`);
  }

  // 3. Performance Dimension (20%) - 500-day Sharpe, Alpha, Consistency
  let pScore = 70;
  if (scheme.sharpeRatio >= 1.3) pScore += 15;
  else if (scheme.sharpeRatio >= 1.0) pScore += 8;
  else pScore -= 5;

  if (scheme.alpha && scheme.alpha > 3.0) {
    pScore += 10;
    exactMatches.push(`Manager Alpha: Generates +${scheme.alpha}% excess return over benchmark ${scheme.benchmark}.`);
  }

  if (scheme.rating >= 5) pScore += 5;
  else if (scheme.rating <= 3) pScore -= 10;

  // 4. Return Dimension (15%) - 1Y, 3Y, 5Y historical returns
  let tScore = 70;
  if (scheme.return3Y && scheme.return3Y >= 18) tScore += 15;
  else if (scheme.return3Y && scheme.return3Y >= 12) tScore += 10;
  else if (scheme.return1Y >= 15) tScore += 5;

  // 5. Tax and Exit Dimension (10%)
  let xScore = 80;
  const q15Answer = responses.answers[15]; // Direct vs Regular
  if (q15Answer === 'q15_a' && scheme.plan === 'Direct') {
    xScore += 10;
    exactMatches.push(`Cost optimization: Direct plan eliminates distributor commission, saving on TER (${scheme.ter}%).`);
  }
  const q16Answer = responses.answers[16]; // Growth vs IDCW
  if (q16Answer === 'q16_a' && scheme.option === 'Growth') {
    xScore += 10;
    exactMatches.push(`Tax deferral match: Growth option avoids annual marginal slab tax and allows compounding before tax.`);
  }

  // Cap all sub-scores between 10 and 100
  const clamp = (val: number) => Math.max(10, Math.min(100, Math.round(val)));
  const cleanS = clamp(sScore);
  const cleanR = clamp(rScore);
  const cleanP = clamp(pScore);
  const cleanT = clamp(tScore);
  const cleanX = clamp(xScore);

  // DICE Master Formula: 0.30(S) + 0.25(R) + 0.20(P) + 0.15(T) + 0.10(X)
  const totalScore = Math.round(
    (0.30 * cleanS) +
    (0.25 * cleanR) +
    (0.20 * cleanP) +
    (0.15 * cleanT) +
    (0.10 * cleanX)
  );

  let matchLabel: MatchLabel = 'Not recommended';
  if (!eligibility.isEligible) {
    matchLabel = 'Not recommended';
  } else if (totalScore >= 80) {
    matchLabel = 'High Match';
  } else if (totalScore >= 60) {
    matchLabel = 'Medium Match';
  } else if (totalScore >= 40) {
    matchLabel = 'Low Match';
  }

  // Future value projections for illustrative purposes
  // SIP: PMT * (((1+i)^m - 1)/i)
  const monthlySip = 5000;
  const nYears = Math.max(1, profile.timeHorizonYears);
  const nMonths = nYears * 12;
  const futureValueProjections = [6, 10, 12].map(annualRate => {
    const monthlyRate = annualRate / 100 / 12;
    const fv = monthlySip * ((Math.pow(1 + monthlyRate, nMonths) - 1) / monthlyRate);
    const totalInvested = monthlySip * nMonths;
    return {
      rateAssumption: annualRate,
      investedAmount: totalInvested,
      projectedGain: Math.round(fv - totalInvested),
      projectedTotalValue: Math.round(fv)
    };
  });

  const whyMatches = exactMatches.slice(0, 3);
  const whyNotMatches = [
    ...eligibility.reasons,
    ...mismatches.slice(0, 2),
    ...partialMatches.slice(0, 1)
  ];

  return {
    scheme,
    isEligible: eligibility.isEligible,
    ineligibilityReasons: eligibility.reasons,
    suitabilityScore: {
      score: cleanS,
      weightedScore: Number((0.30 * cleanS).toFixed(1)),
      status: cleanS >= 80 ? 'High Match' : cleanS >= 60 ? 'Medium Match' : cleanS >= 40 ? 'Low Match' : 'Mismatch',
      summary: 'Evaluates fit with investor goal horizon, investment style and asset allocation.'
    },
    riskScore: {
      score: cleanR,
      weightedScore: Number((0.25 * cleanR).toFixed(1)),
      status: cleanR >= 80 ? 'High Match' : cleanR >= 60 ? 'Medium Match' : cleanR >= 40 ? 'Low Match' : 'Mismatch',
      summary: 'Matches portfolio standard deviation, beta, and SEBI riskometer against investor loss capacity.'
    },
    performanceScore: {
      score: cleanP,
      weightedScore: Number((0.20 * cleanP).toFixed(1)),
      status: cleanP >= 80 ? 'High Match' : cleanP >= 60 ? 'Medium Match' : cleanP >= 40 ? 'Low Match' : 'Mismatch',
      summary: 'Evaluates risk-adjusted Sharpe ratio, alpha, and drawdowns over 500+ trading days.'
    },
    returnScore: {
      score: cleanT,
      weightedScore: Number((0.15 * cleanT).toFixed(1)),
      status: cleanT >= 80 ? 'High Match' : cleanT >= 60 ? 'Medium Match' : cleanT >= 40 ? 'Low Match' : 'Mismatch',
      summary: 'Assesses historical rolling returns over 1Y, 3Y, 5Y periods relative to benchmark TRI.'
    },
    taxAndExitScore: {
      score: cleanX,
      weightedScore: Number((0.10 * cleanX).toFixed(1)),
      status: cleanX >= 80 ? 'High Match' : cleanX >= 60 ? 'Medium Match' : cleanX >= 40 ? 'Low Match' : 'Mismatch',
      summary: 'Evaluates exit load horizon, lock-in period, and post-Budget 2024 capital gains tax suitability.'
    },
    totalScore,
    matchLabel,
    rank: 0,
    whyMatches,
    whyNotMatches,
    exactMatches,
    partialMatches,
    mismatches,
    futureValueProjections
  };
}

/**
 * Runs full DICE matching across all schemes and returns top results.
 * Strictly adheres to rule: "Show fewer than three schemes if fewer than three pass hard eligibility checks; never force three recommendations."
 */
export function runDICEMatching(
  schemes: MutualFundScheme[],
  profile: InvestorProfile,
  responses: UserResponses
): { topMatches: DICEScoringResult[]; allEvaluations: DICEScoringResult[] } {
  const allEvaluations = schemes.map(s => evaluateSchemeDICE(s, profile, responses));

  // Filter eligible schemes only and sort by Total Score descending
  const eligibleSchemes = allEvaluations
    .filter(res => res.isEligible && res.totalScore >= 40)
    .sort((a, b) => b.totalScore - a.totalScore);

  // Take up to 3 schemes
  const topMatches = eligibleSchemes.slice(0, 3).map((match, idx) => ({
    ...match,
    rank: idx + 1
  }));

  return {
    topMatches,
    allEvaluations: allEvaluations.sort((a, b) => b.totalScore - a.totalScore)
  };
}
