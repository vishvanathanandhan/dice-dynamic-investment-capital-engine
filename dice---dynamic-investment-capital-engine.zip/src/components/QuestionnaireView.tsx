/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 20-Question Guided Behavioral & Financial Holdings Profiler
 * Integrates live Gemini 3.8 Flash AI reasoning & DICE Engine rules
 * Fully localized with seamless bilingual support (English & Tamil)
 */

import React, { useState, useEffect } from 'react';
import {
  UserResponses,
  MatchAnalysisResponse
} from '../types';
import { DICE_QUESTIONS } from '../data/questions';
import { getLocalizedQuestion } from '../data/questionsTamil';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  TrendingUp,
  RotateCcw,
  User,
  Loader2
} from 'lucide-react';

interface QuestionnaireViewProps {
  onComplete: (data: MatchAnalysisResponse) => void;
  onCancel: () => void;
}

export const QuestionnaireView: React.FC<QuestionnaireViewProps> = ({
  onComplete,
  onCancel,
}) => {
  const { t, isTamil } = useLanguage();
  const [investorName, setInvestorName] = useState('Avishvanath');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({
    1: 'q1_c',
    2: 'q2_c',
    3: 'q3_c',
    4: 'q4_c',
    5: 'q5_c',
    6: 'q6_c',
    7: 'q7_b',
    8: 'q8_c',
    9: 'q9_b',
    10: 'q10_c',
    11: 'q11_b',
    12: 'q12_b',
    13: 'q13_b',
    14: 'q14_a',
    15: 'q15_a',
    16: 'q16_a',
    17: 'q17_a',
    18: 'q18_c',
    19: 'q19_b',
    20: 'q20_a',
  });

  const [aiGuidanceLoading, setAiGuidanceLoading] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Client-side cache for fetched AI explanations
  const clientCacheRef = React.useRef<Record<string, string>>({});

  const rawQ = DICE_QUESTIONS[currentIndex];
  const currentQ = getLocalizedQuestion(rawQ, isTamil);
  const selectedOptionId = answers[currentQ.id];
  const selectedOption = currentQ.options.find((o) => o.id === selectedOptionId) || currentQ.options[0];

  useEffect(() => {
    let isCancelled = false;
    const cacheKey = `${currentQ.id}_${selectedOptionId}_${investorName.trim()}_${isTamil ? 'ta' : 'en'}`;

    if (isTamil) {
      setAiExplanation(selectedOption.aiGuidance);
      setAiGuidanceLoading(false);
      return;
    }

    if (clientCacheRef.current[cacheKey]) {
      setAiExplanation(clientCacheRef.current[cacheKey]);
      setAiGuidanceLoading(false);
      return;
    } else {
      setAiExplanation(selectedOption.aiGuidance);
    }

    const timer = setTimeout(async () => {
      if (!selectedOptionId) return;
      try {
        const res = await fetch('/api/dice/explain', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            questionId: currentQ.id,
            optionId: selectedOptionId,
            investorName,
          }),
        });
        const data = await res.json();
        if (!isCancelled && data.aiGuidance && !isTamil) {
          clientCacheRef.current[cacheKey] = data.aiGuidance;
          setAiExplanation(data.aiGuidance);
        }
      } catch (err) {
        if (!isCancelled) {
          setAiExplanation(selectedOption.aiGuidance);
        }
      }
    }, 800);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [currentQ.id, selectedOptionId, investorName, selectedOption.aiGuidance, isTamil]);

  const handleSelectOption = (optionId: string) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQ.id]: optionId,
    }));
  };

  const handleNext = () => {
    if (currentIndex < DICE_QUESTIONS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      window.scrollTo({ top: 120, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      window.scrollTo({ top: 120, behavior: 'smooth' });
    }
  };

  const { schemes } = useSchemes();

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const userResponses: UserResponses = {
        investorName: investorName.trim() || 'Avishvanath',
        answers,
      };

      const res = await fetch('/api/dice/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userResponses,
          schemes, // Pass in active full scheme universe including uploaded Excel records
        }),
      });

      if (!res.ok) {
        throw new Error(`Engine match failed: ${res.statusText}`);
      }

      const matchData: MatchAnalysisResponse = await res.json();
      onComplete(matchData);
    } catch (err) {
      console.error('Error submitting questionnaire:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const answeredCount = Object.keys(answers).length;
  const progressPercentage = Math.round((answeredCount / DICE_QUESTIONS.length) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Progress Header */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-[#2E2E38]">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
              <span>{isTamil ? 'NISM Series V-A ஒழுங்குமுறை கட்டமைப்பு' : 'NISM Series V-A Grounded Framework'}</span>
              <span>·</span>
              <span>{isTamil ? 'DICE பொருத்தம் முறைமை' : 'Deterministic Scoring Engine'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {t('quest.title', 'Investor Suitability & Behavioral Diagnostic')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {t('quest.subtitle', 'Evaluates emotional biases and financial holdings to recommend up to 3 verified schemes.')}
            </p>
          </div>

          {/* Temporary Name Entry */}
          <div className="w-full sm:w-auto bg-slate-50 dark:bg-[#141416] border border-slate-200 dark:border-[#2E2E38] rounded-xl px-3.5 py-2 flex items-center gap-2">
            <User className="w-4 h-4 text-slate-400 shrink-0" />
            <div className="flex flex-col">
              <label htmlFor="investor-name" className="text-[10px] uppercase font-semibold text-slate-500 dark:text-slate-400 leading-none">
                {t('quest.name_label', 'Temporary Entry Name')}
              </label>
              <input
                id="investor-name"
                type="text"
                value={investorName}
                onChange={(e) => setInvestorName(e.target.value)}
                placeholder={isTamil ? 'உங்கள் பெயரை உள்ளிடவும்' : 'Enter your name'}
                className="text-sm font-semibold text-slate-900 dark:text-white bg-transparent focus:outline-none w-36 sm:w-44"
              />
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-6 pt-4 border-t border-slate-100 dark:border-[#2E2E38]">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300 mb-2">
            <span>
              {isTamil ? `கேள்வி ${currentIndex + 1} / ${DICE_QUESTIONS.length}` : `Question ${currentIndex + 1} of ${DICE_QUESTIONS.length}`}
            </span>
            <span className="text-amber-700 dark:text-amber-400 font-mono tabular-nums">{progressPercentage}% {isTamil ? 'முடிந்தது' : 'Completed'}</span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-[#141416] rounded-full h-2 overflow-hidden border dark:border-[#2E2E38]">
            <div
              className="bg-amber-600 h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>

          {/* Quick jump step numbers */}
          <div className="flex items-center gap-1.5 mt-3 overflow-x-auto pb-1 scrollbar-none">
            {DICE_QUESTIONS.map((q, idx) => {
              const isAnswered = !!answers[q.id];
              const isCurrent = idx === currentIndex;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-7 h-7 rounded-lg text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                    isCurrent
                      ? 'bg-amber-600 text-white shadow-xs'
                      : isAnswered
                      ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 hover:bg-amber-200'
                      : 'bg-slate-100 dark:bg-[#141416] text-slate-500 dark:text-slate-400 hover:bg-slate-200 border dark:border-[#2E2E38]'
                  }`}
                  title={q.title}
                >
                  {q.id}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Question & Option Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Question & Options (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-2xl p-6 sm:p-7 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-amber-700 dark:text-amber-400 font-mono">Q{currentQ.id}</span>
            <span>·</span>
            <span>{currentQ.category}</span>
          </div>

          <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-snug">
            {currentQ.question}
          </h3>

          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 leading-relaxed bg-slate-50 dark:bg-[#141416] rounded-lg p-3 border border-slate-100 dark:border-[#2E2E38]">
            <span className="font-semibold text-slate-700 dark:text-slate-300">{t('quest.why_dice', 'Why DICE evaluates this: ')}</span>
            {currentQ.explanationWhyAsked}
          </p>

          {/* Options List */}
          <div className="mt-5 space-y-3">
            {currentQ.options.map((opt) => {
              const isSelected = selectedOptionId === opt.id;
              return (
                <div
                  key={opt.id}
                  onClick={() => handleSelectOption(opt.id)}
                  className={`cursor-pointer rounded-xl p-4 border transition-all duration-150 flex items-start gap-3 ${
                    isSelected
                      ? 'border-amber-600 bg-amber-50/50 dark:bg-amber-950/30 ring-1 ring-amber-600 shadow-xs'
                      : 'border-slate-200 dark:border-[#2E2E38] hover:border-slate-300 dark:hover:border-slate-600 hover:bg-slate-50/80 dark:hover:bg-[#141416]/50 bg-white dark:bg-[#1E1E24]'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                      isSelected
                        ? 'border-amber-600 bg-amber-600 text-white'
                        : 'border-slate-300 dark:border-[#2E2E38] bg-white dark:bg-[#141416]'
                    }`}
                  >
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />}
                  </div>

                  <div className="flex-1">
                    <div className="text-sm font-semibold text-slate-900 dark:text-white">{opt.label}</div>
                    {opt.subtext && (
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{opt.subtext}</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Navigation Controls */}
          <div className="mt-8 pt-5 border-t border-slate-100 dark:border-[#2E2E38] flex items-center justify-between">
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className="px-4 py-2 border border-slate-200 dark:border-[#2E2E38] rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-[#141416] disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t('quest.prev_btn', 'Previous')}</span>
            </button>

            {currentIndex < DICE_QUESTIONS.length - 1 ? (
              <button
                onClick={handleNext}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              >
                <span>{t('quest.next_btn', 'Next Question')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition-all shadow-sm hover:shadow-md disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isTamil ? 'DICE இயந்திரம் கணக்கிடுகிறது...' : 'Processing DICE Engine...'}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{t('quest.submit_btn', 'Complete & Match Funds')}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Right Column: AI Behavioral Character & Holding Analysis (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* AI Guide Card */}
          <div className="bg-linear-to-b from-white to-amber-50/30 dark:from-[#1E1E24] dark:to-[#141416] border border-amber-200 dark:border-[#2E2E38] rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-amber-100 dark:border-[#2E2E38]">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-900 dark:text-amber-400">
                <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>{t('quest.ai_guidance', 'AI Reason & DICE Engine Guidance')}</span>
              </div>
              <span className="text-[10px] font-mono text-amber-700 dark:text-amber-300 bg-amber-100/80 dark:bg-amber-950/60 px-2 py-0.5 rounded border dark:border-amber-900/40">
                {isTamil ? 'அடிப்படை: NISM V-A' : 'Grounded: NISM V-A'}
              </span>
            </div>

            {/* Selected Option Feedback */}
            <div className="mt-4">
              <div className="text-xs uppercase font-semibold text-slate-500 dark:text-slate-400">
                {isTamil ? 'பகுப்பாய்வு செய்யப்படுவது: ' : 'Diagnosing for: '}
                <span className="text-slate-900 dark:text-white font-bold">{investorName || (isTamil ? 'முதலீட்டாளர்' : 'Investor')}</span>
              </div>
              <div className="text-xs font-medium text-slate-700 dark:text-slate-300 mt-1 italic">
                "{selectedOption.label}"
              </div>
            </div>

            {/* AI Explanation Content */}
            <div className="mt-4 pt-4 border-t border-amber-100/60 dark:border-[#2E2E38]">
              {aiGuidanceLoading ? (
                <div className="flex items-center gap-2 text-xs text-amber-800 dark:text-amber-300 py-4">
                  <Loader2 className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />
                  <span>{isTamil ? 'DICE AI நடத்தை முறையை ஆய்வு செய்கிறது...' : 'DICE AI analyzing behavioral pattern...'}</span>
                </div>
              ) : (
                <div className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
                  {aiExplanation || selectedOption.aiGuidance}
                </div>
              )}
            </div>

            {/* Two Deep Analytical Pillars */}
            <div className="mt-5 space-y-3 pt-4 border-t border-amber-100 dark:border-[#2E2E38]">
              {/* Behavioral Character Insight */}
              <div className="bg-white/80 dark:bg-[#1E1E24] rounded-xl p-3 border border-amber-100 dark:border-[#2E2E38]">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>{isTamil ? 'கண்டறியப்பட்ட முதலீட்டாளர் நடத்தை குணம்:' : 'Behavioral Character Identified:'}</span>
                </div>
                <div className="text-xs text-amber-900 dark:text-amber-300 font-semibold mt-0.5">
                  {currentQ.behaviouralConcept}
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1 leading-normal">
                  {selectedOption.scoreImpact.behavioralBiasDetected ? (
                    isTamil
                      ? `சாத்தியமான நடத்தை சார்பு: ${selectedOption.scoreImpact.behavioralBiasDetected}. இதை உணர்வது சந்தை சரிவின் போது ஏற்படும் பயத்தைத் தடுக்கும்.`
                      : `Potential bias: ${selectedOption.scoreImpact.behavioralBiasDetected}. Recognizing this prevents emotional panic in down markets.`
                  ) : (
                    isTamil
                      ? 'குறிக்கோள் அபாயத்தை எதிர்கொள்ளும் சீரான முதலீட்டாளர் மனப்பான்மை.'
                      : 'Balanced investor mindset aligned with objective risk-taking.'
                  )}
                </p>
              </div>

              {/* Financial Holding Impact */}
              <div className="bg-white/80 dark:bg-[#1E1E24] rounded-xl p-3 border border-amber-100 dark:border-[#2E2E38]">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>{isTamil ? 'நிதி சொத்து தாக்கம்:' : 'Financial Holding Impact:'}</span>
                </div>
                <div className="text-xs text-slate-700 dark:text-slate-300 font-medium mt-0.5">
                  {currentQ.holdingAspect}
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1 leading-normal">
                  {selectedOption.holdingInsight}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="bg-slate-50 dark:bg-[#141416] border border-slate-200 dark:border-[#2E2E38] rounded-xl p-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>{isTamil ? 'பின்னர் மாற்ற வேண்டுமா? பதில்களை எப்போது வேண்டுமானாலும் மாற்றலாம்.' : 'Need to adjust later? Responses can be updated anytime.'}</span>
            <button
              onClick={onCancel}
              className="text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-medium underline underline-offset-2 shrink-0 cursor-pointer"
            >
              {isTamil ? 'முகப்புக்கு திரும்புக' : 'Back to Explorer'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
