/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Tools Grid filtered to genuine Mutual Fund tools, removing unwanted stock/IPO features
 */

import React from 'react';
import {
  FileSpreadsheet,
  Eye,
  PieChart,
  ShieldCheck,
  Search,
  ArrowLeftRight,
  TrendingUp,
  BarChart3,
  Award,
  DollarSign,
  Zap,
  Calculator,
  Compass,
  Database
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface ToolsGridProps {
  onSelectTool: (toolId: string) => void;
}

interface ToolItem {
  name: string;
  desc: string;
  icon: React.ReactNode;
  actionId: string;
  badge?: string;
}

export const ToolsGrid: React.FC<ToolsGridProps> = ({ onSelectTool }) => {
  const { t } = useLanguage();

  const tools: ToolItem[] = [
    {
      name: t('tools.data_quality_title', 'Data Quality & Audit Dashboard'),
      desc: t('tools.data_quality_desc', 'Verify field completeness, monitor regulatory disclosures, and audit 11,000+ schemes database health'),
      icon: <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      actionId: 'data_quality',
      badge: t('tools.badge_11k_universe', '11,000+ Universe')
    },
    {
      name: t('wealth.import_excel', 'Import Schemes (Excel / CSV)'),
      desc: t('tools.import_desc', 'Upload custom scheme data via Excel or CSV with instant app-wide linking and calculations'),
      icon: <FileSpreadsheet className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      actionId: 'upload_excel',
      badge: t('tools.badge_custom_import', 'Custom Import')
    },
    {
      name: t('tools.compare_title', 'Multi-Fund Compare'),
      desc: t('tools.compare_desc', 'Side-by-side comparison of up to 4 mutual funds across risk metrics, returns, and expense ratios'),
      icon: <ArrowLeftRight className="w-5 h-5 text-blue-500 dark:text-blue-400" />,
      actionId: 'fund_compare',
      badge: t('tools.badge_11k', '11k+ Schemes')
    },
    {
      name: t('tools.p2p_title', 'Point-to-Point Returns'),
      desc: t('tools.p2p_desc', 'Retrospective compounding, CAGR, and capital growth calculation for any fund in the database'),
      icon: <TrendingUp className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />,
      actionId: 'point_to_point',
      badge: t('tools.badge_compounding', 'Compounding')
    },
    {
      name: t('tools.watchlist_title', 'My Watchlist'),
      desc: t('tools.watchlist_desc', 'Track favorite mutual fund schemes with real-time NAV, 1-year returns, and quick factsheets'),
      icon: <Eye className="w-5 h-5 text-amber-500 dark:text-amber-400" />,
      actionId: 'watchlist',
      badge: t('tools.badge_live_tracker', 'Live Tracker')
    },
    {
      name: t('tools.20q_title', 'DICE 20Q Risk Assessment'),
      desc: t('tools.20q_desc', 'Diagnose your financial behavioral characters, loss aversion, and holdings suitability'),
      icon: <ShieldCheck className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      actionId: 'risk_assessment',
      badge: t('tools.badge_diagnostic', 'Diagnostic')
    },
    {
      name: t('tools.screener_title', 'Wealth Builder Screener'),
      desc: t('tools.screener_desc', 'Deep filter schemes across Equity, Debt, Hybrid, and Commodities with instant CSV export'),
      icon: <Search className="w-5 h-5 text-slate-600 dark:text-slate-400" />,
      actionId: 'screener'
    },
    {
      name: t('monitor.heading', 'Fund Monitor & Heatmap'),
      desc: t('tools.monitor_desc', 'Live category performance matrix and top performing schemes leaderboard across India'),
      icon: <BarChart3 className="w-5 h-5 text-slate-600 dark:text-slate-400" />,
      actionId: 'monitor'
    },
    {
      name: t('calc.heading', 'SIP & Goal Calculators'),
      desc: t('tools.calc_desc', 'Interactive SIP accumulation, lump sum compounding, and goal target planning calculators'),
      icon: <Calculator className="w-5 h-5 text-slate-600 dark:text-slate-400" />,
      actionId: 'calculators'
    }
  ];

  return (
    <section className="py-12 bg-[#FAF8F5] dark:bg-[#141416] border-b border-slate-200/80 dark:border-[#2E2E38] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              {t('tools.suite_subtitle', 'Interactive Tools Suite')}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-0.5">
              {t('tools.heading', 'Mutual Fund Research & Diagnostics')}
            </h2>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
            {t('tools.count_label', '9 Dedicated Analytical Tools')}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {tools.map((tool) => (
            <div
              key={tool.name}
              onClick={() => onSelectTool(tool.actionId)}
              className="group cursor-pointer bg-white dark:bg-[#1E1E24] border border-slate-200/90 dark:border-[#2E2E38] hover:border-amber-500/80 dark:hover:border-amber-500/80 rounded-2xl p-4 sm:p-5 transition-all duration-150 hover:shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-50 dark:bg-[#141416] group-hover:bg-amber-50 dark:group-hover:bg-amber-950/40 flex items-center justify-center transition-colors">
                    {tool.icon}
                  </div>
                  {tool.badge && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-[#141416] text-slate-700 dark:text-slate-300 group-hover:bg-amber-100 dark:group-hover:bg-amber-950/60 group-hover:text-amber-900 dark:group-hover:text-amber-300 transition-colors">
                      {tool.badge}
                    </span>
                  )}
                </div>
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
                  {tool.name}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-snug line-clamp-2">
                  {tool.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
