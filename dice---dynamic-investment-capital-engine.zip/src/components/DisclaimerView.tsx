/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE - Website Disclaimer Full Page View
 * Grounded in statutory Indian regulations and academic educational policies
 */

import React from 'react';
import { ShieldAlert, BookOpen, AlertTriangle, ArrowLeft, CheckCircle2, Scale, ExternalLink } from 'lucide-react';

interface DisclaimerViewProps {
  onBackToHome: () => void;
}

export const DisclaimerView: React.FC<DisclaimerViewProps> = ({ onBackToHome }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] px-3.5 py-2 rounded-xl shadow-2xs hover:bg-slate-50 dark:hover:bg-[#2A2A32] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          <span>Back to Explorer</span>
        </button>

        <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
          Last Reviewed: 07 November 2026
        </span>
      </div>

      {/* Main Document Card */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-10 shadow-xs space-y-8 transition-colors">
        {/* Title Header */}
        <div className="border-b border-slate-200 dark:border-[#2E2E38] pb-6 space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-bold uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>Statutory Legal & Educational Disclosures</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            DICE – Website Disclaimer
          </h1>
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
            Dynamic Investment Capital Engine (DICE)
          </p>
        </div>

        {/* 12 Disclaimer Sections */}
        <div className="space-y-6 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {/* 1 */}
          <section className="space-y-2">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="text-amber-700 dark:text-amber-400 font-mono">1.</span>
              <span>Educational Purpose Only</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              DICE is an independent financial literacy, mutual fund information and academic research project. The platform is intended to improve public understanding of mutual funds, financial markets, investment concepts, risk assessment and financial calculations.
            </p>
          </section>

          {/* 2 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">2.</span>
              <span>No Investment Advice</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              All information, tools, calculators, comparisons, illustrations and analytical outputs provided on this website are for general educational and informational purposes only. They do not constitute investment advice, financial planning, portfolio management, research recommendations, solicitation or an offer to purchase, sell or hold any financial instrument.
            </p>
          </section>

          {/* 3 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">3.</span>
              <span>Regulatory Status</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              DICE is not a SEBI-registered Investment Adviser, Research Analyst, Portfolio Manager, stockbroker, mutual fund distributor or Asset Management Company. The platform does not claim any regulatory registration or authorisation.
            </p>
          </section>

          {/* 4 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">4.</span>
              <span>No Scheme Promotion or Recommendation</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              DICE does not endorse, sponsor, advertise or recommend any particular mutual fund scheme, asset management company or investment product. Scheme comparisons, historical rankings and analytical displays, where available, are presented solely for educational examination of publicly available information.
            </p>
          </section>

          {/* 5 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">5.</span>
              <span>Data Accuracy and Verification</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Information displayed on this platform may be collected from publicly accessible sources, including AMFI, SEBI, asset management companies and other official disclosures. Although reasonable efforts may be made to validate information, DICE does not warrant that all data is complete, current, accurate or error-free. Users must independently verify all information with the original source.
            </p>
          </section>

          {/* 6 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">6.</span>
              <span>Historical Performance</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Historical returns, NAV movements, AUM, expense ratios and other performance-related information are not indicative of future results. Market conditions and scheme characteristics can change.
            </p>
          </section>

          {/* 7 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">7.</span>
              <span>Calculators and Illustrations</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Financial calculators use hypothetical assumptions and mathematical models for educational demonstrations. Their outputs are illustrative only and do not represent guaranteed returns, actual investment outcomes or a promise of achieving any financial goal.
            </p>
          </section>

          {/* 8 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">8.</span>
              <span>Independent Decision-Making</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Visitors are responsible for independently examining relevant scheme documents, including the Scheme Information Document (SID), Key Information Memorandum (KIM), factsheets and other applicable disclosures. They should seek advice from an appropriately registered professional where necessary.
            </p>
          </section>

          {/* 9 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">9.</span>
              <span>External Links</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Links to AMFI, SEBI, AMC websites and other third-party resources are provided for reference and educational convenience. DICE does not control or guarantee the accuracy, availability or content of external websites.
            </p>
          </section>

          {/* 10 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">10.</span>
              <span>Intellectual Property</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              Third-party trademarks, scheme names, logos and documents remain the property of their respective owners. Their appearance on this website does not imply affiliation, sponsorship or endorsement.
            </p>
          </section>

          {/* 11 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">11.</span>
              <span>Limitation of Responsibility</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              To the extent permitted by applicable law, DICE disclaims responsibility for losses or damages arising from reliance on incomplete, inaccurate, delayed or misunderstood information presented on the platform. Nothing in this disclaimer excludes liability that cannot legally be excluded.
            </p>
          </section>

          {/* 12 */}
          <section className="space-y-2 pt-4 border-t border-slate-100">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <span className="text-amber-700 font-mono">12.</span>
              <span>Regulatory Changes</span>
            </h2>
            <p className="text-slate-600 leading-relaxed">
              The platform and its disclosures should be reviewed periodically in light of applicable Indian laws, SEBI regulations, AMFI requirements and other relevant regulatory developments.
            </p>
          </section>
        </div>

        {/* Highlighted Risk Warning Box */}
        <div className="bg-amber-500/10 dark:bg-amber-950/20 border-2 border-amber-500/30 dark:border-amber-800/40 rounded-2xl p-6 space-y-2">
          <div className="flex items-center gap-2 text-amber-950 dark:text-amber-300 font-bold text-sm">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>Important Risk Disclosure</span>
          </div>
          <p className="text-xs sm:text-sm text-amber-900 dark:text-amber-300 font-semibold leading-relaxed">
            Mutual fund investments are subject to market risks. Read all scheme-related documents carefully before investing.
          </p>
        </div>

        {/* Footer of Card */}
        <div className="pt-6 border-t border-slate-200 dark:border-[#2E2E38] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div>
            <div className="font-extrabold text-slate-900 dark:text-white">
              DICE – Dynamic Investment Capital Engine
            </div>
            <div>Independent Financial Literacy and Academic Research Project</div>
          </div>

          <button
            onClick={() => {
              try {
                sessionStorage.setItem('dice_educational_disclaimer_accepted_v1', 'true');
              } catch {
                // ignore
              }
              onBackToHome();
            }}
            className="px-5 py-2.5 bg-slate-900 dark:bg-amber-600 hover:bg-slate-800 dark:hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-colors shadow-2xs cursor-pointer"
          >
            Acknowledge & Return to Explorer
          </button>
        </div>
      </div>
    </div>
  );
};
