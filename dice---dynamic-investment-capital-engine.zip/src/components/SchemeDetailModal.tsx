/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive 8-Tab Scheme Detail Modal
 * Grounded in NISM Series V-A & DICE Master Document
 */

import React, { useState } from 'react';
import { MutualFundScheme, DICEScoringResult } from '../types';
import { RiskometerGauge } from './RiskometerGauge';
import {
  X,
  TrendingUp,
  ShieldAlert,
  PieChart,
  Receipt,
  Scale,
  FileText,
  Sliders,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Info,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { useSchemes } from '../context/SchemeContext';

interface SchemeDetailModalProps {
  scheme: MutualFundScheme;
  diceResult?: DICEScoringResult;
  onClose: () => void;
}

type TabType = 'overview' | 'performance' | 'risk' | 'portfolio' | 'cost' | 'tax' | 'suitability' | 'documents';

export const SchemeDetailModal: React.FC<SchemeDetailModalProps> = ({
  scheme,
  diceResult,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const { syncSchemeWithLiveAmfi, isSyncingAmfi } = useSchemes();
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  const handleSyncThisFund = async () => {
    setSyncNotice(null);
    const ok = await syncSchemeWithLiveAmfi(scheme.id);
    if (ok) {
      setSyncNotice('Updated with live AMFI daily NAV and recomputed quantitative ratios.');
      setTimeout(() => setSyncNotice(null), 4000);
    } else {
      setSyncNotice('AMFI feed checked. Using latest verified baseline.');
      setTimeout(() => setSyncNotice(null), 4000);
    }
  };

  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <Info className="w-3.5 h-3.5" /> },
    { id: 'performance', label: 'Performance', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'risk', label: 'Risk & Volatility', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'portfolio', label: 'Portfolio Holdings', icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: 'cost', label: 'Cost & TER', icon: <Receipt className="w-3.5 h-3.5" /> },
    { id: 'tax', label: 'Tax & Exit', icon: <Scale className="w-3.5 h-3.5" /> },
    { id: 'suitability', label: 'DICE Suitability', icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'documents', label: 'SID & Disclosures', icon: <FileText className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] text-slate-900 dark:text-slate-100 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-200 dark:border-[#2E2E38] flex items-start justify-between gap-4 bg-slate-50/50 dark:bg-[#141416]">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
              <span>{scheme.amc}</span>
              <span>·</span>
              <span>{scheme.category}</span>
              <span>·</span>
              <span className="font-mono">{scheme.plan} Plan ({scheme.option})</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
              {scheme.name}
            </h2>
            <div className="flex items-center gap-4 text-xs text-slate-600 dark:text-slate-300 mt-1.5 font-mono">
              <span>NAV: ₹{scheme.nav.toFixed(2)}</span>
              <span>AUM: ₹{(scheme.aumCrores / 1000).toFixed(1)}k Cr</span>
              <span>TER: {scheme.ter}%</span>
              {scheme.code && (
                <button
                  type="button"
                  onClick={handleSyncThisFund}
                  disabled={isSyncingAmfi}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 font-sans text-[11px] font-semibold transition-colors cursor-pointer"
                  title="Fetch live daily NAV from AMFI and recompute ratios"
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncingAmfi ? 'animate-spin' : ''}`} />
                  <span>Sync AMFI</span>
                </button>
              )}
            </div>
            {syncNotice && (
              <div className="mt-2 text-[11px] font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-md border border-emerald-200 dark:border-emerald-800 inline-block animate-fade-in">
                {syncNotice}
              </div>
            )}
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-[#141416] hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shrink-0 cursor-pointer border dark:border-[#2E2E38]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 8 Tabs Header */}
        <div className="border-b border-slate-200 dark:border-[#2E2E38] px-6 bg-white dark:bg-[#1E1E24] overflow-x-auto scrollbar-none flex gap-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-3 px-3 text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                  isActive
                    ? 'border-amber-600 text-slate-950 dark:text-white font-bold'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1 bg-white dark:bg-[#1E1E24]">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Scheme Investment Objective
                </h3>
                <p className="text-sm text-slate-700 leading-relaxed">{scheme.opinion}</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Fund Manager</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">{scheme.fundManager}</div>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Inception Date</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {scheme.inceptionDate} ({scheme.fundAgeYears.toFixed(1)} yrs)
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Benchmark (TRI)</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">{scheme.benchmark}</div>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Min. Investment / SIP</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5 font-mono">
                    ₹{scheme.minInvestment} / ₹{scheme.minSip}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Portfolio Turnover</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5 font-mono">{scheme.turnoverRatio}%</div>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Lock-in Period</span>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">{scheme.lockInPeriod}</div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PERFORMANCE */}
          {activeTab === 'performance' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Historical Return Trajectory</h3>
                  <p className="text-xs text-slate-500">
                    Benchmarked against Total Return Index (TRI) as mandated by SEBI.
                  </p>
                </div>
                <span className="text-xs font-mono bg-slate-100 px-2.5 py-1 rounded-md text-slate-700">
                  500+ Trading Days
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">1-Week</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">
                    {scheme.return1W >= 0 ? `+${scheme.return1W}%` : `${scheme.return1W}%`}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">1-Month</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">
                    {scheme.return1M >= 0 ? `+${scheme.return1M}%` : `${scheme.return1M}%`}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">3-Month</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">
                    {scheme.return3M >= 0 ? `+${scheme.return3M}%` : `${scheme.return3M}%`}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">1-Year CAGR</span>
                  <div className="text-base font-bold text-emerald-700 font-mono mt-0.5">
                    +{scheme.return1Y}%
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">3-Year CAGR</span>
                  <div className="text-base font-bold text-emerald-700 font-mono mt-0.5">
                    {scheme.return3Y ? `+${scheme.return3Y}%` : 'N/A'}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400">5-Year CAGR</span>
                  <div className="text-base font-bold text-emerald-700 font-mono mt-0.5">
                    {scheme.return5Y ? `+${scheme.return5Y}%` : 'N/A'}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 col-span-2">
                  <span className="text-slate-400">Since Inception CAGR</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">
                    +{scheme.returnSinceInception}% p.a.
                  </div>
                </div>
              </div>

              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-4 text-xs text-amber-900">
                <span className="font-bold">NISM Compliance Note: </span>
                Past performance is not an indicator of future returns. 3-Year and 5-Year returns are compounded annual growth rates (CAGR).
              </div>
            </div>
          )}

          {/* TAB 3: RISK */}
          {activeTab === 'risk' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="space-y-1 text-center sm:text-left">
                  <h3 className="text-sm font-bold text-slate-900">SEBI Pictorial Riskometer</h3>
                  <p className="text-xs text-slate-500 max-w-sm">
                    Categorizes the risk to principal at one of six standardized tiers as per SEBI regulations.
                  </p>
                </div>
                <RiskometerGauge level={scheme.riskometer} size="md" />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Standard Deviation</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">
                    {scheme.standardDeviation}%
                  </div>
                  <span className="text-[10px] text-slate-400">Total Volatility</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Beta</span>
                  <div className="text-base font-bold text-slate-900 font-mono mt-0.5">{scheme.beta}</div>
                  <span className="text-[10px] text-slate-400">Market Sensitivity</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Sharpe Ratio</span>
                  <div className="text-base font-bold text-emerald-700 font-mono mt-0.5">
                    {scheme.sharpeRatio}
                  </div>
                  <span className="text-[10px] text-slate-400">Risk-Adjusted Return</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 uppercase font-semibold">Max Drawdown</span>
                  <div className="text-base font-bold text-rose-700 font-mono mt-0.5">
                    {scheme.maxDrawdown}%
                  </div>
                  <span className="text-[10px] text-slate-400">Peak-to-Trough Drop</span>
                </div>
              </div>

              {scheme.modifiedDuration && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 text-xs">
                  <span className="font-bold text-slate-900">Debt Specific Duration Metrics: </span>
                  <span className="font-mono text-slate-700">
                    Modified Duration: {scheme.modifiedDuration} yrs · Average Maturity: {scheme.averageMaturity} yrs · Credit Profile: {scheme.creditQualityProfile}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PORTFOLIO */}
          {activeTab === 'portfolio' && (
            <div className="space-y-6">
              {/* Asset Allocation Split */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Asset Class Allocation
                </h3>
                <div className="w-full bg-slate-100 h-4 rounded-full flex overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full"
                    style={{ width: `${scheme.equityAllocation}%` }}
                    title={`Equity: ${scheme.equityAllocation}%`}
                  />
                  <div
                    className="bg-blue-600 h-full"
                    style={{ width: `${scheme.debtAllocation}%` }}
                    title={`Debt: ${scheme.debtAllocation}%`}
                  />
                  <div
                    className="bg-amber-500 h-full"
                    style={{ width: `${scheme.goldAllocation}%` }}
                    title={`Gold: ${scheme.goldAllocation}%`}
                  />
                  <div
                    className="bg-slate-400 h-full"
                    style={{ width: `${scheme.cashAllocation}%` }}
                    title={`Cash/TREPS: ${scheme.cashAllocation}%`}
                  />
                </div>
                <div className="flex items-center gap-4 text-xs mt-2 font-mono text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600" />
                    Equity: {scheme.equityAllocation}%
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    Debt: {scheme.debtAllocation}%
                  </span>
                  {scheme.goldAllocation > 0 && (
                    <span className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      Gold: {scheme.goldAllocation}%
                    </span>
                  )}
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-slate-400" />
                    Cash: {scheme.cashAllocation}%
                  </span>
                </div>
              </div>

              {/* Top Holdings Table */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Top 5 Scheme Holdings
                </h3>
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-4">Company / Asset</th>
                        <th className="py-2.5 px-4">Sector / Instrument</th>
                        <th className="py-2.5 px-4 text-right">Weight (%)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {scheme.topHoldings.map((h, i) => (
                        <tr key={i} className="hover:bg-slate-50/50">
                          <td className="py-2.5 px-4 font-semibold text-slate-900">{h.company}</td>
                          <td className="py-2.5 px-4 text-slate-600">{h.sector}</td>
                          <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900">
                            {h.weightage}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Sector Allocations */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Sector Allocations
                </h3>
                <div className="space-y-2">
                  {scheme.sectorAllocations.map((s, i) => (
                    <div key={i} className="text-xs">
                      <div className="flex justify-between text-slate-700 mb-1">
                        <span>{s.sector}</span>
                        <span className="font-mono font-bold">{s.weightage}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-slate-800 h-1.5 rounded-full" style={{ width: `${s.weightage}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: COST */}
          {activeTab === 'cost' && (
            <div className="space-y-6 text-xs">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
                <div>
                  <span className="text-slate-400 uppercase font-semibold">Total Expense Ratio (TER)</span>
                  <div className="text-2xl font-black text-slate-900 font-mono mt-0.5">{scheme.ter}% p.a.</div>
                  <p className="text-slate-500 mt-1">
                    Direct plan expense ratio excluding distributor trail commissions as mandated by SEBI Regulations.
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-200">
                  <span className="text-slate-400 uppercase font-semibold">Exit Load Structure</span>
                  <div className="text-sm font-semibold text-slate-800 mt-0.5">{scheme.exitLoad}</div>
                </div>

                <div className="pt-3 border-t border-slate-200">
                  <span className="text-slate-400 uppercase font-semibold">SEBI Stamp Duty</span>
                  <div className="text-slate-700 mt-0.5">
                    0.005% applicable at the time of unit issuance (both physical & demat).
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: TAX */}
          {activeTab === 'tax' && (
            <div className="space-y-5 text-xs">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                  <Scale className="w-4 h-4 text-amber-600" />
                  <span>Taxation Rules for {scheme.name}</span>
                </div>
                <div className="text-slate-500 font-medium">
                  Tax Classification: <span className="font-bold text-slate-800">{scheme.taxClassification}</span>
                </div>

                {scheme.taxClassification === 'Equity-Oriented' ? (
                  <div className="space-y-2 text-slate-700">
                    <p>
                      <strong>Holding Period:</strong> 12 months for Long-Term Capital Gains (LTCG).
                    </p>
                    <p>
                      <strong>Short-Term Capital Gains (STCG &lt; 12 mo):</strong> Taxed at <strong>20%</strong> (as updated in Union Budget 2024).
                    </p>
                    <p>
                      <strong>Long-Term Capital Gains (LTCG &gt; 12 mo):</strong> Taxed at <strong>12.5%</strong> on gains exceeding ₹1.25 Lakhs per financial year.
                    </p>
                    <p>
                      <strong>Securities Transaction Tax (STT):</strong> 0.001% payable on redemption.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 text-slate-700">
                    <p>
                      <strong>Debt Fund Taxation (Finance Act 2023 amendment):</strong>
                    </p>
                    <p>
                      Gains are treated as short-term capital gains irrespective of holding period and taxed at the investor's <strong>Marginal Slab Rate (MSR)</strong>.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 7: SUITABILITY */}
          {activeTab === 'suitability' && (
            <div className="space-y-5 text-xs">
              {diceResult ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="font-bold text-slate-900 text-sm">
                      DICE Total Match Score: {diceResult.totalScore}/100 ({diceResult.matchLabel})
                    </div>
                    <p className="text-slate-500 mt-0.5">
                      Deterministic suitability score calculated via 5 weighted dimensions.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-2">Exact Criteria Matches:</h4>
                    <ul className="space-y-1.5 text-slate-700">
                      {diceResult.exactMatches.map((em, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{em}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {diceResult.mismatches.length > 0 && (
                    <div>
                      <h4 className="font-bold text-amber-900 mb-2">Identified Constraints / Mismatches:</h4>
                      <ul className="space-y-1.5 text-slate-700">
                        {diceResult.mismatches.map((mm, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                            <span>{mm}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-slate-500">
                  Take the 20-Question Behavioral Profiler to generate your personalized DICE suitability scorecard for this fund.
                </p>
              )}
            </div>
          )}

          {/* TAB 8: DOCUMENTS */}
          {activeTab === 'documents' && (
            <div className="space-y-4 text-xs">
              <p className="text-slate-600 leading-relaxed">
                As per SEBI regulations, every investor is presumed to have read and accepted the Scheme Information Document (SID), Key Information Memorandum (KIM), and Statement of Additional Information (SAI) before subscribing.
              </p>

              <div className="space-y-2">
                <a
                  href={scheme.sidLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-white flex items-center justify-between text-slate-900 font-semibold transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-amber-600" />
                    <span>Scheme Information Document (SID)</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                </a>

                <a
                  href={scheme.kimLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-white flex items-center justify-between text-slate-900 font-semibold transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-amber-600" />
                    <span>Key Information Memorandum (KIM)</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                </a>

                {/* Pipeline Provenance & Audit Card */}
                <div className="mt-4 p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-2">
                  <div className="flex items-center justify-between text-emerald-950 font-bold">
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-700" />
                      <span>Data Provenance & Validation Audit</span>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 font-bold">
                      Verified Official Feed
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-emerald-900 pt-1">
                    <div>
                      <span className="text-emerald-700 font-semibold">Source Feeds: </span>
                      <span>AMFI Official Daily (NAVAll.txt) & TIGZIG SSD</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 font-semibold">Data As-Of Date: </span>
                      <span>{scheme.navDate || '04-Nov-2026'}</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 font-semibold">Inception Return Kind: </span>
                      <span>Annualized CAGR (&gt;1 Year History)</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 font-semibold">Star Rating Status: </span>
                      <span>
                        {scheme.rating && scheme.rating > 0
                          ? `Identifiable Licensed Agency (★${scheme.rating}.0)`
                          : 'Data unavailable (Excluded without identifiable rating license)'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Close Analysis
          </button>
        </div>
      </div>
    </div>
  );
};
