/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Welcome & Educational Disclaimer Modal displayed on website entry
 * Features smooth popup animation, mandatory checkbox confirmation,
 * and direct link to DICE – Website Disclaimer on "disclaimer and acknowledgement."
 */

import React, { useState, useEffect } from 'react';
import { AlertTriangle, ExternalLink, ArrowRight } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface EducationalDisclaimerModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  onNavigateToDisclaimer?: () => void;
}

const STORAGE_KEY = 'dice_educational_disclaimer_accepted_v1';

export const EducationalDisclaimerModal: React.FC<EducationalDisclaimerModalProps> = ({
  isOpen: controlledIsOpen,
  onClose: controlledOnClose,
  onNavigateToDisclaimer,
}) => {
  const { isTamil } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [isAcknowledged, setIsAcknowledged] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (controlledIsOpen !== undefined) {
      setIsOpen(controlledIsOpen);
      return;
    }
    // Check session storage on initial website entry
    try {
      const accepted = sessionStorage.getItem(STORAGE_KEY);
      if (!accepted) {
        setIsOpen(true);
      }
    } catch {
      setIsOpen(true);
    }
  }, [controlledIsOpen]);

  const handleAccept = () => {
    if (!isAcknowledged || isExiting) return;

    // Trigger smooth exit transition animation before closing
    setIsExiting(true);
    setTimeout(() => {
      try {
        sessionStorage.setItem(STORAGE_KEY, 'true');
      } catch {
        // ignore
      }
      setIsOpen(false);
      setIsExiting(false);
      if (controlledOnClose) {
        controlledOnClose();
      }
    }, 280);
  };

  const handleOpenDisclaimerPage = () => {
    setIsOpen(false);
    if (onNavigateToDisclaimer) {
      onNavigateToDisclaimer();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto transition-opacity duration-300 ${
        isExiting ? 'opacity-0' : 'opacity-100 animate-in fade-in duration-200'
      }`}
    >
      <div
        className={`bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] text-slate-900 dark:text-slate-100 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh] transition-all duration-300 transform ${
          isExiting ? 'scale-95 opacity-0' : 'scale-100 opacity-100 animate-in zoom-in-95 duration-200'
        }`}
      >
        {/* Header matching Welcome to DICE */}
        <div className="bg-linear-to-r from-amber-500/15 via-amber-500/10 to-transparent border-b border-amber-200/80 dark:border-[#2E2E38] px-6 py-5 flex items-center gap-3.5">
          <img
            src="/assets/aistudio/Logo_DICE__1_-removebg-preview_f2e8a9ea.png"
            alt="DICE"
            className="w-10 h-10 object-contain drop-shadow-sm shrink-0"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/assets/aistudio/Logo_DICE__1__09a2a920.png';
            }}
          />
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-tight">
              {isTamil ? 'DICE-க்கு நல்வரவு' : 'Welcome to DICE'}
            </h2>
            <p className="text-xs sm:text-sm font-bold text-amber-700 dark:text-amber-400 mt-0.5">
              {isTamil ? 'டைனமிக் முதலீட்டு மூலதன இயந்திரம்' : 'Dynamic Investment Capital Engine'}
            </p>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 space-y-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed overflow-y-auto max-h-[58vh] scrollbar-thin">
          <p className="font-semibold text-slate-800 dark:text-slate-100 text-[13px] leading-relaxed">
            {isTamil
              ? 'DICE என்பது மனித யோசனைகள், AI தொழில்நுட்பம், நிதி ஆராய்ச்சி மற்றும் NISM Series V-A Mutual Fund Distributors பாடத்திட்டத்தின் கருத்துக்களின் கலவையின் மூலம் உருவாக்கப்பட்ட ஒரு சுயாதீன, AI-உதவி பக்கத் திட்டமாகும்.'
              : 'DICE is an independent, AI-assisted side project developed through a combination of human ideas, AI technology, financial research and concepts from the NISM Series V-A Mutual Fund Distributors curriculum.'}
          </p>

          <p className="text-slate-600 dark:text-slate-300">
            {isTamil
              ? 'இந்த தளம் கல்வி, தகவல் மற்றும் கல்விசார் ஆராய்ச்சி நோக்கங்களுக்காக மட்டுமே உருவாக்கப்பட்டது.'
              : 'This platform is created solely for educational, informational and academic demonstration purposes.'}
          </p>

          {/* Bulleted Points */}
          <ul className="space-y-2.5 pt-1 pl-1 text-slate-700 dark:text-slate-200">
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
              <span>
                {isTamil
                  ? 'DICE செபி (SEBI), AMFI, NISM அல்லது எந்தவொரு பரஸ்பர நிதி நிறுவனத்துடனும் இணைக்கப்படவில்லை அல்லது அங்கீகரிக்கப்படவில்லை.'
                  : 'DICE is not affiliated with or endorsed by SEBI, AMFI, NISM or any Asset Management Company.'}
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
              <span>
                {isTamil
                  ? 'DICE ஒரு செபி-பதிவு செய்யப்பட்ட முதலீட்டு ஆலோசகர், ஆராய்ச்சி ஆய்வாளர் அல்லது பரஸ்பர நிதி விநியோகஸ்தர் அல்ல.'
                  : 'DICE is not a SEBI-registered Investment Adviser, Research Analyst or Mutual Fund Distributor.'}
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
              <span>
                {isTamil
                  ? 'எந்தவொரு முதலீட்டு ஆலோசனையோ, திட்டப் பரிந்துரைகளோ அல்லது விளம்பரச் சேவைகளோ வழங்கப்படவில்லை.'
                  : 'No investment advice, scheme recommendations or promotional services are offered.'}
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
              <span>
                {isTamil
                  ? 'தரவு மற்றும் AI-உருவாக்கிய நுண்ணறிவுகளில் தவறுகள், விடுபடல்கள் அல்லது காலாவதியான தகவல்கள் இருக்கலாம். உத்தியோகபூர்வ ஆதாரங்கள் மூலம் சுயாதீன சரிபார்ப்பு அவசியம்.'
                  : 'Data and AI-generated insights may contain inaccuracies, omissions or outdated information. Independent verification through official sources is essential.'}
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
              <span>
                {isTamil
                  ? 'கணக்கீடுகள், ஒப்பீடுகள் மற்றும் வரலாற்று செயல்திறன் விளக்க நோக்கங்களுக்காக மட்டுமே மற்றும் எதிர்கால வருமானத்திற்கு உத்தரவாதம் அளிக்காது.'
                  : 'Calculators, comparisons and historical performance are illustrative and do not guarantee future returns.'}
              </span>
            </li>
          </ul>

          {/* Highlighted Risk Disclosure */}
          <div className="bg-amber-500/10 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-700/50 rounded-2xl p-4 flex items-start gap-3 text-amber-950 dark:text-amber-200 mt-3">
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <strong>{isTamil ? 'அபாய வெளிப்பாடு:' : 'Risk Disclosure:'}</strong>{' '}
              {isTamil
                ? 'பரஸ்பர நிதி முதலீடுகள் சந்தை அபாயங்களுக்கு உட்பட்டவை. முதலீடு செய்வதற்கு முன் அனைத்து திட்டம் தொடர்பான ஆவணங்களையும் கவனமாக படிக்கவும்.'
                : 'Mutual fund investments are subject to market risks. Read all scheme-related documents carefully before investing.'}
            </div>
          </div>

          {/* Acknowledgement Statement */}
          <div className="pt-2 border-t border-slate-100 dark:border-[#2E2E38] space-y-1.5">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white tracking-tight">
              {isTamil ? 'ஒப்புதல்' : 'Acknowledgement'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {isTamil
                ? 'DICE தளத்திற்குள் நுழைவதன் மூலம், மேலே உள்ள மறுப்புரையை நான் படித்து புரிந்து கொண்டதாக ஒப்புக்கொள்கிறேன். இது ஒரு சுயாதீன கல்வித் திட்டம் என்பதையும், எந்தவொரு நிதி அல்லது முதலீட்டு முடிவுகளும் எனது சொந்தப் பொறுப்பு என்பதையும் நான் புரிந்துகொள்கிறேன்.'
                : 'By entering DICE, I acknowledge that I have read and understood the above disclaimer. I understand that this is an independent educational project and that any financial or investment decisions remain my sole responsibility.'}
            </p>
          </div>
        </div>

        {/* Checkbox Confirmation & Enter Action */}
        <div className="bg-slate-50 dark:bg-[#141416] border-t border-slate-200 dark:border-[#2E2E38] px-6 py-4 space-y-3.5">
          <label
            htmlFor="dice-disclaimer-consent"
            className="flex items-start gap-3 cursor-pointer group select-none bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] hover:border-amber-300 dark:hover:border-amber-600 rounded-xl p-3.5 transition-colors shadow-2xs"
          >
            <input
              type="checkbox"
              id="dice-disclaimer-consent"
              checked={isAcknowledged}
              onChange={(e) => setIsAcknowledged(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-amber-600 border-slate-300 dark:border-slate-700 focus:ring-amber-500 cursor-pointer shrink-0 accent-amber-600"
            />
            <span className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
              {isTamil ? (
                <>
                  நான்{' '}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenDisclaimerPage();
                    }}
                    className="text-amber-700 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-300 font-extrabold underline underline-offset-2 inline-flex items-center gap-1 cursor-pointer"
                    title="முழு DICE மறுப்புரையை காண்க"
                  >
                    <span>மறுப்புரை மற்றும் ஒப்புதலை</span>
                    <ExternalLink className="w-3.5 h-3.5 inline text-amber-600 dark:text-amber-400" />
                  </button>{' '}
                  படித்துப் புரிந்து கொண்டேன்.
                </>
              ) : (
                <>
                  I have read and understood the{' '}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenDisclaimerPage();
                    }}
                    className="text-amber-700 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-300 font-extrabold underline underline-offset-2 inline-flex items-center gap-1 cursor-pointer"
                    title="View full DICE – Website Disclaimer"
                  >
                    <span>disclaimer and acknowledgement</span>
                    <ExternalLink className="w-3.5 h-3.5 inline text-amber-600 dark:text-amber-400" />
                  </button>
                  .
                </>
              )}
            </span>
          </label>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
            <span className="text-[11px] text-slate-400 dark:text-slate-500 font-mono text-center sm:text-left">
              {isAcknowledged
                ? isTamil
                  ? 'DICE தளத்தை ஆராயத் தயார்'
                  : 'Ready to explore DICE'
                : isTamil
                ? 'தொடர மேலே உள்ள பெட்டியை சரிபார்க்கவும்'
                : 'Please check the box above to continue'}
            </span>
            <button
              type="button"
              onClick={handleAccept}
              disabled={!isAcknowledged}
              className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 flex items-center justify-center gap-2 shadow-xs ${
                isAcknowledged
                  ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer hover:shadow-md active:scale-98'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed opacity-75'
              }`}
            >
              <span>{isTamil ? 'DICE தளத்திற்குள் நுழையவும்' : 'Enter DICE Platform'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
