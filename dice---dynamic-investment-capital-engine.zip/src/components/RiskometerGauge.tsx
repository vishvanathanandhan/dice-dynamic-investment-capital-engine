/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SEBI Official 6-Level Riskometer Component
 * Colors specified in NISM Series V-A Chapter 5 (pg 109)
 */

import React from 'react';
import { RiskLevel } from '../types';

interface RiskometerProps {
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

const RISK_LEVELS: { label: RiskLevel; color: string; angle: number }[] = [
  { label: 'Low', color: '#08A04B', angle: 15 },
  { label: 'Low to Moderate', color: '#7FFF00', angle: 45 },
  { label: 'Moderate', color: '#FFFF33', angle: 75 },
  { label: 'Moderately High', color: '#C68E17', angle: 105 },
  { label: 'High', color: '#FF8C00', angle: 135 },
  { label: 'Very High', color: '#F70D1A', angle: 165 },
];

export const RiskometerGauge: React.FC<RiskometerProps> = ({
  level,
  size = 'md',
  showLabel = true,
}) => {
  const currentRisk = RISK_LEVELS.find((r) => r.label === level) || RISK_LEVELS[2];
  
  // Dimensions
  const dimensions = {
    sm: { width: 140, height: 80, stroke: 12, needleLen: 38 },
    md: { width: 220, height: 120, stroke: 16, needleLen: 62 },
    lg: { width: 300, height: 160, stroke: 22, needleLen: 85 },
  }[size];

  // Semicircle arc rendering
  const radius = dimensions.width / 2 - dimensions.stroke;
  const cx = dimensions.width / 2;
  const cy = dimensions.height + (size === 'sm' ? -10 : -15);

  // Needle angle: 180 degrees map to -90 to +90
  const needleRotation = currentRisk.angle - 90;

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: dimensions.width, height: dimensions.height }}>
        <svg
          viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
          className="w-full h-full overflow-visible"
        >
          {/* Segments of the arch */}
          {RISK_LEVELS.map((r, i) => {
            const startAngle = (180 / 6) * i;
            const endAngle = (180 / 6) * (i + 1);
            
            // Polar coordinates for arc segment
            const startRad = (Math.PI / 180) * (180 + startAngle);
            const endRad = (Math.PI / 180) * (180 + endAngle);
            
            const x1 = cx + radius * Math.cos(startRad);
            const y1 = cy + radius * Math.sin(startRad);
            const x2 = cx + radius * Math.cos(endRad);
            const y2 = cy + radius * Math.sin(endRad);

            return (
              <path
                key={r.label}
                d={`M ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2}`}
                fill="none"
                stroke={r.color}
                strokeWidth={dimensions.stroke}
                className="transition-opacity duration-300 hover:opacity-80"
              />
            );
          })}

          {/* Needle */}
          <g transform={`translate(${cx}, ${cy}) rotate(${needleRotation})`}>
            <polygon
              points={`-3,0 0,-${dimensions.needleLen} 3,0`}
              fill="#1E293B"
              className="drop-shadow-sm transition-transform duration-500 ease-out dark:fill-slate-100"
            />
            <circle cx="0" cy="0" r={size === 'sm' ? 4 : 6} fill="#0F172A" className="dark:fill-slate-200" />
            <circle cx="0" cy="0" r={size === 'sm' ? 2 : 3} fill="#FFFFFF" className="dark:fill-[#141416]" />
          </g>
        </svg>
      </div>

      {showLabel && (
        <div className="mt-2 text-center">
          <div className="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 font-medium">SEBI Riskometer</div>
          <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center justify-center gap-1.5 mt-0.5">
            <span
              className="inline-block w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: currentRisk.color }}
            />
            <span>{currentRisk.label} Risk</span>
          </div>
        </div>
      )}
    </div>
  );
};

