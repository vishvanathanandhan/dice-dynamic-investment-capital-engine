/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Hero Section matching the UI/UX Reference PDF with 3 Curated Category Cards
 */

import React, { useState, useEffect } from 'react';
import { Search, TrendingUp, ShieldCheck, Banknote, ArrowRight, FileSpreadsheet, Loader2 } from 'lucide-react';
import { useSchemes } from '../context/SchemeContext';
import { MutualFundScheme } from '../types';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';
import { useLanguage } from '../context/LanguageContext';

interface HeroCardsProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectCategoryFilter: (categoryFilter: 'wealth' | 'tax' | 'income') => void;
  onStartProfiler: () => void;
  onOpenUploadModal: () => void;
  onOpenAmfiModal?: () => void;
  onSelectScheme?: (scheme: MutualFundScheme) => void;
  onAnalyzeScheme?: (scheme: MutualFundScheme) => void;
}

export const HeroCards: React.FC<HeroCardsProps> = ({
  searchQuery,
  onSearchChange,
  onSelectCategoryFilter,
  onStartProfiler,
  onOpenUploadModal,
  onSelectScheme,
  onAnalyzeScheme,
}) => {
  const { t, isTamil } = useLanguage();
  const { schemes, uploadedCount } = useSchemes();
  const [pipelineResults, setPipelineResults] = useState<MutualFundScheme[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [totalFound, setTotalFound] = useState(0);

  // Category counts from 11,434 pipeline
  const [equityCount, setEquityCount] = useState<number>(3173);
  const [elssCount, setElssCount] = useState<number>(237);
  const [debtCount, setDebtCount] = useState<number>(3009);

  // Fetch pipeline counts once on mount
  useEffect(() => {
    let isMounted = true;
    fetch('/api/pipeline/stats')
      .then((res) => res.json())
      .then((data) => {
        if (isMounted && data?.success && data?.data) {
          // If totalSchemes exists, update baseline
          const stats = data.data;
          if (stats.activeSchemes > 0) {
            // Stats loaded
          }
        }
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, []);

  // Search pipeline across all 11,000+ mutual fund schemes with 200ms debounce
  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setPipelineResults([]);
      setTotalFound(0);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const handler = setTimeout(async () => {
      try {
        const res = await fetch(`/api/pipeline/schemes?search=${encodeURIComponent(q)}&limit=12`);
        const json = await res.json();
        if (json.success && json.data) {
          const fetchedSchemes: MutualFundScheme[] = (json.data.schemes || []).map(
            (rec: NormalizedSchemeRecord) => normalizeToMutualFundScheme(rec)
          );

          // Also prepend matching uploaded custom schemes
          const qLower = q.toLowerCase();
          const customMatches = schemes.filter(
            (s) =>
              (s.id.startsWith('uploaded_') || s.isUploaded) &&
              (s.name.toLowerCase().includes(qLower) ||
                s.amc.toLowerCase().includes(qLower) ||
                s.category.toLowerCase().includes(qLower))
          );

          setPipelineResults([...customMatches, ...fetchedSchemes]);
          setTotalFound((json.data.total || 0) + customMatches.length);
        }
      } catch (err) {
        console.error('Failed to search pipeline schemes:', err);
      } finally {
        setIsSearching(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [searchQuery, schemes]);

  return (
    <section className="pt-8 pb-10 border-b border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Title & Subtitle */}
        <div className="max-w-3xl mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-2 flex-wrap">
            <span>DICE Capital Engine</span>
            <span>·</span>
            <span>11,000+ Verified Schemes Database</span>
            {uploadedCount > 0 && (
              <>
                <span>·</span>
                <span className="text-emerald-700 dark:text-emerald-400 font-bold">{uploadedCount} Custom Schemes Loaded</span>
              </>
            )}
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
            {t('hero.title', 'Intelligent Mutual Fund Discovery & Behavioral Profiling')}
          </h1>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t('hero.subtitle', 'Grounded in verified regulatory filings and quantitative multi-factor modeling across 11,000+ mutual fund schemes in India.')}
          </p>
        </div>

        {/* Global Search Bar & Upload CTA */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 max-w-3xl mb-10">
          <div className="relative flex-1">
            <Search className="absolute left-4 w-5 h-5 text-slate-400 dark:text-slate-500 pointer-events-none top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={t('hero.search_placeholder', 'Search across 11,000+ schemes by name, category, or AMC...')}
              className="w-full pl-12 pr-10 py-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100/70 dark:hover:bg-slate-750 focus:bg-white dark:focus:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all shadow-xs"
            />
            {isSearching && (
              <Loader2 className="w-4 h-4 text-amber-600 dark:text-amber-400 animate-spin absolute right-3.5 top-4" />
            )}

            {searchQuery.trim().length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-[#1E1E24] rounded-2xl shadow-xl border border-slate-200 dark:border-[#2E2E38] z-50 overflow-hidden max-h-96 overflow-y-auto">
                <div className="p-3 bg-slate-50 dark:bg-[#141416] border-b border-slate-200 dark:border-[#2E2E38] flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold">
                  <span>
                    {isSearching ? (t('common.loading', 'Searching database...')) : isTamil ? `${totalFound.toLocaleString('en-IN')} திட்டங்கள் கண்டறியப்பட்டது` : `${totalFound.toLocaleString('en-IN')} matching schemes found`}
                  </span>
                  <button
                    onClick={() => onSearchChange('')}
                    className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 text-xs cursor-pointer font-medium"
                  >
                    {isTamil ? 'தேடலை அழி' : 'Clear search'}
                  </button>
                </div>
                {!isSearching && pipelineResults.length === 0 ? (
                  <div className="p-6 text-center text-sm text-slate-500 dark:text-slate-400">
                    {isTamil ? `"${searchQuery}" உடன் பொருந்தும் திட்டங்கள் 11,000+ தரவுத்தளத்தில் இல்லை.` : `No mutual fund schemes match "${searchQuery}" in the 11,000+ database.`}
                    <div className="mt-2">
                      <button
                        onClick={onOpenUploadModal}
                        className="text-emerald-700 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
                      >
                        {isTamil ? 'Excel / CSV கோப்பை பதிவேற்றி' : 'Upload your Excel / CSV file'}
                      </button>{' '}
                      {isTamil ? 'இத்திட்டத்தை இணைக்கவும்.' : 'to include this scheme.'}
                    </div>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                    {pipelineResults.map((scheme) => (
                      <div
                        key={scheme.id}
                        className="p-3.5 hover:bg-amber-50/50 dark:hover:bg-[#282830] flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                              {scheme.amc}
                            </span>
                            <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-[#141416] text-slate-600 dark:text-slate-300 border dark:border-[#2E2E38]">
                              {scheme.category}
                            </span>
                            <span className="text-xs font-mono text-emerald-700 dark:text-emerald-400 font-bold">
                              1Y: {scheme.return1Y > 0 ? `+${scheme.return1Y}%` : `${scheme.return1Y}%`}
                            </span>
                            {scheme.plan && (
                              <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-200/70 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                {scheme.plan}
                              </span>
                            )}
                          </div>
                          <div className="text-sm font-bold text-slate-900 dark:text-white truncate mt-0.5">
                            {scheme.name}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            NAV: ₹{scheme.nav ? scheme.nav.toFixed(2) : 'N/A'} · AUM: ₹{scheme.aumCrores ? scheme.aumCrores.toLocaleString('en-IN') : '0'} Cr · TER: {scheme.ter ? `${scheme.ter}%` : 'Data unavailable'}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {onSelectScheme && (
                            <button
                              onClick={() => {
                                onSelectScheme(scheme);
                                onSearchChange('');
                              }}
                              className="px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-[#141416] hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer border dark:border-[#2E2E38]"
                            >
                              {t('common.view_details', 'View Details')}
                            </button>
                          )}
                          {onAnalyzeScheme && (
                            <button
                              onClick={() => {
                                onAnalyzeScheme(scheme);
                                onSearchChange('');
                              }}
                              className="px-3 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition-colors cursor-pointer"
                            >
                              {isTamil ? 'பகுப்பாய்வு (20Q)' : 'Analyze (20Q)'}
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            onClick={onOpenUploadModal}
            className="px-4 py-3 bg-emerald-50 dark:bg-[#1E1E24] hover:bg-emerald-100 dark:hover:bg-[#282830] border border-emerald-300 dark:border-emerald-700/60 text-emerald-900 dark:text-emerald-300 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shrink-0 shadow-xs cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>{t('wealth.import_excel', 'Upload Scheme Excel')}</span>
          </button>
        </div>

        {/* 3 Core Curated Solution Cards (From PDF Page 1) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Funds to grow wealth */}
          <div
            onClick={() => onSelectCategoryFilter('wealth')}
            className="group cursor-pointer bg-[#FDFBF7] dark:bg-[#1E1E24] hover:bg-[#FAF6EC] dark:hover:bg-[#25252D] border border-[#F1E5D1] dark:border-[#2E2E38] rounded-2xl p-6 transition-all duration-200 hover:shadow-md flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-400 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono font-bold text-amber-900 dark:text-amber-300 bg-amber-100/60 dark:bg-amber-950/50 px-2 py-0.5 rounded-md">
                  {equityCount.toLocaleString('en-IN')}+ Funds
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
                {t('card.wealth.title', 'Funds to grow wealth')}
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t('card.wealth.desc', 'Diversified equity funds suitable to form the core of all long-term wealth creation portfolios with inflation-beating compounding.')}
              </p>
            </div>
            <div className="mt-5 flex items-center gap-1.5 text-xs font-semibold text-amber-800 dark:text-amber-400 group-hover:translate-x-1 transition-transform">
              <span>{t('card.wealth.title', 'View Wealth Builder Funds')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 2: Funds to save tax */}
          <div
            onClick={() => onSelectCategoryFilter('tax')}
            className="group cursor-pointer bg-[#F8FAF9] dark:bg-[#1E1E24] hover:bg-[#F0F6F3] dark:hover:bg-[#25252D] border border-[#D7E8DE] dark:border-[#2E2E38] rounded-2xl p-6 transition-all duration-200 hover:shadow-md flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono font-bold text-emerald-900 dark:text-emerald-300 bg-emerald-100/60 dark:bg-emerald-950/50 px-2 py-0.5 rounded-md">
                  {elssCount.toLocaleString('en-IN')}+ ELSS Funds
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
                {t('card.tax.title', 'Funds to save tax')}
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t('card.tax.desc', 'Equity-linked savings schemes (ELSS) offering Section 80C tax deductions under Old Regime with the shortest 3-year statutory lock-in.')}
              </p>
            </div>
            <div className="mt-5 flex items-center gap-1.5 text-xs font-semibold text-emerald-800 dark:text-emerald-400 group-hover:translate-x-1 transition-transform">
              <span>{t('card.tax.title', 'View ELSS Tax Savers')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 3: Funds to get regular income */}
          <div
            onClick={() => onSelectCategoryFilter('income')}
            className="group cursor-pointer bg-[#F8FAFC] dark:bg-[#1E1E24] hover:bg-[#F1F5F9] dark:hover:bg-[#25252D] border border-[#E2E8F0] dark:border-[#2E2E38] rounded-2xl p-6 transition-all duration-200 hover:shadow-md flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-400 flex items-center justify-center">
                  <Banknote className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono font-bold text-blue-900 dark:text-blue-300 bg-blue-100/60 dark:bg-blue-950/50 px-2 py-0.5 rounded-md">
                  {debtCount.toLocaleString('en-IN')}+ Income Funds
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 transition-colors">
                {t('card.income.title', 'Funds to get regular income')}
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t('card.income.desc', 'Conservative hybrid, debt funds and systematic withdrawal plan (SWP) setups designed to provide steady cashflow and low volatility.')}
              </p>
            </div>
            <div className="mt-5 flex items-center gap-1.5 text-xs font-semibold text-blue-800 dark:text-blue-400 group-hover:translate-x-1 transition-transform">
              <span>{t('card.income.title', 'View Regular Income Funds')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Callout to 20-Question Behavioral Diagnostic */}
        <div className="mt-8 bg-linear-to-r from-slate-900 to-slate-800 dark:from-[#1E1E24] dark:to-[#141416] border border-slate-700/50 dark:border-[#2E2E38] rounded-2xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md">
          <div className="max-w-2xl">
            <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
              {isTamil ? 'DICE பிரத்தியேக பொருத்தம் பகுப்பாய்வு' : 'DICE Proprietary Suitability Diagnostic'}
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold mt-1 text-white">
              {t('quest.title', 'Investor Suitability & Behavioral Diagnostic')}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              {t('quest.subtitle', 'Evaluates emotional biases and financial holdings to recommend up to 3 verified schemes.')}
            </p>
          </div>
          <button
            onClick={onStartProfiler}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-sm hover:shadow-md shrink-0 flex items-center gap-2 cursor-pointer"
          >
            <span>{t('hero.start_profiler', 'Take 20Q Assessment')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
