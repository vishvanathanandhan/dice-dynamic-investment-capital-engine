/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SchemeUploadModal: Upload Excel/CSV files, inspect column specs, download sample templates,
 * and link imported schemes across all sections in real-time.
 */

import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Layers,
  ArrowRight,
  RefreshCw,
  Trash2
} from 'lucide-react';
import {
  parseUploadedSchemeFile,
  generateSampleExcelFile,
  generateSampleCsvFile,
  SCHEME_COLUMNS_SPEC
} from '../utils/schemeParser';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import { MutualFundScheme } from '../types';

interface SchemeUploadModalProps {
  onClose: () => void;
}

export const SchemeUploadModal: React.FC<SchemeUploadModalProps> = ({ onClose }) => {
  const { addUploadedSchemes, uploadedCount, resetToDefaults } = useSchemes();
  const { isTamil } = useLanguage();
  const [dragActive, setDragActive] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [previewSchemes, setPreviewSchemes] = useState<MutualFundScheme[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [importSuccessMessage, setImportSuccessMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(extension || '')) {
      setParseError('Please upload a valid Excel (.xlsx, .xls) or CSV (.csv) file.');
      return;
    }

    setFileName(file.name);
    setParseError(null);
    setValidationErrors([]);
    setImportSuccessMessage(null);
    setParsing(true);

    try {
      const result = await parseUploadedSchemeFile(file);
      if (result.errors.length > 0) {
        setValidationErrors(result.errors);
      }
      if (result.schemes.length === 0) {
        setParseError('No valid scheme records found in this file. Please check column headers.');
      } else {
        setPreviewSchemes(result.schemes);
      }
    } catch (err: any) {
      setParseError(err.message || 'Failed to parse file.');
    } finally {
      setParsing(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleConfirmImport = () => {
    if (previewSchemes.length === 0) return;
    addUploadedSchemes(previewSchemes, importMode === 'replace');
    setImportSuccessMessage(
      `Successfully integrated ${previewSchemes.length} schemes into the active universe (${importMode === 'replace' ? 'replaced existing' : 'appended'}).`
    );
    setPreviewSchemes([]);
    setFileName(null);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden transition-colors">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 dark:border-[#2E2E38] flex items-center justify-between gap-4 bg-slate-50/50 dark:bg-[#141416]/50">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
              <span>{isTamil ? 'திட்டங்கள் பதிவேற்றக் கருவி' : 'Zero-Cost Scheme Pipeline'}</span>
              <span>·</span>
              <span>{isTamil ? 'அனைத்து பிரிவுகளுடன் இணைக்கப்பட்டது' : 'Cross-Section Linked'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
              {isTamil ? 'பரஸ்பர நிதி திட்டங்களை பதிவேற்றவும் (Excel / CSV)' : 'Upload Mutual Fund Schemes (Excel / CSV)'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isTamil
                ? 'உங்கள் சொந்த அல்லது தனியுரிம திட்ட தரவை இறக்குமதி செய்யுங்கள். உடனடியாக அனைத்து கணக்கீடுகள் மற்றும் பகுப்பாய்வுகளிலும் இணைக்கப்படும்.'
                : 'Import custom or proprietary scheme data. Uploaded schemes immediately reflect across Wealth Builder Funds, Fund Monitor, Calculators, and the DICE Suitability Profiler.'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Success Banner */}
          {importSuccessMessage && (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-emerald-950 dark:text-emerald-200 text-sm">{isTamil ? 'இறக்குமதி முடிந்தது!' : 'Import Complete!'}</div>
                <div className="text-emerald-800 dark:text-emerald-300 mt-0.5">{importSuccessMessage}</div>
              </div>
            </div>
          )}

          {/* 1. Template Download & Column Specification Section */}
          <div className="bg-amber-50/50 dark:bg-[#141416] border border-amber-200/80 dark:border-[#2E2E38] rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-amber-700 dark:text-amber-400" />
                  <span>{isTamil ? 'படி 1: மாதிரி Excel / CSV டெம்ப்ளேட்டை பதிவிறக்கவும்' : 'Step 1: Download Sample Excel / CSV Template'}</span>
                </h3>
                <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                  {isTamil
                    ? 'பங்கு, கடன், கலப்பு மற்றும் பொருட்களுக்கான முன் நிரப்பப்பட்ட மாதிரி வரிசைகளைக் கொண்ட நிலையான டெம்ப்ளேட்டைப் பயன்படுத்தவும்.'
                    : 'Use this standardized template containing pre-filled sample rows for Equity, Debt, Hybrid, and Commodities.'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={generateSampleExcelFile}
                  className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .xlsx</span>
                </button>
                <button
                  onClick={generateSampleCsvFile}
                  className="px-3.5 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .csv</span>
                </button>
              </div>
            </div>

            {/* Column Order Details Accordion / Guide */}
            <div className="pt-3 border-t border-amber-200/60 dark:border-[#2E2E38]">
              <span className="font-bold text-slate-800 dark:text-white block mb-2">
                {isTamil ? 'கட்டாய மற்றும் ஆதரிக்கப்படும் நெடுவரிசை விவரக்குறிப்பு:' : 'Mandatory & Supported Column Order:'}
              </span>
              <div className="max-h-40 overflow-y-auto border border-slate-200 dark:border-[#2E2E38] rounded-xl bg-white dark:bg-[#1E1E24]">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-50 dark:bg-[#141416] font-semibold text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-[#2E2E38]">
                    <tr>
                      <th className="py-1.5 px-3">Column Name</th>
                      <th className="py-1.5 px-3">Required?</th>
                      <th className="py-1.5 px-3">Sample Value</th>
                      <th className="py-1.5 px-3">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                    {SCHEME_COLUMNS_SPEC.map((col) => (
                      <tr key={col.key}>
                        <td className="py-1.5 px-3 font-semibold text-slate-900 dark:text-white">{col.label}</td>
                        <td className="py-1.5 px-3">
                          {col.required ? (
                            <span className="text-amber-800 dark:text-amber-400 font-bold">Yes</span>
                          ) : (
                            <span className="text-slate-400">Optional</span>
                          )}
                        </td>
                        <td className="py-1.5 px-3 font-mono text-slate-600 dark:text-slate-300">{String(col.example)}</td>
                        <td className="py-1.5 px-3 text-slate-500 dark:text-slate-400">{col.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* 2. Drag & Drop File Upload Area */}
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2 flex items-center gap-2">
              <Upload className="w-4 h-4 text-slate-700 dark:text-slate-300" />
              <span>{isTamil ? 'படி 2: உங்கள் கோப்பை பதிவேற்றவும்' : 'Step 2: Upload Your Completed File'}</span>
            </h3>

            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
                dragActive
                  ? 'border-amber-600 bg-amber-50/60 dark:bg-amber-950/30'
                  : 'border-slate-300 dark:border-slate-700 hover:border-slate-400 bg-slate-50/50 dark:bg-[#141416]/50 hover:bg-slate-50 dark:hover:bg-[#141416]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
              />
              <Upload className="w-8 h-8 text-slate-400 mx-auto mb-3" />
              <div className="font-bold text-slate-800 dark:text-white text-sm">
                {fileName ? fileName : isTamil ? 'கோப்பை தேர்வு செய்ய கிளிக் செய்யவும் அல்லது இங்கே இழுத்து விடவும்' : 'Click to select or drag and drop your file here'}
              </div>
              <p className="text-slate-500 dark:text-slate-400 mt-1">Supports Microsoft Excel (.xlsx, .xls) and CSV (.csv)</p>
            </div>

            {parsing && (
              <div className="p-3 mt-3 bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 rounded-xl flex items-center gap-2 font-medium">
                <RefreshCw className="w-4 h-4 animate-spin text-blue-600 dark:text-blue-400" />
                <span>Validating scheme structure and columns...</span>
              </div>
            )}

            {parseError && (
              <div className="p-3 mt-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                <span>{parseError}</span>
              </div>
            )}
          </div>

          {/* 3. Preview of Parsed Schemes */}
          {previewSchemes.length > 0 && (
            <div className="space-y-4 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white text-sm">
                    Preview: {previewSchemes.length} Schemes Detected
                  </span>
                  <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                    Ready to Link
                  </span>
                </div>

                {/* Import Mode: Append or Replace */}
                <div className="flex items-center gap-3">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">Import Mode:</span>
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-800 dark:text-slate-200">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'append'}
                      onChange={() => setImportMode('append')}
                      className="text-amber-600"
                    />
                    <span>Append to Universe</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-800 dark:text-slate-200">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'replace'}
                      onChange={() => setImportMode('replace')}
                      className="text-amber-600"
                    />
                    <span>Replace Universe</span>
                  </label>
                </div>
              </div>

              {/* Preview Table */}
              <div className="border border-slate-200 dark:border-[#2E2E38] rounded-xl overflow-hidden max-h-56 overflow-y-auto">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-50 dark:bg-[#141416] font-semibold text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-[#2E2E38]">
                    <tr>
                      <th className="py-2 px-3">Scheme</th>
                      <th className="py-2 px-3">Category</th>
                      <th className="py-2 px-3">Asset Class</th>
                      <th className="py-2 px-3 text-right">NAV (₹)</th>
                      <th className="py-2 px-3 text-right">1Y Ret (%)</th>
                      <th className="py-2 px-3 text-left">Riskometer</th>
                      <th className="py-2 px-3 text-right">TER (%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                    {previewSchemes.map((s, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-[#141416]/50">
                        <td className="py-2 px-3 font-semibold text-slate-900 dark:text-white">{s.name}</td>
                        <td className="py-2 px-3 text-slate-600 dark:text-slate-300">{s.category}</td>
                        <td className="py-2 px-3 font-medium">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              s.broadCategory === 'Equity'
                                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                                : s.broadCategory === 'Debt'
                                ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300'
                                : s.broadCategory === 'Hybrid'
                                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                                : 'bg-yellow-100 dark:bg-yellow-950/60 text-yellow-800 dark:text-yellow-300'
                            }`}
                          >
                            {s.broadCategory}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">₹{s.nav.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-mono text-emerald-700 dark:text-emerald-400 font-bold">+{s.return1Y}%</td>
                        <td className="py-2 px-3 text-slate-700 dark:text-slate-300">{s.riskometer}</td>
                        <td className="py-2 px-3 text-right font-mono text-slate-900 dark:text-white">{s.ter}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {validationErrors.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl text-amber-900 dark:text-amber-300 text-[11px] space-y-1">
                  <div className="font-bold">Minor Warnings:</div>
                  {validationErrors.map((err, i) => (
                    <div key={i}>· {err}</div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Universe Management Strip */}
          {uploadedCount > 0 && (
            <div className="p-4 bg-slate-50 dark:bg-[#141416] border border-slate-200 dark:border-[#2E2E38] rounded-xl flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Custom Universe Active</span>
                <span className="text-slate-500 dark:text-slate-400">Currently hosting {uploadedCount} uploaded schemes.</span>
              </div>
              <button
                onClick={resetToDefaults}
                className="px-3 py-1.5 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Reset to Default Schemes</span>
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-[#2E2E38] bg-slate-50/70 dark:bg-[#141416]/70 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 dark:border-[#2E2E38] rounded-xl font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1E1E24] text-xs transition-colors"
          >
            {isTamil ? 'ரத்துசெய்' : 'Cancel'}
          </button>

          <button
            onClick={handleConfirmImport}
            disabled={previewSchemes.length === 0}
            className="px-6 py-2.5 bg-slate-900 dark:bg-amber-600 hover:bg-slate-800 dark:hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs transition-colors shadow-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {isTamil
                ? `${previewSchemes.length} திட்டங்களை பயன்பாட்டில் இணைக்கவும்`
                : `Confirm & Link ${previewSchemes.length} Schemes Across App`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
