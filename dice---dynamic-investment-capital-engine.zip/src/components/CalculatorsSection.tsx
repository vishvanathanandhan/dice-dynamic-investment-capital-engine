/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Calculators Section with dynamic schemes integration from SchemeContext
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Calculator,
  TrendingUp,
  Target,
  DollarSign,
  RefreshCw,
  ArrowRight,
  ExternalLink,
  Search,
  ChevronDown,
  Check,
  Loader2,
  SlidersHorizontal,
  AlertTriangle,
} from 'lucide-react';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import { MutualFundScheme } from '../types';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';

interface CalculatorsSectionProps {
  onViewSchemeDetails?: (scheme: MutualFundScheme) => void;
}

export const CalculatorsSection: React.FC<CalculatorsSectionProps> = ({ onViewSchemeDetails }) => {
  const { t } = useLanguage();
  const { schemes: localSchemes } = useSchemes();
  const [selectedCalc, setSelectedCalc] = useState<'sip' | 'goal' | 'investment'>('sip');

  // Interactive Calculator State
  const [activeScheme, setActiveScheme] = useState<MutualFundScheme>(localSchemes[0]);
  const [monthlyAmount, setMonthlyAmount] = useState(10000);
  const [durationYears, setDurationYears] = useState(3);
  const [stepUpPercent, setStepUpPercent] = useState(0);
  const [assumedRate, setAssumedRate] = useState(12);

  // Searchable 11,000+ Schemes Picker State
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [schemeSearch, setSchemeSearch] = useState('');
  const [schemeOptions, setSchemeOptions] = useState<MutualFundScheme[]>([]);
  const [isSearchingSchemes, setIsSearchingSchemes] = useState(false);
  const [totalSchemesCount, setTotalSchemesCount] = useState<number>(11434);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Goal Calculator State
  const [targetGoalCorpus, setTargetGoalCorpus] = useState(5000000); // 50 Lakhs
  const [goalYears, setGoalYears] = useState(10);
  const [goalRate, setGoalRate] = useState(12);

  // Initial fetch of top schemes by AUM
  useEffect(() => {
    fetch('/api/pipeline/schemes?limit=20&sortBy=aumCrores&sortOrder=desc')
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );
          setSchemeOptions(list);
          setTotalSchemesCount(json.data.total || 11434);
          if (list.length > 0 && !activeScheme) {
            setActiveScheme(list[0]);
            setAssumedRate(list[0].return3Y || list[0].return1Y || 12);
          }
        }
      })
      .catch((e) => console.error('Failed to load initial calculator schemes', e));
  }, []);

  // Debounced search across 11,000+ schemes
  useEffect(() => {
    if (!isPickerOpen) return;

    const q = schemeSearch.trim();
    setIsSearchingSchemes(true);
    const handler = setTimeout(async () => {
      try {
        const url = q
          ? `/api/pipeline/schemes?search=${encodeURIComponent(q)}&limit=25`
          : '/api/pipeline/schemes?limit=25&sortBy=aumCrores&sortOrder=desc';
        const res = await fetch(url);
        const json = await res.json();
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );

          // Also prepend matching uploaded custom schemes
          const qLower = q.toLowerCase();
          const customMatches = localSchemes.filter(
            (s) =>
              (s.id.startsWith('uploaded_') || s.isUploaded) &&
              (s.name.toLowerCase().includes(qLower) || s.category.toLowerCase().includes(qLower))
          );

          setSchemeOptions([...customMatches, ...list]);
          setTotalSchemesCount(json.data.total || 11434);
        }
      } catch (err) {
        console.error('Failed searching schemes for calculator', err);
      } finally {
        setIsSearchingSchemes(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [schemeSearch, isPickerOpen, localSchemes]);

  // Click outside listener for picker
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsPickerOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectScheme = (scheme: MutualFundScheme) => {
    setActiveScheme(scheme);
    const rate = scheme.return3Y || scheme.return1Y || 12;
    setAssumedRate(Number(rate.toFixed(1)));
    setIsPickerOpen(false);
  };

  // SIP Computation: FV = PMT * (((1 + i)^m - 1) / i)
  const calculateSIP = (p: number, yrs: number, rate: number, stepUp: number) => {
    const monthlyRate = rate / 100 / 12;
    const totalMonths = yrs * 12;
    let totalInvested = 0;
    let accumulated = 0;
    let curMonthly = p;

    for (let m = 1; m <= totalMonths; m++) {
      if (stepUp > 0 && m > 1 && (m - 1) % 12 === 0) {
        curMonthly = curMonthly * (1 + stepUp / 100);
      }
      totalInvested += curMonthly;
      accumulated = (accumulated + curMonthly) * (1 + monthlyRate);
    }

    return {
      totalInvested: Math.round(totalInvested),
      futureValue: Math.round(accumulated),
      totalGains: Math.round(accumulated - totalInvested),
    };
  };

  const isLumpSum = selectedCalc === 'investment';
  const calcResult = isLumpSum
    ? {
        totalInvested: monthlyAmount,
        futureValue: Math.round(monthlyAmount * Math.pow(1 + assumedRate / 100, durationYears)),
        totalGains: Math.round(
          monthlyAmount * Math.pow(1 + assumedRate / 100, durationYears) - monthlyAmount
        ),
      }
    : calculateSIP(monthlyAmount, durationYears, assumedRate, stepUpPercent);

  // Goal Calculator Computation: Required Monthly SIP
  const calculateGoalRequiredSIP = () => {
    const r = goalRate / 100 / 12;
    const m = goalYears * 12;
    const requiredSip = (targetGoalCorpus * r) / ((Math.pow(1 + r, m) - 1) * (1 + r));
    return Math.round(requiredSip);
  };

  return (
    <section className="py-12 bg-white dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('calc.heading', 'Financial Calculators')}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t('calc.subheading', 'Simulate your wealth growth, goal requirements, and compounding with mathematical precision across all funds.')}
          </p>
        </div>

        {/* 3 Distinct Core Calculator Selector Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { id: 'sip', name: t('calc.sip', 'SIP Return Calculator'), desc: 'Calculate accumulation with monthly systematic investment' },
            { id: 'goal', name: t('calc.goal', 'Goal Planning Calculator'), desc: 'Estimate required monthly savings to achieve target goals' },
            { id: 'investment', name: t('calc.investment', 'Lump Sum Investment Calculator'), desc: 'Calculate one-time compounding growth on capital' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedCalc(item.id as typeof selectedCalc)}
              className={`text-left p-4 rounded-2xl border transition-all duration-150 flex flex-col justify-between cursor-pointer ${
                selectedCalc === item.id
                  ? 'border-amber-600 bg-amber-50/50 dark:bg-amber-950/30 shadow-xs ring-1 ring-amber-600'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <div>
                <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-300 mb-2">
                  <Calculator className="w-3.5 h-3.5" />
                </div>
                <div className="text-xs font-bold text-slate-900 dark:text-white leading-snug">{item.name}</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-tight">
                  {item.desc}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Interactive Mutual Fund / SIP Calculator Interface (Matching PDF Page 1) */}
        <div className="bg-[#FAF8F5] dark:bg-slate-950 border border-[#E9DFCE] dark:border-slate-800 rounded-3xl p-6 sm:p-8 transition-colors duration-300">
          <div className="max-w-4xl mx-auto">
            <div className="border-b border-[#DFD3BE] dark:border-slate-800 pb-4 mb-6">
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                {selectedCalc === 'goal'
                  ? t('calc.goal', 'Goal Planning Calculator')
                  : selectedCalc === 'investment'
                  ? t('calc.investment', 'Lump Sum Investment Calculator')
                  : t('calc.sip', 'Mutual Fund SIP Return Calculator')}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                Calculate retrospective performance or prospective hypothetical compounding.
              </p>
            </div>

            {selectedCalc === 'goal' ? (
              /* Goal Planning Mode */
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div className="md:col-span-7 space-y-5 text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      {t('calc.target_goal', 'Target Goal Amount (₹)')}
                    </label>
                    <input
                      type="number"
                      step="50000"
                      value={targetGoalCorpus}
                      onChange={(e) => setTargetGoalCorpus(Number(e.target.value))}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-1 block">
                      ₹{(targetGoalCorpus / 100000).toFixed(2)} Lakhs
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        {t('calc.time_period', 'Time Horizon (Years)')}
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="30"
                        value={goalYears}
                        onChange={(e) => setGoalYears(Number(e.target.value))}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        {t('calc.expected_rate', 'Expected Return (% p.a.)')}
                      </label>
                      <input
                        type="number"
                        min="4"
                        max="20"
                        value={goalRate}
                        onChange={(e) => setGoalRate(Number(e.target.value))}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="md:col-span-5 space-y-3">
                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center space-y-2 shadow-2xs">
                    <div className="text-[11px] uppercase font-bold text-slate-400 dark:text-slate-500">{t('calc.required_sip', 'Required Monthly SIP')}</div>
                    <div className="text-3xl font-black text-slate-900 dark:text-white font-mono tabular-nums">
                      ₹{calculateGoalRequiredSIP().toLocaleString('en-IN')}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal pt-2">
                      To accumulate ₹{(targetGoalCorpus / 100000).toFixed(2)} Lakhs in {goalYears} years at {goalRate}% p.a.
                    </p>
                  </div>

                  {/* Calculator Disclaimer displayed directly below result */}
                  <div className="p-3.5 bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/90 dark:border-amber-800/40 rounded-2xl text-left space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 dark:text-amber-300">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                      <span>{t('calc.disclaimer_title', 'Calculator Disclaimer')}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      {t('calc.disclaimer_text')}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              /* SIP & Mutual Fund Calculator Mode */
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                {/* Inputs */}
                <div className="md:col-span-7 space-y-5 text-xs">
                  <div className="relative" ref={dropdownRef}>
                    <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between mb-1.5">
                      <span>Select Any Mutual Fund Scheme:</span>
                      <span className="text-[10px] text-amber-800 dark:text-amber-400 font-mono font-medium">
                        Search across 11,000+ schemes
                      </span>
                    </label>

                    <div className="flex items-center gap-2">
                      {/* Searchable Picker Trigger */}
                      <button
                        type="button"
                        onClick={() => setIsPickerOpen((prev) => !prev)}
                        className="flex-1 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-left font-semibold text-slate-900 dark:text-white flex items-center justify-between transition-all focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shadow-2xs"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="font-bold text-slate-900 dark:text-white truncate">
                            {activeScheme?.name || 'Select Scheme'}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-normal truncate mt-0.5">
                            {activeScheme?.amc} · {activeScheme?.category} · {activeScheme?.broadCategory}
                          </div>
                        </div>
                        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      </button>

                      {onViewSchemeDetails && activeScheme && (
                        <button
                          type="button"
                          onClick={() => onViewSchemeDetails(activeScheme)}
                          className="px-3.5 py-2.5 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                          title="Open full factsheet and portfolio breakdown"
                        >
                          <ExternalLink className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
                          <span className="hidden sm:inline">{t('common.view_details', 'View Details')}</span>
                        </button>
                      )}
                    </div>

                    {/* Dropdown Popover */}
                    {isPickerOpen && (
                      <div className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 overflow-hidden">
                        <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700">
                          <div className="relative">
                            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                            <input
                              type="text"
                              value={schemeSearch}
                              onChange={(e) => setSchemeSearch(e.target.value)}
                              placeholder="Type to search 11,000+ schemes (e.g. Parag Parikh, SBI, HDFC, Liquid)..."
                              autoFocus
                              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-8 pr-8 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                            />
                            {isSearchingSchemes && (
                              <Loader2 className="w-3.5 h-3.5 text-amber-600 animate-spin absolute right-2.5 top-2.5" />
                            )}
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 px-0.5">
                            <span>Showing {schemeOptions.length} of {totalSchemesCount.toLocaleString('en-IN')} schemes</span>
                            <span>Click any scheme to select</span>
                          </div>
                        </div>

                        <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                          {schemeOptions.length === 0 && !isSearchingSchemes ? (
                            <div className="p-4 text-center text-xs text-slate-500 dark:text-slate-400">
                              No schemes found matching "{schemeSearch}".
                            </div>
                          ) : (
                            schemeOptions.map((sch) => {
                              const isSelected = activeScheme?.id === sch.id;
                              return (
                                <button
                                  key={sch.id}
                                  type="button"
                                  onClick={() => handleSelectScheme(sch)}
                                  className={`w-full p-2.5 text-left text-xs transition-colors flex items-center justify-between cursor-pointer ${
                                    isSelected ? 'bg-amber-50 dark:bg-amber-950/40 font-bold' : 'hover:bg-slate-50 dark:hover:bg-slate-800 font-normal'
                                  }`}
                                >
                                  <div className="min-w-0 pr-3">
                                    <div className="text-slate-900 dark:text-white font-semibold truncate text-[11px]">
                                      {sch.name}
                                    </div>
                                    <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5 flex-wrap">
                                      <span>{sch.amc}</span>
                                      <span>·</span>
                                      <span className="font-mono">{sch.category}</span>
                                      <span>·</span>
                                      <span className="text-emerald-700 dark:text-emerald-400 font-mono font-bold">
                                        1Y: {sch.return1Y ? `+${sch.return1Y}%` : 'N/A'}
                                      </span>
                                    </div>
                                  </div>
                                  {isSelected && <Check className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />}
                                </button>
                              );
                            })
                          )}
                        </div>
                      </div>
                    )}

                    {activeScheme && (
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-1.5 block">
                        Latest NAV: ₹{activeScheme.nav ? activeScheme.nav.toFixed(2) : 'Data unavailable'} · 1Y Ret: {activeScheme.return1Y ? `+${activeScheme.return1Y}%` : 'Data unavailable'} · TER: {activeScheme.ter ? `${activeScheme.ter}%` : 'Data unavailable'} · Risk: {activeScheme.riskometer || 'Moderate'}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        {isLumpSum ? t('calc.lump_sum_amount', 'One-Time Lump Sum Capital (₹)') : t('calc.monthly_amount', 'Monthly Investment (₹)')}
                      </label>
                      <input
                        type="number"
                        step="500"
                        min="500"
                        value={monthlyAmount}
                        onChange={(e) => setMonthlyAmount(Number(e.target.value))}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        {t('calc.time_period', 'Investment Duration (Years)')}
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="35"
                        value={durationYears}
                        onChange={(e) => setDurationYears(Number(e.target.value))}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {!isLumpSum ? (
                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          {t('calc.annual_step_up', 'Increase investment by % per year (Step-Up)')}
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="50"
                          value={stepUpPercent}
                          onChange={(e) => setStepUpPercent(Number(e.target.value))}
                          className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>
                    ) : (
                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Investment Mode
                        </label>
                        <div className="py-2.5 px-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-medium text-slate-800 dark:text-slate-200 text-xs">
                          One-Time Lump Sum Capital Growth
                        </div>
                      </div>
                    )}
                    <div>
                      <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        {t('calc.expected_rate', 'Assumed Return Rate (% p.a.)')}
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="30"
                        value={assumedRate}
                        onChange={(e) => setAssumedRate(Number(e.target.value))}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Output Card */}
                <div className="md:col-span-5 space-y-3">
                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-2xs">
                    <div className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500">{t('calc.worth_title', 'Worth of Investment')}</div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500 dark:text-slate-400">{isLumpSum ? 'Lump Sum Invested:' : t('calc.total_invested', 'Total Invested:')}</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          ₹{calcResult.totalInvested.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500 dark:text-slate-400">{t('calc.estimated_gain', 'Estimated Gain:')}</span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          +₹{calcResult.totalGains.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-baseline">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{t('calc.future_value', 'Total Future Value:')}</span>
                        <span className="font-mono text-2xl font-black text-slate-900 dark:text-white tabular-nums">
                          ₹{calcResult.futureValue.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight pt-2 border-t border-slate-100 dark:border-slate-800 italic">
                      *Compounded {isLumpSum ? 'annually' : 'monthly'} at {assumedRate}% p.a. using standard compound interest formulas. Returns are market-linked and not guaranteed.
                    </div>
                  </div>

                  {/* Calculator Disclaimer displayed directly below result */}
                  <div className="p-3.5 bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/90 dark:border-amber-800/40 rounded-2xl text-left space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 dark:text-amber-300">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                      <span>{t('calc.disclaimer_title', 'Calculator Disclaimer')}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      {t('calc.disclaimer_text')}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
