/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE Methodology, NISM Foundations & Regulatory Disclaimer View
 */

import React from 'react';
import { BookOpen, ShieldCheck, Scale, Cpu, AlertTriangle, CheckCircle, FileText } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const MethodologyView: React.FC = () => {
  const { isTamil } = useLanguage();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-semibold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
          <span>{isTamil ? 'ஆவணங்கள் & கட்டமைப்பு' : 'Documentation & Architecture'}</span>
          <span>·</span>
          <span>{isTamil ? 'DICE இயந்திர கட்டமைப்பு' : 'DICE Engine Framework'}</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {isTamil ? 'DICE முறைமை & ஒழுங்குமுறை அடிப்படை' : 'DICE Methodology & Regulatory Foundation'}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
          {isTamil
            ? 'டைனமிக் முதலீட்டு மூலதன இயந்திரம் (DICE) என்பது NISM Series V-A பாடத்திட்டத்தின் அடிப்படையில் அமைக்கப்பட்ட உறுதிப்படுத்தப்பட்ட, வெளிப்படையான நிதி பொருத்தம் மற்றும் வடிகட்டுதல் அமைப்பாகும்.'
            : 'The Dynamic Investment Capital Engine (DICE) is a deterministic, explainable financial suitability and scheme filtering layer grounded in the NISM Series V-A Mutual Fund Distributors curriculum.'}
        </p>
      </div>

      {/* 1. Core Principle */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
          <Cpu className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          <span>{isTamil ? 'கணித மற்றும் உறுதிப்படுத்தப்பட்ட கட்டமைப்பு' : 'Core Mathematical & Deterministic Architecture'}</span>
        </div>
        <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {isTamil
            ? 'DICE இயந்திரம் நிதி அளவுருக்களை ஒருபோதும் ஊகிக்காது. இது கட்டமைக்கப்பட்ட திட்டத் தகவல்களின் (NAV, TER, AUM, போர்ட்ஃபோலியோ, ஷார்ப், பீட்டா) அடிப்படையில் செயல்படுகிறது. மதிப்பெண்களை கணக்கிடுவதற்கு முன் முதலீட்டாளர் தேவைகளை கடினமான நிதி வரம்புகளுடன் ஒப்பிடுகிறது.'
            : 'The DICE Engine never guesses or hallucinates financial parameters. It operates on structured scheme disclosures (NAV, TER, AUM, Portfolio, Sharpe, Beta, Max Drawdown) and evaluates investor inputs against hard financial constraints before calculating scores. AI (Gemini 3.8 Flash) is used strictly to provide plain-language, auditable explanations for verified engine outputs.'}
        </p>
      </div>

      {/* 2. DICE 5-Dimension Scoring Model */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
          <Scale className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          <span>{isTamil ? 'DICE 5-பரிமாண மதிப்பீட்டு மாதிரி & எடைகள்' : 'The DICE Scoring Model & Weight Allocations'}</span>
        </div>

        <div className="p-4 bg-slate-50 dark:bg-[#141416] rounded-2xl border border-slate-200 dark:border-[#2E2E38] font-mono text-xs sm:text-sm text-slate-900 dark:text-amber-400 text-center font-bold">
          DICE Total Score = 0.30(S) + 0.25(R) + 0.20(P) + 0.15(T) + 0.10(X)
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416]">
            <div className="font-bold text-slate-900 dark:text-white text-sm">1. {isTamil ? 'பொருத்தம் (S) — 30% எடை' : 'Suitability (S) — 30% Weight'}</div>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              {isTamil
                ? 'முதலீட்டாளரின் இலக்கு காலம், உபரி நிதி மற்றும் திட்டத்தின் பரிந்துரைக்கப்பட்ட கால அளவு இடையிலான சீரமைப்பை மதிப்பிடுகிறது.'
                : "Evaluates alignment between the investor's goal horizon, investible surplus, preferred mode (SIP/Lumpsum), and the fund's recommended holding period and investment objective."}
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416]">
            <div className="font-bold text-slate-900 dark:text-white text-sm">2. {isTamil ? 'அபாய பரிமாணம் (R) — 25% எடை' : 'Risk Dimension (R) — 25% Weight'}</div>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              {isTamil
                ? 'திட்டத்தின் நிலையற்ற தன்மையை (நிலையான விலகல், பீட்டா, SEBI 6-நிலை அபாயமானி) முதலீட்டாளரின் நிதி திறன் மற்றும் உளவியல் விருப்பத்துடன் ஒப்பிடுகிறது.'
                : "Compares scheme volatility (Standard Deviation, Beta, Drawdown, SEBI 6-level Riskometer) against the investor's diagnosed risk capacity (financial ability) and willingness (psychological comfort)."}
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416]">
            <div className="font-bold text-slate-900 dark:text-white text-sm">3. {isTamil ? 'செயல்திறன் (P) — 20% எடை' : 'Performance (P) — 20% Weight'}</div>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              {isTamil
                ? 'அபாய-சரிசெய்யப்பட்ட வருமானங்கள் (ஷார்ப் விகிதம்) மற்றும் சந்தை அளவுகோல்களுடன் ஒப்பீட்டு நிதி மேலாளரின் நிலைத்தன்மையை மதிப்பிடுகிறது.'
                : 'Evaluates risk-adjusted returns (Sharpe ratio, Jensen’s Alpha) and fund manager consistency relative to Total Return Index (TRI) benchmarks over 500+ trading days.'}
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416]">
            <div className="font-bold text-slate-900 dark:text-white text-sm">4. {isTamil ? 'வருமான பாதை (T) — 15% எடை' : 'Return Trajectory (T) — 15% Weight'}</div>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              {isTamil
                ? 'கடந்த கால கூட்டு வருமானங்களை (1Y, 3Y, 5Y) மதிப்பிடுகிறது; கடந்த கால வருமானம் எதிர்கால வருமானத்திற்கு உத்தரவாதம் அளிக்காது என்பதையும் நினைவூட்டுகிறது.'
                : 'Assesses historical rolling returns (1-Year, 3-Year, 5-Year CAGR) while explicitly reminding investors that past performance does not guarantee future results.'}
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-[#2E2E38] bg-slate-50/50 dark:bg-[#141416] md:col-span-2">
            <div className="font-bold text-slate-900 dark:text-white text-sm">5. {isTamil ? 'வரி & வெளியேறும் கட்டணம் (X) — 10% எடை' : 'Tax & Exit (X) — 10% Weight'}</div>
            <p className="text-slate-600 dark:text-slate-300 mt-1">
              {isTamil
                ? 'முதலீட்டுக் காலம், வெளியேறும் கட்டண அட்டவணைகள், லாக்-இன் காலங்கள் மற்றும் யூனியன் பட்ஜெட் 2024 வரி விதிகளை மதிப்பிடுகிறது.'
                : 'Assesses holding duration against exit load schedules (e.g. 1% within 365 days), lock-in periods (e.g. 3 years for ELSS), and Union Budget 2024 taxation rules (20% STCG, 12.5% LTCG above ₹1.25 Lakh exemption).'}
            </p>
          </div>
        </div>

        {/* Match Bands Table */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
            {isTamil ? 'மதிப்பெண் வரம்பு வகைப்பாடுகள்' : 'Match Score Classifications'}
          </h4>
          <div className="border border-slate-200 dark:border-[#2E2E38] rounded-xl overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-[#141416] text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-[#2E2E38]">
                <tr>
                  <th className="py-2.5 px-4">{isTamil ? 'மதிப்பெண் வரம்பு' : 'Score Range'}</th>
                  <th className="py-2.5 px-4">{isTamil ? 'பொருத்த லேபிள்' : 'Match Label'}</th>
                  <th className="py-2.5 px-4">{isTamil ? 'கணினி விளக்கம்' : 'System Interpretation'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                <tr>
                  <td className="py-2.5 px-4 font-mono font-bold text-emerald-800 dark:text-emerald-400">80 – 100</td>
                  <td className="py-2.5 px-4 font-bold text-emerald-700 dark:text-emerald-400">{isTamil ? 'அதிக பொருத்தம்' : 'High Match'}</td>
                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{isTamil ? 'கால அளவு, அபாய சுயவிவரம் மற்றும் ஒதுக்கீட்டை மிகச் சிறப்பாக பூர்த்தி செய்கிறது.' : 'Meets horizon, risk profile, and allocation with strong risk-adjusted alpha.'}</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 font-mono font-bold text-amber-800 dark:text-amber-400">60 – 79</td>
                  <td className="py-2.5 px-4 font-bold text-amber-700 dark:text-amber-400">{isTamil ? 'நடுத்தர பொருத்தம்' : 'Medium Match'}</td>
                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{isTamil ? 'ஏற்றுக்கொள்ளக்கூடிய பொருத்தம்; கால அளவு அல்லது துறையில் சிறிய மாற்றங்கள் இருக்கலாம்.' : 'Acceptable fit with minor tradeoffs in duration or sector concentration.'}</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 font-mono font-bold text-orange-800 dark:text-orange-400">40 – 59</td>
                  <td className="py-2.5 px-4 font-bold text-orange-700 dark:text-orange-400">{isTamil ? 'குறைந்த பொருத்தம்' : 'Low Match'}</td>
                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{isTamil ? 'விளிம்பு நிலை பொருத்தம்; அபாய சகிப்புத்தன்மை அல்லது கால வரம்பில் வேறுபாடு உள்ளது.' : 'Borderline suitability; noticeable divergence in risk tolerance or time horizon.'}</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 font-mono font-bold text-rose-800 dark:text-rose-400">&lt; 40</td>
                  <td className="py-2.5 px-4 font-bold text-rose-700 dark:text-rose-400">{isTamil ? 'பரிந்துரைக்கப்படவில்லை' : 'Not Recommended'}</td>
                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{isTamil ? 'குறிப்பிட்ட தேவைகளுக்கு பொருந்தாதவை; கணினியால் விலக்கப்பட்டது.' : 'Incompatible with stated needs; excluded by the engine.'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 3. NISM Series V-A Workbook Chapter Foundations */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
          <BookOpen className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          <span>Curriculum Mapping: NISM Series V-A (March 2026 Edition)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 1:</strong> Investor Profile, Goals, Risk Capacity vs Willingness, Behavioural Biases.
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 2:</strong> Mutual Fund Categorization (SEBI Circular: Equity, Debt, Hybrid, Life Cycle Funds).
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 5:</strong> Mandatory Documents (SID, SAI, KIM) and SEBI 6-Level Risk-o-meter Color Scheme.
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 7:</strong> NAV Computation, Total Expense Ratio (TER), and Exit Load Impact.
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 8:</strong> Taxation (Union Budget 2024 Equity 20% STCG / 12.5% LTCG, Debt MSR, Stamp Duty).
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 9:</strong> KYC, CERSAI cKYCR, Cut-off Timings, and Systematic Transactions (SIP, SWP, STP).
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 10:</strong> Risk Measures (Standard Deviation, Beta, Drawdown, Segregated Portfolios).
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38] text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Chapter 11:</strong> Benchmarks (Total Return Index TRI), Sharpe, Treynor, and Information Ratio.
          </div>
        </div>
      </div>

      {/* 4. Educational Prototype & Regulatory Safeguards */}
      <div className="bg-amber-50/70 dark:bg-[#1E1E24] border border-amber-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-amber-950 dark:text-amber-400">
          <AlertTriangle className="w-5 h-5 text-amber-700 dark:text-amber-400" />
          <span>{isTamil ? 'கல்வி மற்றும் ஆராய்ச்சி முன்மாதிரி மறுப்புரை' : 'Educational & Research Prototype Disclaimer'}</span>
        </div>
        <p className="text-xs text-amber-900 dark:text-slate-300 leading-relaxed">
          {isTamil
            ? 'DICE என்பது ஆராய்ச்சி மற்றும் விளக்க நோக்கங்களுக்காக உருவாக்கப்பட்ட ஒரு கல்வி, பகுப்பாய்வு முன்மாதிரி ஆகும். இது பரிவர்த்தனைகளைச் செய்யாது, வைப்புகளை ஏற்காது அல்லது SEBI-யில் பதிவுசெய்யப்பட்ட முதலீட்டு ஆலோசகர் என்று கூறாது. அனைத்து எதிர்கால மதிப்புக் கணக்கீடுகளும் கணித விளக்கங்கள் மட்டுமே. பரஸ்பர நிதிகளில் முதலீடு செய்வது சந்தை அபாயங்களுக்கு உட்பட்டது; அனைத்து திட்டம் தொடர்பான ஆவணங்களையும் கவனமாகப் படியுங்கள்.'
            : 'DICE is an educational, analytical portfolio prototype built for research and demonstration purposes. It does not execute transactions, accept deposits, place brokerage orders, or claim SEBI registration as an Investment Adviser. All future value calculations are purely mathematical illustrations and do not constitute promised or assured returns. Investments in mutual funds are subject to market risks; please read all scheme related documents carefully.'}
        </p>
      </div>
    </div>
  );
};
