/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Watchlist Modal: Track favorite schemes across the entire 11,000+ database
 * Localized with comprehensive English and Tamil support
 */

import React, { useState, useEffect } from 'react';
import { X, Star, ArrowRight, Eye, Plus, Search, Loader2 } from 'lucide-react';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import { MutualFundScheme } from '../types';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';

interface WatchlistModalProps {
  onClose: () => void;
  onOpenSchemeDetail: (scheme: MutualFundScheme) => void;
  onAnalyzeSchemeWithDICE: (scheme: MutualFundScheme) => void;
}

const WATCHLIST_STORAGE_KEY = 'dice_watchlist_schemes_v2';

export const WatchlistModal: React.FC<WatchlistModalProps> = ({
  onClose,
  onOpenSchemeDetail,
  onAnalyzeSchemeWithDICE,
}) => {
  const { schemes: localSchemes } = useSchemes();
  const { t, isTamil } = useLanguage();

  const [watchedList, setWatchedList] = useState<MutualFundScheme[]>(() => {
    try {
      const saved = localStorage.getItem(WATCHLIST_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // fallback
    }
    // Default to first 2 default schemes if available
    return localSchemes.slice(0, 2);
  });

  // Search state across 11,000+ schemes
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MutualFundScheme[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(WATCHLIST_STORAGE_KEY, JSON.stringify(watchedList));
    } catch (e) {
      // ignore
    }
  }, [watchedList]);

  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const handler = setTimeout(async () => {
      try {
        const res = await fetch(`/api/pipeline/schemes?search=${encodeURIComponent(q)}&limit=15`);
        const json = await res.json();
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );

          const qLower = q.toLowerCase();
          const customMatches = localSchemes.filter(
            (s) =>
              (s.id.startsWith('uploaded_') || s.isUploaded) &&
              (s.name.toLowerCase().includes(qLower) || s.category.toLowerCase().includes(qLower))
          );

          setSearchResults([...customMatches, ...list]);
        }
      } catch (err) {
        console.error('Failed searching schemes for watchlist', err);
      } finally {
        setIsSearching(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [searchQuery, localSchemes]);

  const addToWatchlist = (scheme: MutualFundScheme) => {
    if (!watchedList.some((s) => s.id === scheme.id || s.isin === scheme.isin)) {
      setWatchedList([scheme, ...watchedList]);
    }
    setSearchQuery('');
    setIsSearchOpen(false);
  };

  const removeFromWatchlist = (id: string) => {
    setWatchedList(watchedList.filter((s) => s.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden transition-colors">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-[#2E2E38] flex items-center justify-between gap-4 bg-slate-50/50 dark:bg-[#141416]/50">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              <span>{isTamil ? 'DICE நேரலை போர்ட்ஃபோலியோ டிராக்கர்' : 'DICE Live Portfolio Tracker'}</span>
              <span>·</span>
              <span>{isTamil ? '11,000+ தரவுத்தளத்துடன் இணைக்கப்பட்டது' : '11,000+ Database Linked'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
              {t('tools.watchlist_title', 'My Watchlist')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t('tools.watchlist_desc', 'Monitor your preferred mutual funds from the 11,000+ scheme database with live NAV, 1-year returns, and instant DICE diagnostics.')}
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-[#141416] hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shrink-0 cursor-pointer border dark:border-[#2E2E38]"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Add across 11,000+ schemes */}
        <div className="px-6 py-3 bg-amber-50/50 dark:bg-[#141416] border-b border-amber-100 dark:border-[#2E2E38] relative">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={isTamil ? '11,000+ திட்டங்களில் தேடி சேர்க்கவும் (எ.கா. பராக் பாரிக், SBI ஸ்மால் கேப்)...' : 'Search across 11,000+ schemes to add (e.g., Parag Parikh, SBI Small Cap, HDFC Top 100)...'}
                value={searchQuery}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                className="w-full pl-9 pr-8 py-2 bg-white dark:bg-[#1E1E24] border border-slate-300 dark:border-[#2E2E38] rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              />
              {isSearching && (
                <Loader2 className="w-4 h-4 text-amber-600 dark:text-amber-400 animate-spin absolute right-3 top-1/2 -translate-y-1/2" />
              )}
            </div>
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchOpen && searchQuery.trim() && (
            <div className="absolute top-full left-6 right-6 mt-1 bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-2xl shadow-xl z-20 max-h-64 overflow-y-auto p-2">
              <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between border-b border-slate-100 dark:border-[#2E2E38]">
                <span>{isTamil ? `பொருந்திய திட்டங்கள் (${searchResults.length})` : `Matching Schemes (${searchResults.length})`}</span>
                <button
                  type="button"
                  onClick={() => setIsSearchOpen(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {searchResults.length === 0 && !isSearching && (
                <div className="p-4 text-center text-xs text-slate-500 dark:text-slate-400">
                  {isTamil ? `"${searchQuery}" க்கு பொருந்தும் திட்டங்கள் இல்லை.` : `No matching schemes found for "${searchQuery}".`}
                </div>
              )}

              {searchResults.map((scheme) => {
                const isAlreadyAdded = watchedList.some((s) => s.id === scheme.id || s.isin === scheme.isin);
                return (
                  <button
                    key={scheme.id}
                    type="button"
                    disabled={isAlreadyAdded}
                    onClick={() => addToWatchlist(scheme)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      isAlreadyAdded
                        ? 'opacity-50 cursor-not-allowed bg-slate-50 dark:bg-[#141416]'
                        : 'hover:bg-amber-50/80 dark:hover:bg-[#282830] cursor-pointer'
                    }`}
                  >
                    <div className="truncate pr-3">
                      <div className="font-semibold text-slate-900 dark:text-white truncate">{scheme.name}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{scheme.amc}</span>
                        <span>·</span>
                        <span className="text-amber-700 dark:text-amber-400">{scheme.category}</span>
                        <span>·</span>
                        <span>NAV ₹{scheme.nav?.toFixed(2)}</span>
                      </div>
                    </div>
                    <span
                      className={`shrink-0 px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 ${
                        isAlreadyAdded
                          ? 'bg-slate-100 dark:bg-[#141416] text-slate-500'
                          : 'bg-amber-600 text-white'
                      }`}
                    >
                      {isAlreadyAdded ? (
                        isTamil ? 'சேர்க்கப்பட்டது' : 'Added'
                      ) : (
                        <>
                          <Plus className="w-3 h-3" />
                          <span>{isTamil ? 'சேர்' : 'Add'}</span>
                        </>
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Watchlist Items */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3 text-xs bg-white dark:bg-[#1E1E24]">
          {watchedList.length === 0 ? (
            <div className="text-center py-12 text-slate-400 dark:text-slate-500">
              <Eye className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="font-medium text-slate-600 dark:text-slate-400">{isTamil ? 'உங்கள் கண்காணிப்பு பட்டியல் காலியாக உள்ளது.' : 'Your watchlist is empty.'}</p>
              <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                {isTamil ? '11,000+ தரவுத்தளத்தில் இருந்து திட்டங்களை சேர்க்க மேலே உள்ள தேடல் பட்டியைப் பயன்படுத்தவும்.' : 'Type in the search bar above to track any scheme from the 11,000+ database.'}
              </p>
            </div>
          ) : (
            watchedList.map((scheme) => (
              <div
                key={scheme.id}
                className="bg-white dark:bg-[#141416] border border-slate-200 dark:border-[#2E2E38] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-xs hover:border-amber-200 dark:hover:border-amber-700/60 transition-all"
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => removeFromWatchlist(scheme.id)}
                    className="text-amber-500 hover:text-red-500 pt-0.5 transition-colors cursor-pointer"
                    title={isTamil ? 'பட்டியலிலிருந்து நீக்கு' : 'Remove from watchlist'}
                  >
                    <Star className="w-4 h-4 fill-current" />
                  </button>
                  <div>
                    <button
                      onClick={() => {
                        onOpenSchemeDetail(scheme);
                        onClose();
                      }}
                      className="font-bold text-slate-900 dark:text-white hover:text-amber-700 dark:hover:text-amber-400 text-sm text-left transition-colors cursor-pointer"
                    >
                      {scheme.name}
                    </button>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      <span>{scheme.amc}</span>
                      <span>·</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300">{scheme.category}</span>
                      <span>·</span>
                      <span className="font-mono text-slate-400 dark:text-slate-500">{scheme.plan || 'Direct'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-5 border-t dark:border-[#2E2E38] sm:border-t-0 pt-2 sm:pt-0">
                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 block font-semibold">NAV</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      ₹{typeof scheme.nav === 'number' ? scheme.nav.toFixed(2) : scheme.nav}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] uppercase text-slate-400 block font-semibold">{isTamil ? '1ஆண் வருமானம்' : '1Y Ret'}</span>
                    <span
                      className={`font-mono font-bold ${
                        (scheme.return1Y || 0) >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'
                      }`}
                    >
                      {(scheme.return1Y || 0) >= 0 ? '+' : ''}
                      {typeof scheme.return1Y === 'number' ? scheme.return1Y.toFixed(1) : scheme.return1Y}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        onOpenSchemeDetail(scheme);
                        onClose();
                      }}
                      className="px-3 py-1.5 border border-slate-200 dark:border-[#2E2E38] hover:bg-slate-50 dark:hover:bg-[#1E1E24] rounded-lg text-slate-700 dark:text-slate-300 font-semibold text-[11px] cursor-pointer"
                    >
                      {isTamil ? 'விவரங்கள்' : 'Factsheet'}
                    </button>
                    <button
                      onClick={() => {
                        onAnalyzeSchemeWithDICE(scheme);
                        onClose();
                      }}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-[11px] flex items-center gap-1 shadow-xs cursor-pointer"
                    >
                      <span>{isTamil ? '20Q சோதனை' : '20Q Test'}</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-[#2E2E38] bg-slate-50/70 dark:bg-[#141416] flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            {isTamil ? 'கண்காணிப்பு மாற்றங்கள் உங்கள் உலாவியில் உள்ளூரில் சேமிக்கப்படும்.' : 'Watchlist changes are stored locally in your browser.'}
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
          >
            {isTamil ? 'மூடு' : 'Close Watchlist'}
          </button>
        </div>
      </div>
    </div>
  );
};
