/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Wealth Builder Funds Table connected to 11,000+ Schemes Pipeline
 * Synchronizes uploaded Excel schemes in real-time across all views and filters
 */

import React, { useState, useEffect, useCallback } from 'react';
import { MutualFundScheme } from '../types';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';
import {
  Download,
  Search,
  FileSpreadsheet,
  ChevronRight,
  ChevronLeft,
  Filter,
  Loader2,
  ExternalLink,
  ArrowUpDown,
} from 'lucide-react';

interface WealthBuilderTableProps {
  onSelectScheme: (scheme: MutualFundScheme) => void;
  onAnalyzeSchemeWithDICE: (scheme: MutualFundScheme) => void;
  onOpenUploadModal: () => void;
  externalCategoryFilter?: 'wealth' | 'tax' | 'income' | null;
}

type TableTab = 'snapshot' | 'returns' | 'portfolio' | 'risk' | 'nav' | 'fees';
type ObjectiveFilter = 'all' | 'wealth' | 'tax' | 'income' | 'hybrid' | 'commodities';

const TOP_AMCS = [
  'All AMCs',
  'HDFC Mutual Fund',
  'SBI Mutual Fund',
  'ICICI Prudential Mutual Fund',
  'Kotak Mahindra Mutual Fund',
  'Nippon India Mutual Fund',
  'Axis Mutual Fund',
  'Aditya Birla Sun Life Mutual Fund',
  'UTI Mutual Fund',
  'Mirae Asset Mutual Fund',
  'DSP Mutual Fund',
  'Parag Parikh Mutual Fund',
  'Quant Mutual Fund',
  'Tata Mutual Fund',
  'Bandhan Mutual Fund',
  'Motilal Oswal Mutual Fund',
  'Edelweiss Mutual Fund',
  'Canara Robeco Mutual Fund',
  'Franklin Templeton Mutual Fund',
];

export const WealthBuilderTable: React.FC<WealthBuilderTableProps> = ({
  onSelectScheme,
  onAnalyzeSchemeWithDICE,
  onOpenUploadModal,
  externalCategoryFilter,
}) => {
  const { t } = useLanguage();
  const { schemes: localSchemes, uploadedCount } = useSchemes();
  const [activeTab, setActiveTab] = useState<TableTab>('snapshot');

  // Filter States
  const [objectiveFilter, setObjectiveFilter] = useState<ObjectiveFilter>('all');
  const [selectedAmc, setSelectedAmc] = useState<string>('All AMCs');
  const [planFilter, setPlanFilter] = useState<'All' | 'Direct' | 'Regular'>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortBy, setSortBy] = useState<'aumCrores' | 'return1Y' | 'return3Y' | 'nav' | 'ter' | 'name'>('aumCrores');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Pagination States
  const [page, setPage] = useState<number>(1);
  const pageSize = 25;
  const [totalSchemesCount, setTotalSchemesCount] = useState<number>(11434);
  const [pipelineSchemes, setPipelineSchemes] = useState<MutualFundScheme[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sync with external category filter from Hero Cards
  useEffect(() => {
    if (externalCategoryFilter === 'wealth') {
      setObjectiveFilter('wealth');
      setSearchTerm('');
      setPage(1);
    } else if (externalCategoryFilter === 'tax') {
      setObjectiveFilter('tax');
      setSearchTerm('');
      setPage(1);
    } else if (externalCategoryFilter === 'income') {
      setObjectiveFilter('income');
      setSearchTerm('');
      setPage(1);
    }
  }, [externalCategoryFilter]);

  // Fetch from pipeline with debounce
  const fetchSchemes = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      params.append('limit', String(pageSize));
      params.append('offset', String((page - 1) * pageSize));
      params.append('sortBy', sortBy);
      params.append('sortOrder', sortOrder);

      if (searchTerm.trim()) {
        params.append('search', searchTerm.trim());
      }

      if (selectedAmc !== 'All AMCs') {
        params.append('amc', selectedAmc.replace(' Mutual Fund', ''));
      }

      if (planFilter !== 'All') {
        params.append('plan', planFilter);
      }

      // Objective filter to pipeline categories
      if (objectiveFilter === 'wealth') {
        params.append('broadCategory', 'Equity');
      } else if (objectiveFilter === 'tax') {
        params.append('category', 'ELSS');
      } else if (objectiveFilter === 'income') {
        params.append('broadCategory', 'Debt');
      } else if (objectiveFilter === 'hybrid') {
        params.append('broadCategory', 'Hybrid');
      } else if (objectiveFilter === 'commodities') {
        params.append('broadCategory', 'Commodities');
      }

      const res = await fetch(`/api/pipeline/schemes?${params.toString()}`);
      const json = await res.json();

      if (json.success && json.data) {
        const converted = (json.data.schemes || []).map((rec: NormalizedSchemeRecord) =>
          normalizeToMutualFundScheme(rec)
        );

        // Prepend custom uploaded schemes on Page 1 if matching
        let combined = converted;
        if (page === 1) {
          const customUploaded = localSchemes.filter((s) => s.id.startsWith('uploaded_') || s.isUploaded);
          if (customUploaded.length > 0) {
            combined = [...customUploaded, ...converted];
          }
        }

        setPipelineSchemes(combined);
        setTotalSchemesCount(json.data.total || 0);
      }
    } catch (err) {
      console.error('Failed to fetch pipeline schemes for table:', err);
    } finally {
      setIsLoading(false);
    }
  }, [page, pageSize, sortBy, sortOrder, searchTerm, selectedAmc, planFilter, objectiveFilter, localSchemes]);

  useEffect(() => {
    const handler = setTimeout(() => {
      fetchSchemes();
    }, 200);
    return () => clearTimeout(handler);
  }, [fetchSchemes]);

  // Handle Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Scheme Name',
      'AMC',
      'Category',
      'Category Code',
      'Broad Asset Class',
      'Plan',
      'Riskometer',
      'NAV (INR)',
      '1Y Return (%)',
      '3Y Return (%)',
      'AUM (Cr)',
      'TER (%)',
      'Sharpe Ratio',
      'Beta',
      'Benchmark',
    ];

    const rows = pipelineSchemes.map((s) => [
      `"${s.name}"`,
      `"${s.amc}"`,
      `"${s.category}"`,
      s.categoryCode,
      s.broadCategory,
      s.plan,
      `"${s.riskometer}"`,
      s.nav,
      s.return1Y,
      s.return3Y || 'Data unavailable',
      s.aumCrores,
      s.ter || 'Data unavailable',
      s.sharpeRatio || 'Data unavailable',
      s.beta || 'Data unavailable',
      `"${s.benchmark}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DICE_Mutual_Funds_11k_${objectiveFilter}_page_${page}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const totalPages = Math.max(1, Math.ceil(totalSchemesCount / pageSize));

  return (
    <section className="py-12 bg-white dark:bg-[#141416] border-b border-slate-200/80 dark:border-[#2E2E38] transition-colors duration-300" id="wealth-builder-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              <span>Verified Fund Universe</span>
              <span>·</span>
              <span>11,000+ Master Database</span>
              {uploadedCount > 0 && (
                <>
                  <span>·</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800">
                    {uploadedCount} Uploaded Schemes Active
                  </span>
                </>
              )}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-0.5">
              {t('wealth.title', 'Wealth Builder Funds')} ({totalSchemesCount.toLocaleString('en-IN')} {t('wealth.schemes', 'Schemes')})
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {t('wealth.desc', 'Browse, filter, and inspect mutual fund schemes across all regulatory categories and asset classes.')}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onOpenUploadModal}
              className="px-3.5 py-2 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 text-emerald-900 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
              <span>{t('wealth.import_excel', 'Import Scheme Excel')}</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-4 py-2 bg-slate-100 dark:bg-[#1E1E24] hover:bg-slate-200 dark:hover:bg-[#2A2A32] text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('wealth.export_csv', 'Export Page CSV')}</span>
            </button>
          </div>
        </div>

        {/* Objective Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: t('wealth.all_funds', 'All Funds (11k+)') },
            { id: 'wealth', label: t('wealth.wealth_growth', 'Wealth Growth (Equity)') },
            { id: 'tax', label: t('wealth.tax_saver', 'Tax Saver (ELSS 80C)') },
            { id: 'income', label: t('wealth.regular_income', 'Regular Income (Debt)') },
            { id: 'hybrid', label: t('wealth.hybrid_balanced', 'Hybrid & Balanced') },
            { id: 'commodities', label: t('wealth.commodities', 'Commodities (Gold/Silver)') },
          ].map((pill) => (
            <button
              key={pill.id}
              onClick={() => {
                setObjectiveFilter(pill.id as ObjectiveFilter);
                setPage(1);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                objectiveFilter === pill.id
                  ? 'bg-slate-900 dark:bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-[#1E1E24] text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-[#2A2A32] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>

        {/* Filters Bar matching PDF */}
        <div className="bg-[#FAF8F5] dark:bg-[#1E1E24] border border-[#EBE3D5] dark:border-[#2E2E38] rounded-2xl p-4 flex flex-wrap items-center gap-3 text-xs">
          {/* Fund House Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 dark:text-slate-400 font-semibold">Fund House:</span>
            <select
              value={selectedAmc}
              onChange={(e) => {
                setSelectedAmc(e.target.value);
                setPage(1);
              }}
              className="bg-white dark:bg-[#141416] border border-slate-300 dark:border-[#2E2E38] rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100 focus:outline-none"
            >
              {TOP_AMCS.map((amc) => (
                <option key={amc} value={amc}>
                  {amc}
                </option>
              ))}
            </select>
          </div>

          {/* Search Input across 11,000+ schemes */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              placeholder="Search scheme name, category or ISIN..."
              className="w-full bg-white dark:bg-[#141416] border border-slate-300 dark:border-[#2E2E38] rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Plan Toggle */}
          <div className="flex items-center gap-1 bg-white dark:bg-[#141416] border border-slate-300 dark:border-[#2E2E38] rounded-lg p-0.5">
            {(['All', 'Direct', 'Regular'] as const).map((p) => (
              <button
                key={p}
                onClick={() => {
                  setPlanFilter(p);
                  setPage(1);
                }}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                  planFilter === p
                    ? 'bg-slate-900 dark:bg-amber-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 dark:text-slate-400 font-semibold">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white dark:bg-[#141416] border border-slate-300 dark:border-[#2E2E38] rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100 focus:outline-none"
            >
              <option value="aumCrores">Highest AUM</option>
              <option value="return1Y">Highest 1Y Return</option>
              <option value="return3Y">Highest 3Y Return</option>
              <option value="nav">NAV</option>
              <option value="ter">Lowest Expense Ratio</option>
              <option value="name">Scheme Name (A-Z)</option>
            </select>
            <button
              onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
              className="p-1.5 bg-white dark:bg-[#141416] border border-slate-300 dark:border-[#2E2E38] rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-[#2A2A32] cursor-pointer"
              title="Toggle sort direction"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* View Tabs matching PDF (Snapshot, Returns, Portfolio, Risk, NAV Details, Fees) */}
        <div className="flex items-center gap-1 border-b border-slate-200 dark:border-[#2E2E38] overflow-x-auto scrollbar-none">
          {[
            { id: 'snapshot', label: t('wealth.tab_snapshot', 'Snapshot') },
            { id: 'returns', label: t('wealth.tab_returns', 'Returns') },
            { id: 'portfolio', label: t('wealth.tab_portfolio', 'Portfolio') },
            { id: 'risk', label: t('wealth.tab_risk', 'Risk') },
            { id: 'nav', label: t('wealth.tab_nav', 'NAV Details') },
            { id: 'fees', label: t('wealth.tab_fees', 'Fees & Details') },
          ].map((tTab) => (
            <button
              key={tTab.id}
              onClick={() => setActiveTab(tTab.id as TableTab)}
              className={`py-2.5 px-4 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors cursor-pointer ${
                activeTab === tTab.id
                  ? 'border-amber-600 text-slate-950 dark:text-white font-bold'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              {tTab.label}
            </button>
          ))}
        </div>

        {/* Table Content */}
        <div className="border border-slate-200 dark:border-[#2E2E38] rounded-2xl overflow-hidden shadow-xs overflow-x-auto relative min-h-[300px]">
          {isLoading && (
            <div className="absolute inset-0 bg-white/70 dark:bg-[#141416]/70 backdrop-blur-xs flex items-center justify-center z-10">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-700 dark:text-amber-400 bg-white dark:bg-[#1E1E24] px-4 py-2 rounded-xl shadow-md border border-amber-200 dark:border-[#2E2E38]">
                <Loader2 className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />
                <span>Loading schemes from database...</span>
              </div>
            </div>
          )}

          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 dark:bg-[#1E1E24] text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-[#2E2E38]">
              <tr>
                <th className="py-3 px-4 min-w-[260px]">{t('wealth.th_funds', 'Funds')}</th>
                {/* RATING REMOVED PER USER REQUEST */}
                {activeTab === 'snapshot' && (
                  <>
                    <th className="py-3 px-3 text-right">{t('wealth.th_1y_ret', '1 Yr Ret (%)')}</th>
                    <th className="py-3 px-3 text-left">{t('wealth.th_riskometer', 'Riskometer')}</th>
                    <th className="py-3 px-3 text-left">{t('wealth.th_category', 'Category')}</th>
                    <th className="py-3 px-3 text-left min-w-[180px]">{t('wealth.th_mandate', 'Mandate / Objective')}</th>
                    <th className="py-3 px-3 text-right">{t('wealth.th_ter', 'TER (%)')}</th>
                    <th className="py-3 px-3 text-right">{t('wealth.th_plan', 'Plan')}</th>
                    <th className="py-3 px-4 text-right">{t('wealth.th_aum', 'Net Assets (Cr)')}</th>
                  </>
                )}
                {activeTab === 'returns' && (
                  <>
                    <th className="py-3 px-3 text-right">1 Day</th>
                    <th className="py-3 px-3 text-right">1 Month</th>
                    <th className="py-3 px-3 text-right">1 Year</th>
                    <th className="py-3 px-3 text-right">3 Years</th>
                    <th className="py-3 px-3 text-right">5 Years</th>
                    <th className="py-3 px-4 text-right">Inception</th>
                  </>
                )}
                {activeTab === 'portfolio' && (
                  <>
                    <th className="py-3 px-3 text-right">Equity %</th>
                    <th className="py-3 px-3 text-right">Debt %</th>
                    <th className="py-3 px-3 text-right">Cash %</th>
                    <th className="py-3 px-3 text-left min-w-[180px]">Top Holding</th>
                    <th className="py-3 px-4 text-left">Benchmark</th>
                  </>
                )}
                {activeTab === 'risk' && (
                  <>
                    <th className="py-3 px-3 text-right">Std Dev (%)</th>
                    <th className="py-3 px-3 text-right">Beta</th>
                    <th className="py-3 px-3 text-right">Sharpe</th>
                    <th className="py-3 px-3 text-right">Alpha</th>
                    <th className="py-3 px-4 text-right">Max Drawdown</th>
                  </>
                )}
                {activeTab === 'nav' && (
                  <>
                    <th className="py-3 px-3 text-right">NAV (₹)</th>
                    <th className="py-3 px-3 text-left">NAV Date</th>
                    <th className="py-3 px-3 text-right">Min Investment</th>
                    <th className="py-3 px-4 text-right">Min SIP</th>
                  </>
                )}
                {activeTab === 'fees' && (
                  <>
                    <th className="py-3 px-3 text-right">TER (%)</th>
                    <th className="py-3 px-3 text-left min-w-[220px]">Exit Load</th>
                    <th className="py-3 px-3 text-left">Lock-in</th>
                    <th className="py-3 px-4 text-right">Option</th>
                  </>
                )}
                <th className="py-3 px-4 text-center">{t('wealth.th_action', 'Action')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
              {pipelineSchemes.length === 0 && !isLoading ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-500 dark:text-slate-400">
                    No mutual fund schemes match your current criteria.
                  </td>
                </tr>
              ) : (
                pipelineSchemes.map((scheme) => (
                  <tr key={scheme.id} className="hover:bg-slate-50/70 dark:hover:bg-[#1E1E24]/60 transition-colors">
                    {/* Scheme Name */}
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white">
                      <button
                        onClick={() => onSelectScheme(scheme)}
                        className="text-left hover:text-amber-700 dark:hover:text-amber-400 transition-colors block font-bold cursor-pointer"
                      >
                        {scheme.name}
                      </button>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400 font-normal mt-0.5 flex-wrap">
                        <span>{scheme.amc}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400 dark:text-slate-500">{scheme.plan}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400 dark:text-slate-500">Code: {scheme.code}</span>
                        {scheme.id.startsWith('uploaded_') && (
                          <span className="text-[9px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold px-1.5 py-0.2 rounded">
                            Custom Upload
                          </span>
                        )}
                      </div>
                    </td>

                    {/* RATING COLUMN REMOVED PER USER REQUEST */}

                    {/* Tab-specific Cells */}
                    {activeTab === 'snapshot' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {scheme.return1Y !== null && scheme.return1Y !== 0
                            ? `${scheme.return1Y > 0 ? '+' : ''}${scheme.return1Y}%`
                            : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-left text-slate-700 font-medium">
                          {scheme.riskometer || 'Moderate'}
                        </td>
                        <td className="py-3.5 px-3 text-left font-mono text-slate-600">
                          {scheme.categoryCode || scheme.category}
                        </td>
                        <td className="py-3.5 px-3 text-left text-slate-500 line-clamp-1 italic text-[11px] max-w-[200px]">
                          {scheme.opinion}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono text-slate-800 tabular-nums">
                          {scheme.ter ? `${scheme.ter}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right text-slate-600 font-mono">
                          {scheme.plan}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                          {scheme.aumCrores ? `₹${scheme.aumCrores.toLocaleString('en-IN')} Cr` : 'Data unavailable'}
                        </td>
                      </>
                    )}

                    {activeTab === 'returns' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          +{scheme.return1D}%
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          +{scheme.return1M}%
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {scheme.return1Y ? `${scheme.return1Y > 0 ? '+' : ''}${scheme.return1Y}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {scheme.return3Y ? `+${scheme.return3Y}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {scheme.return5Y ? `+${scheme.return5Y}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                          {scheme.returnSinceInception ? `+${scheme.returnSinceInception}%` : 'Data unavailable'}
                        </td>
                      </>
                    )}

                    {activeTab === 'portfolio' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums">{scheme.equityAllocation}%</td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums">{scheme.debtAllocation}%</td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums">{scheme.cashAllocation}%</td>
                        <td className="py-3.5 px-3 text-slate-800 font-medium truncate max-w-[180px]">
                          {scheme.topHoldings[0]?.company || 'SEBI Monthly Filing'}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 truncate max-w-[180px]">
                          {scheme.benchmark || 'Data unavailable'}
                        </td>
                      </>
                    )}

                    {activeTab === 'risk' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-800">
                          {scheme.standardDeviation ? `${scheme.standardDeviation}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-800">
                          {scheme.beta || 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {scheme.sharpeRatio || 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-800">
                          {scheme.alpha ? `+${scheme.alpha}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-rose-700 tabular-nums">
                          {scheme.maxDrawdown ? `${scheme.maxDrawdown}%` : 'Data unavailable'}
                        </td>
                      </>
                    )}

                    {activeTab === 'nav' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                          ₹{scheme.nav ? scheme.nav.toFixed(2) : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-slate-500 font-mono">{scheme.navDate}</td>
                        <td className="py-3.5 px-3 text-right font-mono">₹{scheme.minInvestment}</td>
                        <td className="py-3.5 px-4 text-right font-mono">₹{scheme.minSip}</td>
                      </>
                    )}

                    {activeTab === 'fees' && (
                      <>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900">
                          {scheme.ter ? `${scheme.ter}%` : 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-slate-600 text-[11px] truncate max-w-[220px]">
                          {scheme.exitLoad || 'Data unavailable'}
                        </td>
                        <td className="py-3.5 px-3 text-slate-800">{scheme.lockInPeriod || 'Nil'}</td>
                        <td className="py-3.5 px-4 text-right font-mono">{scheme.option}</td>
                      </>
                    )}

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onSelectScheme(scheme)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-[#1E1E24] dark:hover:bg-[#2A2A32] text-slate-800 dark:text-slate-200 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          {t('common.view_details', 'Details')}
                        </button>
                        <button
                          onClick={() => onAnalyzeSchemeWithDICE(scheme)}
                          className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-lg text-[11px] font-bold transition-colors inline-flex items-center gap-1 cursor-pointer"
                        >
                          <span>Analyze</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 text-xs text-slate-600 dark:text-slate-400">
          <div>
            Showing <strong className="font-semibold text-slate-900 dark:text-white">{(page - 1) * pageSize + 1}</strong> to{' '}
            <strong className="font-semibold text-slate-900 dark:text-white">
              {Math.min(page * pageSize, totalSchemesCount).toLocaleString('en-IN')}
            </strong>{' '}
            of <strong className="font-semibold text-slate-900 dark:text-white">{totalSchemesCount.toLocaleString('en-IN')}</strong> schemes
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-[#2E2E38] bg-white dark:bg-[#1E1E24] hover:bg-slate-50 dark:hover:bg-[#2A2A32] text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <span className="font-mono px-2 py-1 bg-slate-100 dark:bg-[#1E1E24] rounded-md text-slate-800 dark:text-slate-200 font-semibold border border-transparent dark:border-[#2E2E38]">
              Page {page} of {totalPages}
            </span>

            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-[#2E2E38] bg-white dark:bg-[#1E1E24] hover:bg-slate-50 dark:hover:bg-[#2A2A32] text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
