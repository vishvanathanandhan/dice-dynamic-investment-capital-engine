/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Fund Monitor Heatmap Table dynamically computed from SchemeContext & 11,000+ Pipeline
 * Shows Category Multi-Timeframe Heatmap and Top Performing Schemes Leaderboard
 */

import React, { useState, useEffect } from 'react';
import { useSchemes } from '../context/SchemeContext';
import { useLanguage } from '../context/LanguageContext';
import { BroadAssetCategory, MutualFundScheme } from '../types';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';
import { TrendingUp, BarChart3, Star, ExternalLink, Loader2 } from 'lucide-react';

interface ComputedMonitorRow {
  category: string;
  type: BroadAssetCategory;
  fundCount: number;
  ret1D: number;
  retYTD: number;
  ret1W: number;
  ret1M: number;
  ret3M: number;
  ret1Y: number;
  ret3Y: number;
  ret5Y: number;
  ret10Y: number;
}

interface FundMonitorHeatmapProps {
  onSelectScheme?: (scheme: MutualFundScheme) => void;
}

export const FundMonitorHeatmap: React.FC<FundMonitorHeatmapProps> = ({ onSelectScheme }) => {
  const { t } = useLanguage();
  const { schemes } = useSchemes();
  const [filterType, setFilterType] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'heatmap' | 'top_schemes'>('top_schemes');

  // Top schemes loaded from 11,000+ pipeline (reduced to Top 10)
  const [topSchemes, setTopSchemes] = useState<MutualFundScheme[]>([]);
  const [isLoadingTop, setIsLoadingTop] = useState(false);

  // Real-time category heatmap data
  const [heatmapRows, setHeatmapRows] = useState<ComputedMonitorRow[]>([]);
  const [isLoadingHeatmap, setIsLoadingHeatmap] = useState(false);

  // Fetch real-time Top 10 schemes
  useEffect(() => {
    setIsLoadingTop(true);
    const catParam = filterType !== 'All' ? `&broadCategory=${filterType}` : '';
    fetch(`/api/pipeline/schemes?limit=10&sortBy=return1Y&sortOrder=desc${catParam}`)
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.data) {
          const converted = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );
          setTopSchemes(converted);
        }
      })
      .catch((e) => console.error('Failed to load top monitor schemes', e))
      .finally(() => setIsLoadingTop(false));
  }, [filterType]);

  // Fetch real-time category heatmap from pipeline
  useEffect(() => {
    setIsLoadingHeatmap(true);
    fetch('/api/pipeline/heatmap')
      .then((res) => res.json())
      .then((json) => {
        if (json.success && Array.isArray(json.data) && json.data.length > 0) {
          setHeatmapRows(json.data);
        }
      })
      .catch((e) => console.error('Failed to load real-time heatmap', e))
      .finally(() => setIsLoadingHeatmap(false));
  }, []);

  const filteredData =
    filterType === 'All'
      ? heatmapRows
      : heatmapRows.filter((row) => row.type === filterType);

  // Return cell background styling for heatmap
  const getHeatmapColor = (val: number) => {
    if (val >= 20) return 'bg-[#86efac]/80 text-[#064e3b] font-bold'; // strong green
    if (val >= 10) return 'bg-[#bbf7d0]/80 text-[#14532d] font-semibold'; // mid green
    if (val > 0) return 'bg-[#dcfce7]/70 text-[#166534]'; // soft green
    if (val === 0) return 'bg-slate-100 text-slate-700';
    if (val > -3) return 'bg-[#fef3c7]/80 text-[#78350f]'; // light amber
    if (val > -6) return 'bg-[#fed7aa]/80 text-[#7c2d12]'; // orange-red
    return 'bg-[#fecaca]/80 text-[#7f1d1d] font-semibold'; // red
  };

  return (
    <section className="py-10 bg-white dark:bg-[#141416] border-b border-slate-200/80 dark:border-[#2E2E38] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              <span>Performance Tracker</span>
              <span>·</span>
              <span>11,000+ Verified Universe</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-0.5">
              {t('monitor.heading', 'Fund Monitor')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t('monitor.subheading', 'Live multi-timeframe category matrix & top performing mutual fund schemes across India.')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#1E1E24] rounded-xl text-xs font-semibold">
              <button
                onClick={() => setViewMode('top_schemes')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'top_schemes'
                    ? 'bg-white dark:bg-[#141416] text-slate-950 dark:text-white font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>{t('monitor.leaderboard_title', 'Top Schemes Leaderboard')}</span>
              </button>
              <button
                onClick={() => setViewMode('heatmap')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'heatmap'
                    ? 'bg-white dark:bg-[#141416] text-slate-950 dark:text-white font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
                <span>Category Heatmap</span>
              </button>
            </div>

            {/* Category Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#1E1E24] rounded-xl text-xs font-medium overflow-x-auto">
              {[
                { id: 'All', label: 'All Assets' },
                { id: 'Equity', label: t('cat.equity', 'Equity') },
                { id: 'Debt', label: t('cat.debt', 'Debt') },
                { id: 'Hybrid', label: t('cat.hybrid', 'Hybrid') },
                { id: 'Commodities', label: t('cat.commodities', 'Commodities') },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterType(tab.id)}
                  className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                    filterType === tab.id
                      ? 'bg-white dark:bg-[#141416] text-slate-900 dark:text-white font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* View 1: Top Schemes Leaderboard */}
        {viewMode === 'top_schemes' && (
          <div className="border border-slate-200 dark:border-[#2E2E38] rounded-2xl overflow-hidden shadow-xs overflow-x-auto relative">
            {isLoadingTop && (
              <div className="absolute inset-0 bg-white/70 dark:bg-[#141416]/70 backdrop-blur-xs flex items-center justify-center z-10">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-700 dark:text-amber-400 bg-white dark:bg-[#1E1E24] px-4 py-2 rounded-xl shadow border border-amber-200 dark:border-[#2E2E38]">
                  <Loader2 className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />
                  <span>Loading top schemes...</span>
                </div>
              </div>
            )}
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-[#1E1E24] text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-[#2E2E38]">
                <tr>
                  <th className="py-3 px-4 min-w-[260px]">Top Performing Scheme</th>
                  <th className="py-3 px-3 text-left">Category</th>
                  <th className="py-3 px-3 text-right">1Y Return</th>
                  <th className="py-3 px-3 text-right">3Y CAGR</th>
                  <th className="py-3 px-3 text-right">NAV (₹)</th>
                  <th className="py-3 px-3 text-right">AUM (Cr)</th>
                  <th className="py-3 px-3 text-right">TER</th>
                  <th className="py-3 px-3 text-left">Riskometer</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                {topSchemes.map((scheme, idx) => (
                  <tr key={scheme.id} className="hover:bg-slate-50/70 dark:hover:bg-[#1E1E24]/60 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-[#1E1E24] text-slate-700 dark:text-slate-300 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <div className="min-w-0">
                          <button
                            onClick={() => onSelectScheme && onSelectScheme(scheme)}
                            className="font-bold text-slate-900 dark:text-white hover:text-amber-700 dark:hover:text-amber-400 transition-colors text-left truncate block cursor-pointer"
                          >
                            {scheme.name}
                          </button>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-normal">
                            {scheme.amc} · <span className="font-mono text-slate-400 dark:text-slate-500">{scheme.plan}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-600 dark:text-slate-300">
                      {scheme.category}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      {scheme.return1Y ? `+${scheme.return1Y}%` : 'Data unavailable'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      {scheme.return3Y ? `+${scheme.return3Y}%` : 'Data unavailable'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      ₹{scheme.nav ? scheme.nav.toFixed(2) : 'N/A'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {scheme.aumCrores ? `₹${scheme.aumCrores.toLocaleString('en-IN')} Cr` : 'Data unavailable'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-700 dark:text-slate-300">
                      {scheme.ter ? `${scheme.ter}%` : 'Data unavailable'}
                    </td>
                    <td className="py-3 px-3 text-slate-700 dark:text-slate-300 font-medium">
                      {scheme.riskometer || 'Moderate'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {onSelectScheme && (
                        <button
                          onClick={() => onSelectScheme(scheme)}
                          className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          {t('common.view_details', 'View Factsheet')}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* View 2: Multi-Timeframe Heatmap Table */}
        {viewMode === 'heatmap' && (
          <div className="border border-slate-200 dark:border-[#2E2E38] rounded-2xl overflow-hidden shadow-xs overflow-x-auto relative min-h-[200px]">
            {isLoadingHeatmap && (
              <div className="absolute inset-0 bg-white/70 dark:bg-[#141416]/70 backdrop-blur-2xs flex items-center justify-center z-10">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-700 dark:text-amber-400 bg-white dark:bg-[#1E1E24] px-4 py-2 rounded-xl shadow border border-amber-200 dark:border-[#2E2E38]">
                  <Loader2 className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />
                  <span>Loading real-time category performance...</span>
                </div>
              </div>
            )}
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-[#1E1E24] text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-[#2E2E38]">
                <tr>
                  <th className="py-3 px-4 min-w-[220px]">Category</th>
                  <th className="py-3 px-3 text-center">Funds</th>
                  <th className="py-3 px-3 text-right">1 Day</th>
                  <th className="py-3 px-3 text-right">YTD</th>
                  <th className="py-3 px-3 text-right">1 Week</th>
                  <th className="py-3 px-3 text-right">1 Month</th>
                  <th className="py-3 px-3 text-right">3 Months</th>
                  <th className="py-3 px-3 text-right">1 Year</th>
                  <th className="py-3 px-3 text-right">3 Years</th>
                  <th className="py-3 px-3 text-right">5 Years</th>
                  <th className="py-3 px-4 text-right">10 Years</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38]">
                {filteredData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-[#1E1E24]/50">
                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                      {row.category}
                    </td>
                    <td className="py-3 px-3 text-center font-mono text-slate-500 dark:text-slate-400">
                      {row.fundCount}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret1D)}`}>
                      {row.ret1D > 0 ? `+${row.ret1D.toFixed(2)}` : row.ret1D.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.retYTD)}`}>
                      {row.retYTD > 0 ? `+${row.retYTD.toFixed(2)}` : row.retYTD.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret1W)}`}>
                      {row.ret1W > 0 ? `+${row.ret1W.toFixed(2)}` : row.ret1W.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret1M)}`}>
                      {row.ret1M > 0 ? `+${row.ret1M.toFixed(2)}` : row.ret1M.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret3M)}`}>
                      {row.ret3M > 0 ? `+${row.ret3M.toFixed(2)}` : row.ret3M.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret1Y)}`}>
                      {row.ret1Y > 0 ? `+${row.ret1Y.toFixed(2)}` : row.ret1Y.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret3Y)}`}>
                      {row.ret3Y > 0 ? `+${row.ret3Y.toFixed(2)}` : row.ret3Y.toFixed(2)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono tabular-nums ${getHeatmapColor(row.ret5Y)}`}>
                      {row.ret5Y > 0 ? `+${row.ret5Y.toFixed(2)}` : row.ret5Y.toFixed(2)}
                    </td>
                    <td className={`py-3 px-4 text-right font-mono tabular-nums ${getHeatmapColor(row.ret10Y)}`}>
                      {row.ret10Y > 0 ? `+${row.ret10Y.toFixed(2)}` : row.ret10Y.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
};
