/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE Engine Results & Explainability View
 * Up to 3 eligible schemes with 5-dimension scoring, why matches/why not, and profile diagnosis
 */

import React, { useState } from 'react';
import {
  MatchAnalysisResponse,
  DICEScoringResult,
  MutualFundScheme
} from '../types';
import { RiskometerGauge } from './RiskometerGauge';
import { useLanguage } from '../context/LanguageContext';
import {
  Sparkles,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  ArrowRight,
  SlidersHorizontal,
  ChevronDown,
  Info,
  ExternalLink,
  Percent,
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';

interface ResultsViewProps {
  data: MatchAnalysisResponse;
  onRetake: () => void;
  onOpenSchemeDetail: (scheme: MutualFundScheme, diceResult?: DICEScoringResult) => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  data,
  onRetake,
  onOpenSchemeDetail,
}) => {
  const { investorProfile, topMatches, allEvaluations, executiveSummary } = data;
  const [showIneligible, setShowIneligible] = useState(false);
  const [selectedCalcRate, setSelectedCalcRate] = useState<number>(10);
  const { isTamil } = useLanguage();

  const ineligibleSchemes = allEvaluations.filter((s) => !s.isEligible);

  const getMatchBadgeStyle = (label: string) => {
    switch (label) {
      case 'High Match':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800';
      case 'Medium Match':
        return 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800';
      case 'Low Match':
        return 'bg-orange-50 text-orange-800 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* 1. Header Banner & Executive Summary */}
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-[#2E2E38]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
              <span>{isTamil ? 'DICE இயந்திரப் பொருத்தம் அறிக்கை' : 'DICE Engine Suitability Report'}</span>
              <span>·</span>
              <span>{isTamil ? 'டைனமிக் முதலீட்டு மூலதன இயந்திரம்' : 'Dynamic Investment Capital Engine'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {isTamil ? `${investorProfile.name} க்கான பிரத்தியேக முதலீட்டு பகுப்பாய்வு` : `Personalized Investment Insights for ${investorProfile.name}`}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isTamil
                ? 'NISM Series V-A கோட்பாடுகளின்படி · DICE முதன்மை மதிப்பீட்டு கட்டமைப்பு மூலம் கணக்கிடப்பட்டது'
                : 'Grounded in NISM Series V-A Principles · Formulated as per DICE Master Scoring Architecture'}
            </p>
          </div>

          <button
            onClick={onRetake}
            className="self-start md:self-auto px-4 py-2 border border-slate-200 dark:border-[#2E2E38] rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#141416] flex items-center gap-1.5 transition-colors shrink-0"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{isTamil ? '20Q சோதனையை மீண்டும் செய்' : 'Retake 20Q Diagnostic'}</span>
          </button>
        </div>

        {/* Executive Summary Card with Gemini AI synthesis */}
        <div className="mt-6 bg-slate-50 dark:bg-[#141416] rounded-2xl p-5 border border-slate-200/80 dark:border-[#2E2E38]">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white mb-2">
            <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>{isTamil ? 'முக்கிய முடிவுகள் & பொருத்த சுருக்கம்' : 'AI Executive Brief & Suitability Synthesis'}</span>
          </div>
          <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
            {executiveSummary}
          </div>
        </div>

        {/* Investor Profile Diagnostics Grid */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38]">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">{isTamil ? 'அபாய பிரிவு' : 'Risk Category'}</div>
            <div className="text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {investorProfile.riskProfileCategory}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">
              DICE Score: {investorProfile.overallRiskScore}/100
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38]">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">{isTamil ? 'அபாயத் திறன் vs விருப்பம்' : 'Risk Capacity vs Willingness'}</div>
            <div className="text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {investorProfile.riskCapacityScore} / {investorProfile.riskWillingnessScore}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              {isTamil ? 'நிதி திறன் vs மனப்பான்மை' : 'Financial Ability vs Psychology'}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38]">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">{isTamil ? 'இலக்கு & காலம்' : 'Goal & Horizon'}</div>
            <div className="text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {investorProfile.timeHorizonYears} {isTamil ? 'ஆண்டுகள்' : 'Years'}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
              {investorProfile.goal}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#141416] border border-slate-100 dark:border-[#2E2E38]">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase">{isTamil ? 'இலக்கு சொத்து ஒதுக்கீடு' : 'Target Asset Allocation'}</div>
            <div className="text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {investorProfile.targetAssetAllocation.equity}% {isTamil ? 'பங்கு' : 'Equity'}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              {investorProfile.targetAssetAllocation.debt}% {isTamil ? 'கடன்' : 'Debt'} · {investorProfile.targetAssetAllocation.gold}% {isTamil ? 'தங்கம்' : 'Gold'}
            </div>
          </div>
        </div>

        {/* Behavioral Biases Diagnosed Banner */}
        {investorProfile.detectedBiases.length > 0 && (
          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-[#2E2E38]">
            <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>{isTamil ? 'கண்டறியப்பட்ட முதலீட்டாளர் நடத்தை குணங்கள்' : 'Diagnosed Investor Behavioral Characters'}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {investorProfile.detectedBiases.map((b, idx) => (
                <div key={idx} className="bg-amber-50/60 dark:bg-[#141416] border border-amber-200/80 dark:border-amber-900/50 rounded-xl p-3.5">
                  <div className="text-xs font-bold text-amber-900 dark:text-amber-300">{b.bias}</div>
                  <div className="text-[11px] text-slate-700 dark:text-slate-300 mt-0.5">{b.description}</div>
                  <div className="text-[11px] text-amber-800 dark:text-amber-400 font-medium mt-1">
                    <span className="font-bold">{isTamil ? 'தணிக்கும் முறை: ' : 'Mitigation: '}</span>
                    {b.mitigationStrategy}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 2. Top Eligible Scheme Matches (Up to 3, never forced) */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              {isTamil ? `பொருத்தமான நிதி திட்டங்கள் (${topMatches.length} கண்டறியப்பட்டது)` : `Eligible Scheme Matches (${topMatches.length} Found)`}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isTamil ? 'அனைத்து கடினமான பொருத்தம், கால அளவு மற்றும் பணப்புழக்க நிபந்தனைகளை நிறைவு செய்தவை.' : 'Passed all hard suitability filters, horizon criteria, and liquidity constraints.'}
            </p>
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-lg px-3 py-1.5 font-mono">
            DICE Scoring: 0.30(S) + 0.25(R) + 0.20(P) + 0.15(T) + 0.10(X)
          </div>
        </div>

        {topMatches.length === 0 ? (
          <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-2xl p-10 text-center">
            <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {isTamil ? 'பொருத்தமான திட்டங்கள் எதுவும் தேர்வாகவில்லை' : 'No Suitable Schemes Passed Hard Eligibility'}
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-lg mx-auto mt-2">
              {isTamil
                ? 'உங்கள் முதலீட்டு கால அளவு அல்லது பணப்புழக்க தேவைகள் இருக்கும் அபாய வரம்பிற்கு பொருந்தவில்லை. DICE கட்டாய பரிந்துரைகளை தவிர்க்கிறது.'
                : 'Your stated investment horizon or liquidity requirements are incompatible with the available risk spectrum. The DICE Engine refuses to force recommendations that would violate investor suitability.'}
            </p>
            <button
              onClick={onRetake}
              className="mt-5 px-5 py-2.5 bg-slate-900 dark:bg-amber-600 hover:dark:bg-amber-500 text-white rounded-xl text-xs font-bold"
            >
              {isTamil ? 'வினாத்தாள் அளவுருக்களை மாற்றுங்கள்' : 'Adjust Questionnaire Parameters'}
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {topMatches.map((match) => {
              const { scheme } = match;
              return (
                <div
                  key={scheme.id}
                  className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 sm:p-8 shadow-xs hover:shadow-md transition-shadow duration-200"
                >
                  {/* Top Bar of the Scheme Card */}
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-slate-100 dark:border-[#2E2E38]">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">{scheme.amc}</span>
                        <span className="text-slate-300 dark:text-slate-600">·</span>
                        <span className="text-xs font-medium text-slate-600 dark:text-slate-300">{scheme.category}</span>
                        <span className="text-slate-300 dark:text-slate-600">·</span>
                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{scheme.plan} Plan ({scheme.option})</span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white leading-snug">
                        {scheme.name}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 italic max-w-2xl">{scheme.opinion}</p>
                    </div>

                    <div className="flex flex-row md:flex-col items-center md:items-end justify-between gap-2 shrink-0">
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-[10px] uppercase font-semibold text-slate-400 dark:text-slate-400">DICE Score</div>
                          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono tabular-nums leading-none">
                            {match.totalScore}
                            <span className="text-xs text-slate-400 font-normal">/100</span>
                          </div>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-bold border ${getMatchBadgeStyle(
                            match.matchLabel
                          )}`}
                        >
                          {match.matchLabel}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 dark:text-slate-400 font-mono">Rank #{match.rank} Match</div>
                    </div>
                  </div>

                  {/* 5 Dimension Meters Breakdown */}
                  <div className="mt-6">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                      {isTamil ? 'DICE 5-பரிமாண மதிப்பீட்டு விவரம்' : 'DICE 5-Dimension Scorecard Breakdown'}
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      {/* Suitability (30%) */}
                      <div className="bg-slate-50 dark:bg-[#141416] rounded-xl p-3 border border-slate-100 dark:border-[#2E2E38]">
                        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-medium">
                          <span>{isTamil ? 'பொருத்தம்' : 'Suitability'} (30%)</span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white">{match.suitabilityScore.score}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-amber-600 dark:bg-amber-500 h-1.5 rounded-full"
                            style={{ width: `${match.suitabilityScore.score}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">{isTamil ? 'இலக்கு & காலம் பொருத்தம்' : 'Goal & horizon fit'}</div>
                      </div>

                      {/* Risk (25%) */}
                      <div className="bg-slate-50 dark:bg-[#141416] rounded-xl p-3 border border-slate-100 dark:border-[#2E2E38]">
                        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-medium">
                          <span>{isTamil ? 'அபாயம்' : 'Risk'} (25%)</span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white">{match.riskScore.score}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-blue-600 dark:bg-blue-500 h-1.5 rounded-full"
                            style={{ width: `${match.riskScore.score}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">{isTamil ? 'இழப்பு திறன் பொருத்தம்' : 'Loss capacity fit'}</div>
                      </div>

                      {/* Performance (20%) */}
                      <div className="bg-slate-50 dark:bg-[#141416] rounded-xl p-3 border border-slate-100 dark:border-[#2E2E38]">
                        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-medium">
                          <span>{isTamil ? 'செயல்திறன்' : 'Performance'} (20%)</span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white">{match.performanceScore.score}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-emerald-600 dark:bg-emerald-500 h-1.5 rounded-full"
                            style={{ width: `${match.performanceScore.score}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">{isTamil ? 'ஷார்ப் & நிலைத்தன்மை' : 'Sharpe & consistency'}</div>
                      </div>

                      {/* Return (15%) */}
                      <div className="bg-slate-50 dark:bg-[#141416] rounded-xl p-3 border border-slate-100 dark:border-[#2E2E38]">
                        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-medium">
                          <span>{isTamil ? 'வருமானம்' : 'Return'} (15%)</span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white">{match.returnScore.score}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-indigo-600 dark:bg-indigo-500 h-1.5 rounded-full"
                            style={{ width: `${match.returnScore.score}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">1Y/3Y/5Y {isTamil ? 'வருமானங்கள்' : 'rolling'}</div>
                      </div>

                      {/* Tax & Exit (10%) */}
                      <div className="bg-slate-50 dark:bg-[#141416] rounded-xl p-3 border border-slate-100 dark:border-[#2E2E38] col-span-2 sm:col-span-1">
                        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-medium">
                          <span>{isTamil ? 'வரி & கட்டணம்' : 'Tax & Exit'} (10%)</span>
                          <span className="font-mono font-bold text-slate-900 dark:text-white">{match.taxAndExitScore.score}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-purple-600 dark:bg-purple-500 h-1.5 rounded-full"
                            style={{ width: `${match.taxAndExitScore.score}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">{isTamil ? 'லாக்-இன் & TER' : 'Lock-in & TER drag'}</div>
                      </div>
                    </div>
                  </div>

                  {/* Scheme Key Financial Metrics Strip */}
                  <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 py-4 px-5 bg-slate-50/70 dark:bg-[#141416] rounded-2xl border border-slate-100 dark:border-[#2E2E38] text-xs">
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">{isTamil ? 'சமீபத்திய NAV' : 'Latest NAV'}</span>
                      <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">₹{scheme.nav.toFixed(2)}</div>
                      <span className="text-[10px] text-slate-400">{scheme.navDate}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">{isTamil ? '3-ஆண்டு CAGR' : '3-Yr CAGR'}</span>
                      <div className="text-sm font-bold text-emerald-700 dark:text-emerald-400 font-mono">
                        {scheme.return3Y ? `+${scheme.return3Y}%` : 'N/A'}
                      </div>
                      <span className="text-[10px] text-slate-400">1Y: +{scheme.return1Y}%</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">Sharpe / Beta</span>
                      <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                        {scheme.sharpeRatio} / {scheme.beta}
                      </div>
                      <span className="text-[10px] text-slate-400">504-day sample</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">{isTamil ? 'செலவு விகிதம் (TER)' : 'TER (Direct)'}</span>
                      <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">{scheme.ter}%</div>
                      <span className="text-[10px] text-slate-400">{isTamil ? 'ஆண்டுதோறும்' : 'Annualized'}</span>
                    </div>

                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">{isTamil ? 'நிதி AUM' : 'Fund AUM'}</span>
                      <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                        ₹{(scheme.aumCrores / 1000).toFixed(1)}k Cr
                      </div>
                      <span className="text-[10px] text-slate-400">{isTamil ? 'சொத்து அளவு' : 'Asset size'}</span>
                    </div>

                    <div className="flex items-center justify-between sm:justify-start gap-2">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-semibold text-slate-400 uppercase">{isTamil ? 'அபாயமானி' : 'Riskometer'}</span>
                        <span className="text-xs font-bold text-slate-900 dark:text-white">{scheme.riskometer}</span>
                      </div>
                    </div>
                  </div>

                  {/* Why this matches you vs Potential Mismatches */}
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Why matches */}
                    <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-[#141416] border border-emerald-100 dark:border-emerald-900/40">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-300 mb-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>{isTamil ? 'உங்கள் சுயவிவரத்திற்கு இது ஏன் பொருந்துகிறது:' : 'Why this matches your DICE profile:'}</span>
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                        {match.whyMatches.map((reason, rIdx) => (
                          <li key={rIdx} className="flex items-start gap-2">
                            <span className="text-emerald-600 dark:text-emerald-400 font-bold">·</span>
                            <span>{reason}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Potential limitations */}
                    <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-[#141416] border border-amber-100 dark:border-amber-900/40">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 dark:text-amber-300 mb-2">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                        <span>{isTamil ? 'முக்கிய எச்சரிக்கைகள் & வரம்புகள்:' : 'Important caveats & key limitations:'}</span>
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                        {match.whyNotMatches.length > 0 ? (
                          match.whyNotMatches.map((limitation, lIdx) => (
                            <li key={lIdx} className="flex items-start gap-2">
                              <span className="text-amber-600 dark:text-amber-400 font-bold">·</span>
                              <span>{limitation}</span>
                            </li>
                          ))
                        ) : (
                          <li className="flex items-start gap-2">
                            <span className="text-amber-600 dark:text-amber-400 font-bold">·</span>
                            <span>{isTamil ? 'சாதாரண பங்குச் சந்தை ஏற்ற இறக்கங்கள் NAV மதிப்பை மாற்றும்.' : 'Standard equity volatility: NAV fluctuates with general market cycles.'}</span>
                          </li>
                        )}
                        <li className="flex items-start gap-2">
                          <span className="text-amber-600 dark:text-amber-400 font-bold">·</span>
                          <span>{isTamil ? 'வெளியேறும் கட்டணம்: ' : 'Exit load: '}{scheme.exitLoad}</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  {/* Approximate Future Value Projections */}
                  <div className="mt-6 pt-5 border-t border-slate-100 dark:border-[#2E2E38]">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        {isTamil
                          ? `மாதாந்திர SIP மதிப்பீடு (₹5,000 / மாதம் · ${investorProfile.timeHorizonYears} ஆண்டுகள்)`
                          : `Hypothetical Monthly SIP Projection (₹5,000 / month over ${investorProfile.timeHorizonYears} yrs)`}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs">
                        <span className="text-slate-500 dark:text-slate-400">{isTamil ? 'விகிதம்:' : 'Rate:'}</span>
                        {[6, 10, 12].map((r) => (
                          <button
                            key={r}
                            onClick={() => setSelectedCalcRate(r)}
                            className={`px-2.5 py-1 rounded-md text-xs font-mono font-semibold transition-colors ${
                              selectedCalcRate === r
                                ? 'bg-slate-900 dark:bg-amber-600 text-white'
                                : 'bg-slate-100 dark:bg-[#141416] text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                            }`}
                          >
                            {r}% p.a.
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Calculated Scenario */}
                    {(() => {
                      const proj =
                        match.futureValueProjections.find((p) => p.rateAssumption === selectedCalcRate) ||
                        match.futureValueProjections[1];
                      return (
                        <div className="bg-slate-50 dark:bg-[#141416] rounded-2xl p-4 border border-slate-200/80 dark:border-[#2E2E38] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="grid grid-cols-3 gap-6 text-xs w-full sm:w-auto">
                            <div>
                              <span className="text-[10px] uppercase font-semibold text-slate-400">{isTamil ? 'மொத்த முதலீடு' : 'Total Invested'}</span>
                              <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                                ₹{(proj.investedAmount / 100000).toFixed(2)} {isTamil ? 'இலட்சம்' : 'Lakh'}
                              </div>
                            </div>
                            <div>
                              <span className="text-[10px] uppercase font-semibold text-slate-400">{isTamil ? 'மதிப்பிடப்பட்ட லாபம்' : 'Estimated Gain'}</span>
                              <div className="text-sm font-bold text-emerald-700 dark:text-emerald-400 font-mono">
                                +₹{(proj.projectedGain / 100000).toFixed(2)} {isTamil ? 'இலட்சம்' : 'Lakh'}
                              </div>
                            </div>
                            <div>
                              <span className="text-[10px] uppercase font-semibold text-slate-400">{isTamil ? 'முதிர்வு மதிப்பு' : 'Approx. Maturity'}</span>
                              <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                                ₹{(proj.projectedTotalValue / 100000).toFixed(2)} {isTamil ? 'இலட்சம்' : 'Lakh'}
                              </div>
                            </div>
                          </div>

                          <div className="text-[10px] text-slate-400 italic max-w-xs text-left sm:text-right">
                            {isTamil ? '*கணித மாதிரியமைப்பு மட்டுமே. வருமானத்திற்கு உத்தரவாதம் இல்லை.' : '*Purely hypothetical mathematical simulation. Mutual fund returns are not guaranteed.'}
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Action CTA: Open 8-Tab Research Modal */}
                  <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5 text-slate-400" />
                      <span>Benchmark: {scheme.benchmark}</span>
                    </div>

                    <button
                      onClick={() => onOpenSchemeDetail(scheme, match)}
                      className="w-full sm:w-auto px-5 py-2.5 bg-slate-900 dark:bg-amber-600 hover:bg-slate-800 dark:hover:bg-amber-500 text-white font-semibold rounded-xl text-xs transition-colors shadow-xs flex items-center justify-center gap-2"
                    >
                      <span>{isTamil ? 'முழு திட்ட பகுப்பாய்வை காண்க (8 பிரிவுகள்)' : 'Explore Full Scheme Analysis (8 Tabs)'}</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 3. Ineligible Schemes Drawer (Transparency Rule) */}
      {ineligibleSchemes.length > 0 && (
        <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] rounded-3xl p-6 shadow-xs">
          <div
            onClick={() => setShowIneligible(!showIneligible)}
            className="flex items-center justify-between cursor-pointer select-none"
          >
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-slate-400" />
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {isTamil ? `விலக்கப்பட்ட திட்டங்கள் (${ineligibleSchemes.length})` : `Excluded Schemes (${ineligibleSchemes.length})`}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isTamil ? 'பொருத்தம் அல்லது பணப்புழக்க நிபந்தனைகளை நிறைவு செய்யாத திட்டங்கள்.' : 'Schemes that failed hard suitability, horizon, or liquidity constraints.'}
                </p>
              </div>
            </div>
            <button className="text-xs font-semibold text-amber-700 dark:text-amber-400 hover:text-amber-800 flex items-center gap-1">
              <span>
                {showIneligible
                  ? isTamil ? 'மறை' : 'Hide Ineligible'
                  : isTamil ? 'விலக்கப்பட்டவற்றை பார்' : 'View Ineligible Audit'}
              </span>
              <ChevronDown
                className={`w-4 h-4 transition-transform duration-200 ${
                  showIneligible ? 'rotate-180' : ''
                }`}
              />
            </button>
          </div>

          {showIneligible && (
            <div className="mt-5 space-y-3 pt-4 border-t border-slate-100 dark:border-[#2E2E38]">
              {ineligibleSchemes.map((item) => (
                <div
                  key={item.scheme.id}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-[#141416] border border-slate-200/70 dark:border-[#2E2E38] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">{item.scheme.name}</div>
                    <div className="text-slate-500 dark:text-slate-400 mt-0.5">{item.scheme.category} · Risk: {item.scheme.riskometer}</div>
                    <div className="text-amber-800 dark:text-amber-400 font-medium mt-1">
                      {item.ineligibilityReasons.join(' · ')}
                    </div>
                  </div>
                  <button
                    onClick={() => onOpenSchemeDetail(item.scheme, item)}
                    className="self-start sm:self-auto px-3 py-1.5 border border-slate-200 dark:border-[#2E2E38] rounded-lg text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white shrink-0 font-medium"
                  >
                    {isTamil ? 'திட்ட விவரம்' : 'View Scheme Info'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
