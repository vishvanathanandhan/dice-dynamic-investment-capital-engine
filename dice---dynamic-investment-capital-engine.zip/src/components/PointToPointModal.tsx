/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Point-to-Point Returns & CAGR Retrospective Calculator
 * Linked with 11,000+ Schemes Universe
 */

import React, { useState, useEffect } from 'react';
import { X, TrendingUp, Calendar, Calculator, Search, Loader2, ExternalLink } from 'lucide-react';
import { useSchemes } from '../context/SchemeContext';
import { MutualFundScheme } from '../types';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';

interface PointToPointModalProps {
  onClose: () => void;
  onOpenSchemeDetail: (scheme: MutualFundScheme) => void;
}

export const PointToPointModal: React.FC<PointToPointModalProps> = ({
  onClose,
  onOpenSchemeDetail,
}) => {
  const { schemes: localSchemes } = useSchemes();
  const [selectedScheme, setSelectedScheme] = useState<MutualFundScheme>(localSchemes[0]);
  const [initialAmount, setInitialAmount] = useState<number>(10000);
  const [selectedYears, setSelectedYears] = useState<number>(3);

  // Scheme Search across 11,000+ database
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MutualFundScheme[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const handler = setTimeout(async () => {
      try {
        const res = await fetch(`/api/pipeline/schemes?search=${encodeURIComponent(q)}&limit=15`);
        const json = await res.json();
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );

          const qLower = q.toLowerCase();
          const customMatches = localSchemes.filter(
            (s) =>
              (s.id.startsWith('uploaded_') || s.isUploaded) &&
              (s.name.toLowerCase().includes(qLower) || s.category.toLowerCase().includes(qLower))
          );

          setSearchResults([...customMatches, ...list]);
        }
      } catch (err) {
        console.error('Failed searching schemes for point-to-point', err);
      } finally {
        setIsSearching(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [searchQuery, localSchemes]);

  // Derive estimated starting NAV from CAGR or 1Y return
  const currentNav = selectedScheme?.nav || 50;
  const annualReturn =
    selectedYears === 1
      ? selectedScheme?.return1Y || 15
      : selectedYears === 2
      ? (selectedScheme?.return3Y || selectedScheme?.return1Y || 14) * 0.95
      : selectedYears === 3
      ? selectedScheme?.return3Y || selectedScheme?.return1Y || 13
      : selectedScheme?.return5Y || selectedScheme?.return3Y || 12;

  const rateDecimal = annualReturn / 100;
  // Starting NAV = Current NAV / (1 + r)^n
  const estimatedInitialNav = Number((currentNav / Math.pow(1 + rateDecimal, selectedYears)).toFixed(2));
  
  // Simple Return = ((LV - IV) / IV) * 100
  const simpleReturn = Number((((currentNav - estimatedInitialNav) / estimatedInitialNav) * 100).toFixed(2));
  
  // Standard growth calculation
  const unitsBought = initialAmount / (estimatedInitialNav > 0 ? estimatedInitialNav : 10);
  const endValue = Math.round(unitsBought * currentNav);
  const absoluteGain = endValue - initialAmount;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] text-slate-900 dark:text-slate-100 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-[#2E2E38] flex items-start justify-between gap-4 bg-slate-50/70 dark:bg-[#141416]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
              <span>Performance Analytics Tool</span>
              <span>·</span>
              <span>Point-to-Point Analysis</span>
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              Point-to-Point Returns Calculator
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select ANY mutual fund from the 11,000+ universe to calculate Simple Return, CAGR, and capital growth.
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-[#141416] hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shrink-0 cursor-pointer border dark:border-[#2E2E38]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto text-xs flex-1 bg-white dark:bg-[#1E1E24]">
          {/* Select Any Fund with 11,000+ Scheme Search */}
          <div className="relative">
            <label className="font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between mb-1.5 text-xs">
              <span>Select Mutual Fund Scheme:</span>
              <span className="text-[10px] text-amber-700 dark:text-amber-400 font-mono">11,000+ schemes available</span>
            </label>

            {/* Currently Selected Scheme Card */}
            <div className="p-3 bg-amber-50/50 dark:bg-[#141416] border border-amber-200 dark:border-[#2E2E38] rounded-xl flex items-center justify-between gap-3 mb-2">
              <div className="min-w-0 flex-1">
                <div className="font-bold text-slate-900 dark:text-white text-xs truncate">
                  {selectedScheme?.name}
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {selectedScheme?.amc} · {selectedScheme?.category} · NAV: ₹{selectedScheme?.nav?.toFixed(2)}
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onOpenSchemeDetail(selectedScheme);
                  onClose();
                }}
                className="px-2.5 py-1.5 bg-white dark:bg-[#1E1E24] border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-400 font-bold rounded-lg text-[10px] shrink-0 hover:bg-amber-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <ExternalLink className="w-3 h-3" />
                <span>Factsheet</span>
              </button>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                placeholder="Search across 11,000+ schemes to switch fund..."
                className="w-full bg-white dark:bg-[#1E1E24] border border-slate-300 dark:border-[#2E2E38] rounded-xl pl-8 pr-8 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
              {isSearching && (
                <Loader2 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 animate-spin absolute right-2.5 top-2.5" />
              )}
            </div>

            {/* Autocomplete Dropdown */}
            {isSearchOpen && searchQuery.trim().length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-[#1E1E24] rounded-xl shadow-xl border border-slate-200 dark:border-[#2E2E38] z-50 overflow-hidden max-h-56 overflow-y-auto">
                <div className="p-2 bg-slate-50 dark:bg-[#141416] border-b border-slate-100 dark:border-[#2E2E38] flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-semibold">
                  <span>Found {searchResults.length} matching funds</span>
                  <button
                    onClick={() => setIsSearchOpen(false)}
                    className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                {searchResults.length === 0 && !isSearching ? (
                  <div className="p-4 text-center text-slate-400 text-xs">No matching schemes.</div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {searchResults.map((scheme) => (
                      <button
                        key={scheme.id}
                        type="button"
                        onClick={() => {
                          setSelectedScheme(scheme);
                          setSearchQuery('');
                          setIsSearchOpen(false);
                        }}
                        className="w-full p-2.5 text-left hover:bg-amber-50/60 flex items-center justify-between gap-2 transition-colors cursor-pointer"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="font-bold text-slate-900 truncate text-[11px]">
                            {scheme.name}
                          </div>
                          <div className="text-[10px] text-slate-500 truncate">
                            {scheme.amc} · {scheme.category}
                          </div>
                        </div>
                        <span className="text-[10px] font-mono text-emerald-700 font-bold shrink-0">
                          1Y: {scheme.return1Y ? `+${scheme.return1Y}%` : 'N/A'}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Timeframe & Amount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">
                Evaluation Window:
              </label>
              <div className="grid grid-cols-4 gap-1.5 bg-slate-100 dark:bg-[#141416] p-1 rounded-xl border dark:border-[#2E2E38]">
                {[1, 2, 3, 5].map((y) => (
                  <button
                    key={y}
                    onClick={() => setSelectedYears(y)}
                    className={`py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      selectedYears === y
                        ? 'bg-white dark:bg-amber-600 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {y}Y
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">
                Initial Hypothetical Investment (₹):
              </label>
              <input
                type="number"
                step="1000"
                value={initialAmount}
                onChange={(e) => setInitialAmount(Number(e.target.value))}
                className="w-full bg-white dark:bg-[#1E1E24] border border-slate-300 dark:border-[#2E2E38] rounded-xl px-3 py-1.5 font-mono text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Computed Results Card */}
          <div className="bg-[#FAF8F5] dark:bg-[#141416] border border-[#EBE3D5] dark:border-[#2E2E38] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E0D7C6] dark:border-[#2E2E38]">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Calculated Compound Return</span>
                <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
                  +{annualReturn.toFixed(2)}% CAGR
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-slate-400">Simple Return</span>
                <div className="text-lg font-bold text-slate-800 dark:text-slate-200 font-mono">
                  +{simpleReturn}%
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-white dark:bg-[#1E1E24] p-3 rounded-xl border border-slate-200 dark:border-[#2E2E38]">
                <span className="text-[10px] text-slate-400 block">Initial NAV</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs">₹{estimatedInitialNav}</span>
              </div>
              <div className="bg-white dark:bg-[#1E1E24] p-3 rounded-xl border border-slate-200 dark:border-[#2E2E38]">
                <span className="text-[10px] text-slate-400 block">Current NAV</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs">₹{currentNav.toFixed(2)}</span>
              </div>
              <div className="bg-white dark:bg-[#1E1E24] p-3 rounded-xl border border-slate-200 dark:border-[#2E2E38]">
                <span className="text-[10px] text-slate-400 block">Invested Amount</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200 text-xs">₹{initialAmount.toLocaleString('en-IN')}</span>
              </div>
              <div className="bg-white dark:bg-[#1E1E24] p-3 rounded-xl border border-slate-200 dark:border-[#2E2E38]">
                <span className="text-[10px] text-slate-400 block">Current Worth</span>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-xs">₹{endValue.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="text-center pt-2">
              <span className="text-xs text-slate-600 dark:text-slate-400 font-medium">
                Absolute Gain: <strong className="text-emerald-600 dark:text-emerald-400 font-mono">+₹{absoluteGain.toLocaleString('en-IN')}</strong> ({simpleReturn}% growth over {selectedYears} years)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
