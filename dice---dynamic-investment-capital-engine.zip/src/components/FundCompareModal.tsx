/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Interactive Fund Compare Modal
 * Allows user to search and choose ANY 2 to 4 schemes from the 11,000+ database
 */

import React, { useState, useEffect } from 'react';
import { X, ArrowLeftRight, Plus, Trash2, CheckCircle2, Search, Loader2, ExternalLink, AlertTriangle } from 'lucide-react';
import { MutualFundScheme } from '../types';
import { useSchemes } from '../context/SchemeContext';
import { normalizeToMutualFundScheme } from '../utils/pipelineAdapter';
import { NormalizedSchemeRecord } from '../types/pipeline';

interface FundCompareModalProps {
  onClose: () => void;
  onOpenSchemeDetail: (scheme: MutualFundScheme) => void;
}

export const FundCompareModal: React.FC<FundCompareModalProps> = ({
  onClose,
  onOpenSchemeDetail,
}) => {
  const { schemes: localSchemes } = useSchemes();
  
  // Default to first 2 schemes
  const [selectedSchemes, setSelectedSchemes] = useState<MutualFundScheme[]>([
    localSchemes[0] || null,
    localSchemes[1] || null,
  ].filter(Boolean));

  // Search state to add any scheme from 11,000+ database
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MutualFundScheme[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Debounced search across 11,000+ pipeline schemes
  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const handler = setTimeout(async () => {
      try {
        const res = await fetch(`/api/pipeline/schemes?search=${encodeURIComponent(q)}&limit=15`);
        const json = await res.json();
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );

          // Also prepend matching uploaded custom schemes
          const qLower = q.toLowerCase();
          const customMatches = localSchemes.filter(
            (s) =>
              (s.id.startsWith('uploaded_') || s.isUploaded) &&
              (s.name.toLowerCase().includes(qLower) || s.category.toLowerCase().includes(qLower))
          );

          setSearchResults([...customMatches, ...list]);
        }
      } catch (err) {
        console.error('Failed to search schemes for comparison:', err);
      } finally {
        setIsSearching(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [searchQuery, localSchemes]);

  const handleAddScheme = (scheme: MutualFundScheme) => {
    if (selectedSchemes.length < 4 && !selectedSchemes.some((s) => s.id === scheme.id)) {
      setSelectedSchemes([...selectedSchemes, scheme]);
      setSearchQuery('');
      setIsSearchOpen(false);
    }
  };

  const handleRemoveScheme = (schemeId: string) => {
    if (selectedSchemes.length > 1) {
      setSelectedSchemes(selectedSchemes.filter((s) => s.id !== schemeId));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-[#1E1E24] border border-slate-200 dark:border-[#2E2E38] text-slate-900 dark:text-slate-100 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-[#2E2E38] flex items-start justify-between gap-4 bg-slate-50/70 dark:bg-[#141416]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase text-amber-700 dark:text-amber-400 tracking-wider">
              <span>Interactive Analytics Tool</span>
              <span>·</span>
              <span>Multi-Fund Comparison</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
              Side-by-Side Fund Compare
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select and compare up to 4 mutual funds across risk metrics, historical returns, and expense ratios from 11,000+ universe.
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 dark:bg-[#141416] hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors shrink-0 cursor-pointer border dark:border-[#2E2E38]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add Scheme Selector Bar with 11,000+ Autocomplete */}
        <div className="px-6 py-3 bg-amber-50/40 dark:bg-[#141416] border-b border-amber-100 dark:border-[#2E2E38] flex flex-wrap items-center justify-between gap-3 text-xs relative">
          <div className="flex items-center gap-2 flex-1 max-w-xl">
            <span className="font-semibold text-slate-700 dark:text-slate-300 shrink-0">
              Add fund to compare ({selectedSchemes.length}/4):
            </span>
            <div className="relative flex-1">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onFocus={() => setIsSearchOpen(true)}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchOpen(true);
                  }}
                  disabled={selectedSchemes.length >= 4}
                  placeholder={
                    selectedSchemes.length >= 4
                      ? 'Maximum 4 funds selected'
                      : 'Search across 11,000+ funds to add (e.g. SBI, HDFC, Liquid)...'
                  }
                  className="w-full bg-white dark:bg-[#1E1E24] border border-slate-300 dark:border-[#2E2E38] rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500 disabled:opacity-50"
                />
                {isSearching && (
                  <Loader2 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 animate-spin absolute right-2.5 top-2.5" />
                )}
              </div>

              {/* Autocomplete Dropdown */}
              {isSearchOpen && searchQuery.trim().length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-[#1E1E24] rounded-xl shadow-xl border border-slate-200 dark:border-[#2E2E38] z-50 overflow-hidden max-h-60 overflow-y-auto">
                  <div className="p-2 bg-slate-50 dark:bg-[#141416] border-b border-slate-100 dark:border-[#2E2E38] flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                    <span>Found {searchResults.length} matching funds</span>
                    <button
                      onClick={() => setIsSearchOpen(false)}
                      className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                  {searchResults.length === 0 && !isSearching ? (
                    <div className="p-4 text-center text-slate-400 text-xs">No matching funds found.</div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {searchResults.map((scheme) => {
                        const isAlreadySelected = selectedSchemes.some((s) => s.id === scheme.id);
                        return (
                          <div
                            key={scheme.id}
                            className="p-2.5 hover:bg-amber-50/60 flex items-center justify-between gap-2 transition-colors text-xs"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-slate-900 truncate text-[11px]">
                                {scheme.name}
                              </div>
                              <div className="text-[10px] text-slate-500 truncate">
                                {scheme.amc} · {scheme.category} · {scheme.plan}
                              </div>
                            </div>
                            <button
                              onClick={() => handleAddScheme(scheme)}
                              disabled={isAlreadySelected || selectedSchemes.length >= 4}
                              className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition-colors cursor-pointer shrink-0 ${
                                isAlreadySelected
                                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                  : 'bg-amber-600 hover:bg-amber-700 text-white'
                              }`}
                            >
                              {isAlreadySelected ? 'Added' : '+ Add'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
            11,000+ schemes linked
          </span>
        </div>

        {/* Comparison Table Grid */}
        <div className="p-6 overflow-y-auto flex-1 bg-white dark:bg-[#1E1E24]">
          <div className="border border-slate-200 dark:border-[#2E2E38] rounded-2xl overflow-hidden overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-[#141416] border-b border-slate-200 dark:border-[#2E2E38]">
                <tr>
                  <th className="py-3 px-4 w-48 text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px]">Metric / Dimension</th>
                  {selectedSchemes.map((s) => (
                    <th key={s.id} className="py-3 px-4 min-w-[200px] text-slate-900 dark:text-white font-bold">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-[10px] text-slate-400 uppercase">{s.amc}</div>
                          <div className="font-extrabold text-sm">{s.name}</div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{s.category} · {s.plan}</div>
                        </div>
                        {selectedSchemes.length > 1 && (
                          <button
                            onClick={() => handleRemoveScheme(s.id)}
                            className="text-slate-400 hover:text-rose-500 p-1 cursor-pointer"
                            title="Remove from comparison"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#2E2E38] text-slate-700 dark:text-slate-300">
                {/* Rating */}
                <tr className="hover:bg-slate-50 dark:hover:bg-[#141416]/50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600 dark:text-slate-300">Fund Rating</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-bold text-amber-600">
                      {s.rating > 0 ? `${'★'.repeat(s.rating)} (${s.rating}.0)` : 'Verified'}
                    </td>
                  ))}
                </tr>

                {/* Riskometer */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Riskometer Level</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-medium text-slate-800">
                      {s.riskometer || 'Moderate'}
                    </td>
                  ))}
                </tr>

                {/* Latest NAV */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Current NAV (INR)</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono font-bold text-slate-900">
                      ₹{s.nav ? s.nav.toFixed(2) : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* 1 Year Return */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">1 Year Return</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono font-bold text-emerald-700">
                      {s.return1Y ? `+${s.return1Y}%` : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* 3 Year Return */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">3 Year CAGR</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono font-bold text-emerald-700">
                      {s.return3Y ? `+${s.return3Y}%` : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* 5 Year Return */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">5 Year CAGR</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono font-bold text-emerald-700">
                      {s.return5Y ? `+${s.return5Y}%` : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* AUM */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">AUM (Rs. Crores)</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono text-slate-800">
                      {s.aumCrores ? `₹${s.aumCrores.toLocaleString('en-IN')} Cr` : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* TER */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Expense Ratio (TER)</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono font-bold text-slate-900">
                      {s.ter ? `${s.ter}%` : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* Sharpe Ratio */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Sharpe Ratio</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono text-slate-800">
                      {s.sharpeRatio ? s.sharpeRatio : 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* Beta */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Beta</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono text-slate-800">
                      {s.beta || 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* Benchmark */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Benchmark Index</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 text-slate-700">
                      {s.benchmark || 'Data unavailable'}
                    </td>
                  ))}
                </tr>

                {/* Minimum SIP */}
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-semibold text-slate-600">Min SIP Amount</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-2.5 px-4 font-mono text-slate-800">
                      ₹{s.minSip || 500}
                    </td>
                  ))}
                </tr>

                {/* Action Buttons */}
                <tr className="bg-slate-50/50">
                  <td className="py-3 px-4 font-semibold text-slate-600">Full Factsheet</td>
                  {selectedSchemes.map((s) => (
                    <td key={s.id} className="py-3 px-4">
                      <button
                        onClick={() => {
                          onOpenSchemeDetail(s);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>View Factsheet</span>
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          {/* Historical Data and Scheme Comparison Disclosure */}
          <div className="p-4 bg-amber-50/70 dark:bg-[#141416] border-t border-amber-200/90 dark:border-[#2E2E38] text-xs shrink-0">
            <div className="flex items-center gap-1.5 font-bold text-amber-950 dark:text-amber-400 mb-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>Historical Data and Scheme Comparison Disclosure</span>
            </div>
            <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-relaxed">
              The information presented is intended for educational comparison of mutual fund scheme characteristics and publicly available historical data. The display order, sorting and comparative metrics do not constitute a recommendation, endorsement, suitability assessment or indication of future performance. Data may be incomplete, delayed or subject to correction. Users should refer to the respective AMC's latest Scheme Information Document, Key Information Memorandum, factsheet and official disclosures before making any independent decision.
            </p>
          </div>

          {/* Modal Bottom Bar */}
          <div className="p-3 bg-slate-50 dark:bg-[#141416] border-t border-slate-200 dark:border-[#2E2E38] flex items-center justify-between text-xs shrink-0">
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Comparing {selectedSchemes.length} of max 4 schemes
            </span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Comparison
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
