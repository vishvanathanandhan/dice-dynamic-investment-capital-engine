/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Header adhering strictly to Top Bar Contract, DICE Branding & Language/Theme controls
 * Zone 3 contains A/த language switcher and Dark/Light Mode toggle switch as requested
 */

import React from 'react';
import { Sparkles, BookOpen, BarChart3, Calculator } from 'lucide-react';
import { useLanguage, LanguageToggleButton } from '../context/LanguageContext';
import { ThemeToggleSwitch } from '../context/ThemeContext';

interface HeaderProps {
  activeView: 'home' | 'questionnaire' | 'results' | 'calculators' | 'monitor' | 'methodology' | 'data_quality' | 'disclaimer';
  onNavigate: (view: 'home' | 'questionnaire' | 'results' | 'calculators' | 'monitor' | 'methodology' | 'data_quality' | 'disclaimer') => void;
  hasResults: boolean;
  onOpenUploadModal?: () => void;
  onOpenAmfiModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onNavigate,
  hasResults,
}) => {
  const { t } = useLanguage();
  const [isRolling, setIsRolling] = React.useState(false);

  const handleLogoClick = () => {
    setIsRolling(true);
    setTimeout(() => setIsRolling(false), 850);
    onNavigate('home');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#141416]/95 backdrop-blur-md border-b border-slate-200 dark:border-[#2E2E38] transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          {/* Zone 1: Brand Wordmark with new transparent logo that rolls like a dice */}
          <div
            onClick={handleLogoClick}
            className="flex items-center gap-3 cursor-pointer select-none shrink-0 group"
            title="Click to roll the dice!"
          >
            <img
              src="/assets/aistudio/Logo_DICE__1_-removebg-preview_f2e8a9ea.png"
              alt="DICE Engine"
              className={`w-9 h-9 object-contain drop-shadow-xs transition-transform duration-200 group-hover:scale-110 ${
                isRolling ? 'animate-dice-roll' : ''
              }`}
              onError={(e) => {
                // Fallback to existing path if needed
                (e.target as HTMLImageElement).src = '/assets/aistudio/Logo_DICE__1__09a2a920.png';
              }}
            />
            <div className="flex flex-col">
              <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-none">
                DICE
              </span>
              <span className="text-[10px] uppercase font-semibold text-amber-700 dark:text-amber-400 tracking-wider">
                {t('brand.tagline', 'Capital Engine')}
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (Single-line, unboxed, bilingual) */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            <button
              onClick={() => onNavigate('home')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 cursor-pointer ${
                activeView === 'home'
                  ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                  : 'border-transparent'
              }`}
            >
              {t('nav.explorer', 'Funds Explorer')}
            </button>
            <button
              onClick={() => onNavigate('questionnaire')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 cursor-pointer ${
                activeView === 'questionnaire'
                  ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                  : 'border-transparent'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{t('nav.profiler', '20Q Profiler')}</span>
            </button>
            {hasResults && (
              <button
                onClick={() => onNavigate('results')}
                className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 cursor-pointer ${
                  activeView === 'results'
                    ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                    : 'border-transparent'
                }`}
              >
                {t('nav.matches', 'DICE Matches')}
              </button>
            )}
            <button
              onClick={() => onNavigate('calculators')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 cursor-pointer ${
                activeView === 'calculators'
                  ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                  : 'border-transparent'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
              <span>{t('nav.calculators', 'Calculators')}</span>
            </button>
            <button
              onClick={() => onNavigate('monitor')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 cursor-pointer ${
                activeView === 'monitor'
                  ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                  : 'border-transparent'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
              <span>{t('nav.monitor', 'Fund Monitor')}</span>
            </button>
            <button
              onClick={() => onNavigate('methodology')}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 flex items-center gap-1.5 cursor-pointer ${
                activeView === 'methodology'
                  ? 'border-amber-600 dark:border-amber-500 text-slate-950 dark:text-white font-semibold'
                  : 'border-transparent'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
              <span>{t('nav.methodology', 'Methodology')}</span>
            </button>
          </nav>

          {/* Zone 3: A/த Language Toggle & Theme Toggle Slider (Replacing upload excel & start 20q) */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Language Switch Button A/த */}
            <LanguageToggleButton />

            {/* Dark Mode / Light Mode Toggle Switch (modeled on image_8fff0741.png) */}
            <ThemeToggleSwitch />
          </div>
        </div>
      </div>
    </header>
  );
};
