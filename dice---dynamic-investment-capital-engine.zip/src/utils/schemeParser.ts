/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Scheme Excel & CSV Parser and Template Generator
 * Handles schema validation, normalization, and sample file generation
 */

import * as XLSX from 'xlsx';
import { MutualFundScheme, RiskLevel, BroadAssetCategory } from '../types';

export const SCHEME_COLUMNS_SPEC = [
  { key: 'name', label: 'Scheme Name', required: true, example: 'Kotak Emerging Equity Fund', desc: 'Full legal name of the fund scheme' },
  { key: 'amc', label: 'Fund House / AMC', required: true, example: 'Kotak Mahindra Mutual Fund', desc: 'Asset Management Company' },
  { key: 'category', label: 'Category', required: true, example: 'Mid Cap Fund', desc: 'SEBI scheme category (Flexi Cap, Mid Cap, Liquid, etc.)' },
  { key: 'categoryCode', label: 'Category Code', required: false, example: 'EQ-MC', desc: 'EQ-FLX, EQ-LC, EQ-MC, EQ-SC, EQ-ELSS, DB-LIQ, HY-AGG, CMD-GLD' },
  { key: 'broadCategory', label: 'Broad Asset Class', required: true, example: 'Equity', desc: 'Equity, Debt, Hybrid, or Commodities' },
  { key: 'plan', label: 'Plan', required: false, example: 'Direct', desc: 'Direct or Regular' },
  { key: 'option', label: 'Option', required: false, example: 'Growth', desc: 'Growth or IDCW' },
  { key: 'rating', label: 'Rating (Stars)', required: false, example: 5, desc: '1 to 5 rating' },
  { key: 'riskometer', label: 'Riskometer Level', required: true, example: 'Very High', desc: 'Low, Low to Moderate, Moderate, Moderately High, High, Very High' },
  { key: 'nav', label: 'NAV (INR)', required: true, example: 124.50, desc: 'Current Net Asset Value in Rupees' },
  { key: 'aumCrores', label: 'AUM (Rs. Cr)', required: false, example: 45000, desc: 'Total Assets Under Management in Crores' },
  { key: 'ter', label: 'TER (%)', required: false, example: 0.75, desc: 'Total Expense Ratio in percentage' },
  { key: 'fundManager', label: 'Fund Manager', required: false, example: 'Pankaj Tibrewal', desc: 'Lead portfolio manager' },
  { key: 'benchmark', label: 'Benchmark Index', required: false, example: 'NIFTY Midcap 150 TRI', desc: 'Total Return Index benchmark' },
  { key: 'return1Y', label: '1-Year Return (%)', required: true, example: 31.5, desc: '1-year performance percentage' },
  { key: 'return3Y', label: '3-Year Return (%)', required: false, example: 24.2, desc: '3-year CAGR percentage' },
  { key: 'return5Y', label: '5-Year Return (%)', required: false, example: 21.0, desc: '5-year CAGR percentage' },
  { key: 'returnSinceInception', label: 'Inception Return (%)', required: false, example: 18.5, desc: 'CAGR since fund launch' },
  { key: 'sharpeRatio', label: 'Sharpe Ratio', required: false, example: 1.35, desc: '500-day risk-adjusted return ratio' },
  { key: 'beta', label: 'Beta', required: false, example: 0.85, desc: 'Systematic market sensitivity' },
  { key: 'standardDeviation', label: 'Standard Deviation (%)', required: false, example: 14.5, desc: 'Annualized return volatility' },
  { key: 'maxDrawdown', label: 'Max Drawdown (%)', required: false, example: -17.5, desc: 'Largest peak-to-trough drop' },
  { key: 'minSip', label: 'Min SIP (INR)', required: false, example: 500, desc: 'Minimum monthly SIP amount' },
  { key: 'exitLoad', label: 'Exit Load', required: false, example: '1% if redeemed within 1 year; Nil thereafter', desc: 'Exit penalty conditions' },
  { key: 'lockInPeriod', label: 'Lock-in Period', required: false, example: 'Nil', desc: '3 Years (ELSS) or Nil' },
  { key: 'topHolding1', label: 'Top Holding 1 (Company: Weight%)', required: false, example: 'Supreme Industries: 4.8%', desc: 'Top portfolio stock/asset' },
  { key: 'topHolding2', label: 'Top Holding 2 (Company: Weight%)', required: false, example: 'Schaeffler India: 3.9%', desc: 'Second largest holding' },
  { key: 'opinion', label: 'Investment Mandate / Opinion', required: false, example: 'High quality mid-cap growth stocks with strong capital efficiency.', desc: 'Summary of strategy' }
];

export const SAMPLE_SCHEMES_TEMPLATE = [
  {
    'Scheme Name': 'Tata Digital India Fund',
    'Fund House / AMC': 'Tata Mutual Fund',
    'Category': 'Sectoral - Technology',
    'Category Code': 'EQ-SEC',
    'Broad Asset Class': 'Equity',
    'Plan': 'Direct',
    'Option': 'Growth',
    'Rating (Stars)': 4,
    'Riskometer Level': 'Very High',
    'NAV (INR)': 48.65,
    'AUM (Rs. Cr)': 10850,
    'TER (%)': 0.72,
    'Fund Manager': 'Meeta Shetty',
    'Benchmark Index': 'BSE Teck TRI',
    '1-Year Return (%)': 29.4,
    '3-Year Return (%)': 18.2,
    '5-Year Return (%)': 22.1,
    'Inception Return (%)': 19.8,
    'Sharpe Ratio': 1.15,
    'Beta': 0.95,
    'Standard Deviation (%)': 16.8,
    'Max Drawdown (%)': -21.4,
    'Min SIP (INR)': 500,
    'Exit Load': '0.25% if redeemed within 30 days; Nil thereafter',
    'Lock-in Period': 'Nil',
    'Top Holding 1 (Company: Weight%)': 'Infosys Ltd: 9.8%',
    'Top Holding 2 (Company: Weight%)': 'Tata Consultancy Services: 8.9%',
    'Investment Mandate / Opinion': 'Targeted exposure to leading Indian and global IT software and digital technology leaders.'
  },
  {
    'Scheme Name': 'Bandhan Sterling Value Fund',
    'Fund House / AMC': 'Bandhan Mutual Fund',
    'Category': 'Value Fund',
    'Category Code': 'EQ-VAL',
    'Broad Asset Class': 'Equity',
    'Plan': 'Direct',
    'Option': 'Growth',
    'Rating (Stars)': 5,
    'Riskometer Level': 'Very High',
    'NAV (INR)': 142.10,
    'AUM (Rs. Cr)': 9800,
    'TER (%)': 0.65,
    'Fund Manager': 'Daylynn Pinto',
    'Benchmark Index': 'Nifty 500 Value 50 TRI',
    '1-Year Return (%)': 33.2,
    '3-Year Return (%)': 26.8,
    '5-Year Return (%)': 23.5,
    'Inception Return (%)': 17.6,
    'Sharpe Ratio': 1.48,
    'Beta': 0.82,
    'Standard Deviation (%)': 13.8,
    'Max Drawdown (%)': -15.8,
    'Min SIP (INR)': 500,
    'Exit Load': '1% if redeemed within 365 days; Nil thereafter',
    'Lock-in Period': 'Nil',
    'Top Holding 1 (Company: Weight%)': 'ICICI Bank Ltd: 6.8%',
    'Top Holding 2 (Company: Weight%)': 'NTPC Ltd: 5.5%',
    'Investment Mandate / Opinion': 'Disciplined value style investing in undervalued companies with high margin of safety.'
  },
  {
    'Scheme Name': 'SBI Corporate Bond Fund',
    'Fund House / AMC': 'SBI Mutual Fund',
    'Category': 'Corporate Bond Fund',
    'Category Code': 'DB-CORP',
    'Broad Asset Class': 'Debt',
    'Plan': 'Direct',
    'Option': 'Growth',
    'Rating (Stars)': 4,
    'Riskometer Level': 'Moderate',
    'NAV (INR)': 41.85,
    'AUM (Rs. Cr)': 22400,
    'TER (%)': 0.35,
    'Fund Manager': 'Rajeev Radhakrishnan',
    'Benchmark Index': 'NIFTY Corporate Bond Index',
    '1-Year Return (%)': 8.1,
    '3-Year Return (%)': 7.4,
    '5-Year Return (%)': 7.1,
    'Inception Return (%)': 8.2,
    'Sharpe Ratio': 1.25,
    'Beta': 0.22,
    'Standard Deviation (%)': 2.1,
    'Max Drawdown (%)': -1.2,
    'Min SIP (INR)': 500,
    'Exit Load': 'Nil',
    'Lock-in Period': 'Nil',
    'Top Holding 1 (Company: Weight%)': 'REC Ltd AAA: 8.5%',
    'Top Holding 2 (Company: Weight%)': 'Power Grid AAA: 7.8%',
    'Investment Mandate / Opinion': 'High quality corporate debt portfolio mandated with minimum 80% in AA+ and above papers.'
  },
  {
    'Scheme Name': 'Mirae Asset Hybrid Equity Fund',
    'Fund House / AMC': 'Mirae Asset Mutual Fund',
    'Category': 'Aggressive Hybrid Fund',
    'Category Code': 'HY-AGG',
    'Broad Asset Class': 'Hybrid',
    'Plan': 'Direct',
    'Option': 'Growth',
    'Rating (Stars)': 5,
    'Riskometer Level': 'Very High',
    'NAV (INR)': 34.20,
    'AUM (Rs. Cr)': 12100,
    'TER (%)': 0.68,
    'Fund Manager': 'Neelesh Surana & Mahendra Jajoo',
    'Benchmark Index': 'CRISIL Hybrid 35+65 Aggressive Index',
    '1-Year Return (%)': 24.5,
    '3-Year Return (%)': 18.9,
    '5-Year Return (%)': 17.5,
    'Inception Return (%)': 16.1,
    'Sharpe Ratio': 1.38,
    'Beta': 0.78,
    'Standard Deviation (%)': 11.2,
    'Max Drawdown (%)': -12.4,
    'Min SIP (INR)': 500,
    'Exit Load': '1% if redeemed within 1 year; Nil thereafter',
    'Lock-in Period': 'Nil',
    'Top Holding 1 (Company: Weight%)': 'HDFC Bank Ltd: 7.2%',
    'Top Holding 2 (Company: Weight%)': '7.18% GOI 2033: 5.4%',
    'Investment Mandate / Opinion': 'Combines growth potential of equities with the stability of high quality fixed income securities.'
  }
];

export function generateSampleExcelFile(): void {
  const ws = XLSX.utils.json_to_sheet(SAMPLE_SCHEMES_TEMPLATE);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'DICE_Schemes_Template');
  XLSX.writeFile(wb, 'DICE_Scheme_Import_Template.xlsx');
}

export function generateSampleCsvFile(): void {
  const ws = XLSX.utils.json_to_sheet(SAMPLE_SCHEMES_TEMPLATE);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'DICE_Scheme_Import_Template.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Parses an Excel / CSV File and transforms it into valid MutualFundScheme[] objects
 */
export async function parseUploadedSchemeFile(file: File): Promise<{
  schemes: MutualFundScheme[];
  errors: string[];
  totalParsed: number;
}> {
  const errors: string[] = [];
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  
  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    throw new Error('The uploaded workbook contains no readable sheets.');
  }
  
  const sheet = workbook.Sheets[firstSheetName];
  const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet);
  
  if (!rows || rows.length === 0) {
    throw new Error('No data rows found in the uploaded file.');
  }

  const parsedSchemes: MutualFundScheme[] = [];

  rows.forEach((row, index) => {
    const rowNum = index + 2; // header is row 1
    
    // Normalize keys (lowercase and remove spaces/special chars)
    const normalized: Record<string, unknown> = {};
    Object.keys(row).forEach((k) => {
      const cleanKey = k.toLowerCase().replace(/[^a-z0-9]/g, '');
      normalized[cleanKey] = row[k];
    });

    // Helper getter
    const getVal = (...keys: string[]): unknown => {
      for (const k of keys) {
        const clean = k.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (normalized[clean] !== undefined && normalized[clean] !== null && normalized[clean] !== '') {
          return normalized[clean];
        }
      }
      return undefined;
    };

    const name = String(getVal('name', 'schemename', 'fundname', 'scheme') || '').trim();
    if (!name) {
      errors.push(`Row ${rowNum}: Skipped because "Scheme Name" is missing.`);
      return;
    }

    const amc = String(getVal('amc', 'fundhouse', 'mutualfund') || 'Mutual Fund AMC').trim();
    const category = String(getVal('category', 'schemecategory') || 'Diversified Equity Fund').trim();
    
    let broadCategory: BroadAssetCategory = 'Equity';
    const rawBroad = String(getVal('broadcategory', 'assetclass', 'broad') || '').toLowerCase();
    if (rawBroad.includes('debt') || category.toLowerCase().includes('debt') || category.toLowerCase().includes('liquid') || category.toLowerCase().includes('gilt')) {
      broadCategory = 'Debt';
    } else if (rawBroad.includes('hybrid') || category.toLowerCase().includes('hybrid') || category.toLowerCase().includes('balanced')) {
      broadCategory = 'Hybrid';
    } else if (rawBroad.includes('gold') || rawBroad.includes('commod') || category.toLowerCase().includes('gold') || category.toLowerCase().includes('commodity')) {
      broadCategory = 'Commodities';
    }

    let categoryCode = String(getVal('categorycode', 'code') || '').toUpperCase();
    if (!categoryCode) {
      if (category.toLowerCase().includes('flexi')) categoryCode = 'EQ-FLX';
      else if (category.toLowerCase().includes('large') && category.toLowerCase().includes('mid')) categoryCode = 'EQ-LM';
      else if (category.toLowerCase().includes('large')) categoryCode = 'EQ-LC';
      else if (category.toLowerCase().includes('mid')) categoryCode = 'EQ-MC';
      else if (category.toLowerCase().includes('small')) categoryCode = 'EQ-SC';
      else if (category.toLowerCase().includes('elss')) categoryCode = 'EQ-ELSS';
      else if (category.toLowerCase().includes('liquid')) categoryCode = 'DB-LIQ';
      else if (category.toLowerCase().includes('corporate')) categoryCode = 'DB-CORP';
      else if (category.toLowerCase().includes('hybrid') || category.toLowerCase().includes('balanced')) categoryCode = 'HY-AGG';
      else if (category.toLowerCase().includes('gold')) categoryCode = 'CMD-GLD';
      else categoryCode = broadCategory === 'Debt' ? 'DB-GEN' : broadCategory === 'Hybrid' ? 'HY-GEN' : 'EQ-GEN';
    }

    const plan = String(getVal('plan') || 'Direct').toLowerCase().includes('reg') ? 'Regular' : 'Direct';
    const option = String(getVal('option') || 'Growth').toLowerCase().includes('idcw') || String(getVal('option')).toLowerCase().includes('div') ? 'IDCW' : 'Growth';
    const rating = Math.min(5, Math.max(1, Number(getVal('rating', 'stars', 'fundrating')) || 4));
    
    const rawRisk = String(getVal('riskometer', 'risk', 'risklevel') || '').toLowerCase();
    let riskometer: RiskLevel = 'Very High';
    let riskometerScore = 6;
    if (rawRisk.includes('low to mod') || rawRisk.includes('low-to-mod')) {
      riskometer = 'Low to Moderate';
      riskometerScore = 2;
    } else if (rawRisk.includes('mod high') || rawRisk.includes('moderately high')) {
      riskometer = 'Moderately High';
      riskometerScore = 4;
    } else if (rawRisk.includes('moderate')) {
      riskometer = 'Moderate';
      riskometerScore = 3;
    } else if (rawRisk.includes('low')) {
      riskometer = 'Low';
      riskometerScore = 1;
    } else if (rawRisk.includes('high') && !rawRisk.includes('very')) {
      riskometer = 'High';
      riskometerScore = 5;
    } else {
      riskometer = 'Very High';
      riskometerScore = 6;
    }

    const nav = Number(getVal('nav', 'latestnav', 'price')) || 50.0;
    const aumCrores = Number(getVal('aumcrores', 'aum', 'assets')) || 10000;
    const ter = Number(getVal('ter', 'expenseratio', 'expense')) || (plan === 'Direct' ? 0.65 : 1.45);
    const fundManager = String(getVal('fundmanager', 'manager') || 'Investment Team').trim();
    const benchmark = String(getVal('benchmark', 'benchmarkindex') || (broadCategory === 'Equity' ? 'Nifty 500 TRI' : 'CRISIL Composite Debt Index')).trim();

    const return1Y = Number(getVal('return1y', '1yreturn', '1y')) || 15.0;
    const return3Y = getVal('return3y', '3yreturn', '3y') !== undefined ? Number(getVal('return3y', '3yreturn', '3y')) : undefined;
    const return5Y = getVal('return5y', '5yreturn', '5y') !== undefined ? Number(getVal('return5y', '5yreturn', '5y')) : undefined;
    const returnSinceInception = Number(getVal('returnsinception', 'inceptionreturn', 'inception')) || (return3Y || return1Y);

    const sharpeRatio = Number(getVal('sharperatio', 'sharpe')) || 1.15;
    const beta = Number(getVal('beta')) || (broadCategory === 'Equity' ? 0.88 : 0.25);
    const standardDeviation = Number(getVal('standarddeviation', 'stddev', 'volatility')) || (broadCategory === 'Equity' ? 13.5 : 3.5);
    const maxDrawdown = Number(getVal('maxdrawdown', 'drawdown')) || -15.0;

    const minSip = Number(getVal('minsip', 'sip')) || 500;
    const minInvestment = Number(getVal('mininvestment', 'lumpsum')) || 1000;
    const exitLoad = String(getVal('exitload', 'load') || '1% if redeemed within 1 year; Nil thereafter').trim();
    const lockInPeriod = String(getVal('lockinperiod', 'lockin') || (categoryCode === 'EQ-ELSS' ? '3 Years (Statutory 80C Lock-in)' : 'Nil')).trim();
    const opinion = String(getVal('opinion', 'mandate', 'summary') || `${category} scheme managed by ${amc}.`).trim();

    // Parse top holdings
    const holding1Str = String(getVal('topholding1', 'holding1') || '');
    const holding2Str = String(getVal('topholding2', 'holding2') || '');
    const topHoldings = [];
    if (holding1Str) {
      const parts = holding1Str.split(':');
      topHoldings.push({ company: parts[0]?.trim() || holding1Str, sector: 'Primary Holdings', weightage: Number(parts[1]?.replace(/[^0-9.]/g, '')) || 7.5 });
    } else {
      topHoldings.push({ company: 'Core Market Leaders', sector: 'Diversified', weightage: 8.5 });
    }
    if (holding2Str) {
      const parts = holding2Str.split(':');
      topHoldings.push({ company: parts[0]?.trim() || holding2Str, sector: 'Secondary Holdings', weightage: Number(parts[1]?.replace(/[^0-9.]/g, '')) || 6.0 });
    }

    // Default asset allocation
    const equityAllocation = broadCategory === 'Equity' ? 95 : broadCategory === 'Hybrid' ? 65 : 0;
    const debtAllocation = broadCategory === 'Debt' ? 95 : broadCategory === 'Hybrid' ? 30 : 0;
    const goldAllocation = broadCategory === 'Commodities' ? 98 : 0;
    const cashAllocation = Math.max(0, 100 - (equityAllocation + debtAllocation + goldAllocation));

    let taxClassification: MutualFundScheme['taxClassification'] = 'Equity-Oriented';
    if (broadCategory === 'Debt') taxClassification = 'Debt-Oriented';
    else if (broadCategory === 'Hybrid') taxClassification = equityAllocation >= 65 ? 'Equity-Oriented' : 'Debt-Oriented';
    else if (broadCategory === 'Commodities') taxClassification = 'Commodity-ETF';

    const recommendedMinHorizonYears = categoryCode === 'EQ-ELSS' ? 3 : broadCategory === 'Equity' ? 5 : broadCategory === 'Hybrid' ? 3 : 1;

    parsedSchemes.push({
      id: `uploaded_${Date.now()}_${index}`,
      code: String(100000 + Math.floor(Math.random() * 900000)),
      name,
      amc,
      category,
      categoryCode,
      broadCategory,
      plan,
      option,
      rating,
      riskometer,
      riskometerScore,
      nav,
      navDate: new Date().toISOString().slice(0, 10),
      aumCrores,
      ter,
      inceptionDate: '2020-01-01',
      fundAgeYears: 6.0,
      fundManager,
      benchmark,
      minInvestment,
      minSip,
      exitLoad,
      lockInPeriod,
      turnoverRatio: 25.0,
      return1D: 0.05,
      return1W: 0.40,
      return1M: 1.50,
      return3M: 4.00,
      return1Y,
      return3Y,
      return5Y,
      returnSinceInception,
      observationsCount: 504,
      standardDeviation,
      beta,
      sharpeRatio,
      maxDrawdown,
      equityAllocation,
      debtAllocation,
      cashAllocation,
      goldAllocation,
      topHoldings,
      sectorAllocations: [
        { sector: 'Core Holdings', weightage: 45.0 },
        { sector: 'Others / Cash', weightage: 55.0 }
      ],
      recommendedMinHorizonYears,
      idealRiskProfile: ['Moderate', 'Moderately Aggressive', 'Aggressive'],
      taxClassification,
      sidLink: 'https://www.sebi.gov.in/filings/mutual-funds.html',
      kimLink: 'https://www.amfiindia.com',
      factsheetDate: new Date().toISOString().slice(0, 10),
      opinion
    });
  });

  return {
    schemes: parsedSchemes,
    errors,
    totalParsed: parsedSchemes.length
  };
}
