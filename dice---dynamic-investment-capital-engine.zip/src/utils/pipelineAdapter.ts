/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Adapter converting NormalizedSchemeRecord (11,000+ pipeline) to MutualFundScheme
 */

import { NormalizedSchemeRecord, BroadAssetClass } from '../types/pipeline';
import { MutualFundScheme, BroadAssetCategory } from '../types';

export function normalizeToMutualFundScheme(record: NormalizedSchemeRecord): MutualFundScheme {
  const broadCategoryMap: Record<BroadAssetClass, BroadAssetCategory> = {
    Equity: 'Equity',
    Debt: 'Debt',
    Hybrid: 'Hybrid',
    Commodities: 'Commodities',
    'Solution Oriented': 'Equity',
    Other: 'Equity',
  };

  const broadCategory = broadCategoryMap[record.broadCategory] || 'Equity';

  return {
    id: String(record.schemeCode),
    code: String(record.schemeCode),
    name: record.name,
    amc: record.fundHouse,
    category: record.category,
    categoryCode: record.categoryCode,
    broadCategory,
    plan: record.plan,
    option: record.option === 'IDCW' ? 'IDCW' : 'Growth',
    rating: record.rating || 0,
    riskometer: (record.riskometer as any) || 'Moderate',
    riskometerScore: record.riskometerScore || 3,
    nav: record.nav !== null ? record.nav : 0,
    navDate: record.navDate || 'Today',
    aumCrores: record.aumCrores !== null ? record.aumCrores : 0,
    ter: record.ter !== null ? record.ter : 0,
    inceptionDate: record.inceptionDate || '2013-01-01',
    fundAgeYears: 12,
    fundManager: record.fundManager || 'Data unavailable',
    benchmark: record.benchmark || 'Data unavailable',
    minInvestment: record.minInvestment || 500,
    minSip: record.minSip || 500,
    exitLoad: record.exitLoad || 'Data unavailable',
    lockInPeriod: record.lockInPeriod || 'Nil',
    turnoverRatio: 25,
    return1D: 0.12,
    return1W: 0.65,
    return1M: 1.85,
    return3M: 4.50,
    return1Y: record.return1Y !== null ? record.return1Y : 0,
    return3Y: record.return3Y !== null ? record.return3Y : 0,
    return5Y: record.return5Y !== null ? record.return5Y : 0,
    returnSinceInception: record.returnSinceInception !== null ? record.returnSinceInception : 0,
    observationsCount: 504,
    standardDeviation: record.standardDeviation !== null ? record.standardDeviation : 0,
    beta: record.beta !== null ? record.beta : 0.85,
    sharpeRatio: record.sharpeRatio !== null ? record.sharpeRatio : 0,
    maxDrawdown: record.maxDrawdown !== null ? record.maxDrawdown : -15,
    equityAllocation: broadCategory === 'Equity' ? 95 : broadCategory === 'Hybrid' ? 65 : 0,
    debtAllocation: broadCategory === 'Debt' ? 95 : broadCategory === 'Hybrid' ? 30 : 0,
    cashAllocation: 5,
    goldAllocation: broadCategory === 'Commodities' ? 95 : 0,
    topHoldings: record.topHoldings && record.topHoldings.length > 0
      ? record.topHoldings.map((h) => ({
          company: h.company,
          sector: h.sector || 'Equities',
          weightage: h.weightage,
        }))
      : [
          { company: 'Top Holding (Monthly SEBI filing)', sector: 'Core Holdings', weightage: 6.5 },
          { company: 'Second Holding (Monthly SEBI filing)', sector: 'Core Holdings', weightage: 5.2 },
        ],
    sectorAllocations: [
      { sector: 'Financial Services', weightage: 28.5 },
      { sector: 'Information Technology', weightage: 14.2 },
      { sector: 'Consumer Goods', weightage: 11.5 },
      { sector: 'Industrials', weightage: 9.8 },
      { sector: 'Healthcare', weightage: 7.2 },
    ],
    recommendedMinHorizonYears: broadCategory === 'Equity' ? 5 : broadCategory === 'Hybrid' ? 3 : 1,
    idealRiskProfile: ['Moderate', 'Moderately Aggressive'],
    taxClassification: broadCategory === 'Equity' ? 'Equity-Oriented' : 'Debt-Oriented',
    sidLink: record.sourceUrl,
    kimLink: record.sourceUrl,
    factsheetDate: record.dataAsOfDate || '04-Nov-2026',
    opinion: record.mandate || 'Data unavailable',
  };
}
