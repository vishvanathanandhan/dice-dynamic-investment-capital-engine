/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE - Dynamic Investment Capital Engine
 * Grounded in NISM Series V-A & DICE Master Specifications
 */

import React, { useState } from 'react';
import { SchemeProvider, useSchemes } from './context/SchemeContext';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { HeroCards } from './components/HeroCards';
import { QuestionnaireView } from './components/QuestionnaireView';
import { ResultsView } from './components/ResultsView';
import { SchemeDetailModal } from './components/SchemeDetailModal';
import { SchemeUploadModal } from './components/SchemeUploadModal';
import { FundCompareModal } from './components/FundCompareModal';
import { PointToPointModal } from './components/PointToPointModal';
import { WatchlistModal } from './components/WatchlistModal';
import { AmfiSyncModal } from './components/AmfiSyncModal';
import { CalculatorsSection } from './components/CalculatorsSection';
import { FundMonitorHeatmap } from './components/FundMonitorHeatmap';
import { WealthBuilderTable } from './components/WealthBuilderTable';
import { ToolsGrid } from './components/ToolsGrid';
import { MethodologyView } from './components/MethodologyView';
import { DataQualityDashboard } from './components/DataQualityDashboard';
import { EducationalDisclaimerModal } from './components/EducationalDisclaimerModal';
import { DisclaimerView } from './components/DisclaimerView';
import {
  MutualFundScheme,
  MatchAnalysisResponse,
  DICEScoringResult,
  BroadAssetCategory,
} from './types';
import { normalizeToMutualFundScheme } from './utils/pipelineAdapter';
import { NormalizedSchemeRecord } from './types/pipeline';
import { ArrowRight, Star, ChevronRight, FileSpreadsheet, Loader2, ShieldAlert } from 'lucide-react';

function AppContent() {
  const { t } = useLanguage();
  const { schemes, equitySchemes, debtSchemes, hybridSchemes, commoditySchemes } = useSchemes();

  const [activeView, setActiveView] = useState<
    'home' | 'questionnaire' | 'results' | 'calculators' | 'monitor' | 'methodology' | 'data_quality' | 'disclaimer'
  >('home');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedScheme, setSelectedScheme] = useState<MutualFundScheme | null>(null);
  const [currentDiceResult, setCurrentDiceResult] = useState<DICEScoringResult | undefined>(undefined);
  const [matchData, setMatchData] = useState<MatchAnalysisResponse | null>(null);

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [isPointToPointOpen, setIsPointToPointOpen] = useState(false);
  const [isWatchlistOpen, setIsWatchlistOpen] = useState(false);
  const [isAmfiModalOpen, setIsAmfiModalOpen] = useState(false);
  const [isFooterDiceRolling, setIsFooterDiceRolling] = useState(false);

  // External Category Filter for WealthBuilderTable
  const [externalFilter, setExternalFilter] = useState<'wealth' | 'tax' | 'income' | null>(null);

  // Top Funds in Categories tab switcher (Equity, Debt, Hybrid, Commodities) from PDF
  const [topCategoryTab, setTopCategoryTab] = useState<BroadAssetCategory>('Equity');
  const [topCategorySchemes, setTopCategorySchemes] = useState<MutualFundScheme[]>([]);
  const [isLoadingTopCategory, setIsLoadingTopCategory] = useState(false);

  // Load Top 5 funds for selected avenue from 11,000+ pipeline
  React.useEffect(() => {
    setIsLoadingTopCategory(true);
    fetch(`/api/pipeline/schemes?broadCategory=${topCategoryTab}&sortBy=aumCrores&sortOrder=desc&limit=5`)
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.data) {
          const list = (json.data.schemes || []).map((r: NormalizedSchemeRecord) =>
            normalizeToMutualFundScheme(r)
          );
          setTopCategorySchemes(list);
        }
      })
      .catch((e) => console.error('Failed loading top category schemes:', e))
      .finally(() => setIsLoadingTopCategory(false));
  }, [topCategoryTab]);

  const handleSelectCuratedFilter = (filterType: 'wealth' | 'tax' | 'income') => {
    setExternalFilter(filterType);
    const elem = document.getElementById('wealth-builder-section');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCompleteQuestionnaire = (data: MatchAnalysisResponse) => {
    setMatchData(data);
    setActiveView('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenSchemeDetail = (scheme: MutualFundScheme, diceResult?: DICEScoringResult) => {
    setSelectedScheme(scheme);
    setCurrentDiceResult(diceResult);
  };

  const handleAnalyzeSchemeWithDICE = (scheme: MutualFundScheme) => {
    setSelectedScheme(scheme);
    setActiveView('questionnaire');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle all tools without generic fallback to Parag Parikh
  const handleSelectTool = (toolId: string) => {
    switch (toolId) {
      case 'data_quality':
        setActiveView('data_quality');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        break;
      case 'amfi_sync':
        setIsAmfiModalOpen(true);
        break;
      case 'upload_excel':
        setIsUploadModalOpen(true);
        break;
      case 'fund_compare':
        setIsCompareModalOpen(true);
        break;
      case 'point_to_point':
        setIsPointToPointOpen(true);
        break;
      case 'watchlist':
        setIsWatchlistOpen(true);
        break;
      case 'risk_assessment':
      case 'planner':
        setActiveView('questionnaire');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        break;
      case 'calculators':
        setActiveView('calculators');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        break;
      case 'monitor':
        setActiveView('monitor');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        break;
      case 'screener':
      case 'best_funds':
      case 'dividends':
      case 'passive':
        setActiveView('home');
        const elem = document.getElementById('wealth-builder-section');
        if (elem) elem.scrollIntoView({ behavior: 'smooth' });
        break;
      default:
        setIsCompareModalOpen(true);
        break;
    }
  };

  // Get active schemes for Top Category strip
  const activeCategorySchemes =
    topCategoryTab === 'Equity'
      ? equitySchemes
      : topCategoryTab === 'Debt'
      ? debtSchemes
      : topCategoryTab === 'Hybrid'
      ? hybridSchemes
      : commoditySchemes;

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] dark:bg-slate-950 text-[#1E293B] dark:text-slate-100 transition-colors duration-300">
      {/* 1. Header */}
      <Header
        activeView={activeView}
        onNavigate={(view) => {
          setActiveView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        hasResults={matchData !== null}
        onOpenUploadModal={() => setIsUploadModalOpen(true)}
      />

      {/* 2. Main Viewport */}
      <main className="flex-1">
        {activeView === 'home' && (
          <div className="space-y-0">
            {/* Hero & 3 Curated Solution Cards from PDF */}
            <HeroCards
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onSelectCategoryFilter={handleSelectCuratedFilter}
              onStartProfiler={() => setActiveView('questionnaire')}
              onOpenUploadModal={() => setIsUploadModalOpen(true)}
              onSelectScheme={handleOpenSchemeDetail}
              onAnalyzeScheme={handleAnalyzeSchemeWithDICE}
            />

            {/* Top Funds in Categories Tabs matching PDF Page 1 */}
            <section className="py-10 bg-white dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800 transition-colors duration-300">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                      {t('categories.heading', 'Top Funds in Categories')}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {t('categories.subheading', 'Top 5 funds by asset size and verified regulatory track record from 11,000+ database.')}
                    </p>
                  </div>

                  {/* Category Filter Tabs */}
                  <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-medium">
                    {[
                      { tab: 'Equity' as BroadAssetCategory, label: t('cat.equity', 'Equity'), count: '3,173' },
                      { tab: 'Debt' as BroadAssetCategory, label: t('cat.debt', 'Debt'), count: '3,009' },
                      { tab: 'Hybrid' as BroadAssetCategory, label: t('cat.hybrid', 'Hybrid'), count: '1,009' },
                      { tab: 'Commodities' as BroadAssetCategory, label: t('cat.commodities', 'Commodities'), count: '189' },
                    ].map(({ tab, label, count }) => (
                      <button
                        key={tab}
                        onClick={() => setTopCategoryTab(tab)}
                        className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                          topCategoryTab === tab
                            ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {label} ({count})
                      </button>
                    ))}
                  </div>
                </div>

                {/* Scheme Cards Grid - 5 Top Schemes from Pipeline */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-2 relative min-h-[140px]">
                  {isLoadingTopCategory && (
                    <div className="absolute inset-0 bg-white/70 dark:bg-slate-900/70 backdrop-blur-2xs flex items-center justify-center z-10 rounded-2xl">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-700 dark:text-amber-400 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-xl shadow-xs border border-amber-200 dark:border-amber-800">
                        <Loader2 className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />
                        <span>Loading top {topCategoryTab} funds...</span>
                      </div>
                    </div>
                  )}

                  {topCategorySchemes.map((f, i) => (
                    <div
                      key={f.id}
                      onClick={() => handleOpenSchemeDetail(f)}
                      className="group cursor-pointer bg-slate-50/70 dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-2xl p-4 transition-all duration-150 hover:shadow-xs flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500 font-mono mb-1">
                          <span className="font-bold text-slate-600 dark:text-slate-300">#{i + 1} · {f.categoryCode || f.category}</span>
                          <span className="text-amber-600 dark:text-amber-400 font-bold">
                            {f.rating > 0 ? `★ ${f.rating}.0` : 'Verified'}
                          </span>
                        </div>
                        <h3 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors line-clamp-2 leading-snug">
                          {f.name}
                        </h3>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 truncate">
                          {f.amc}
                        </p>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs">
                        <div>
                          <span className="text-[9px] text-slate-400 dark:text-slate-500 block leading-none">1Y Return</span>
                          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-xs">
                            {f.return1Y ? `+${f.return1Y}%` : 'N/A'}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button className="px-2 py-1 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-[10px] font-semibold text-slate-700 dark:text-slate-200 group-hover:border-amber-400 dark:group-hover:border-amber-400 cursor-pointer">
                            {t('common.view_details', 'View Details')}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Calculators Section */}
            <CalculatorsSection onViewSchemeDetails={handleOpenSchemeDetail} />

            {/* Fund Monitor Heatmap with Top Schemes Leaderboard */}
            <FundMonitorHeatmap onSelectScheme={handleOpenSchemeDetail} />

            {/* Wealth Builder Funds Table */}
            <WealthBuilderTable
              onSelectScheme={(scheme) => handleOpenSchemeDetail(scheme)}
              onAnalyzeSchemeWithDICE={handleAnalyzeSchemeWithDICE}
              onOpenUploadModal={() => setIsUploadModalOpen(true)}
              externalCategoryFilter={externalFilter}
            />

            {/* Tools Grid from PDF */}
            <ToolsGrid onSelectTool={handleSelectTool} />
          </div>
        )}

        {activeView === 'questionnaire' && (
          <QuestionnaireView
            onComplete={handleCompleteQuestionnaire}
            onCancel={() => setActiveView('home')}
          />
        )}

        {activeView === 'results' && matchData && (
          <ResultsView
            data={matchData}
            onRetake={() => setActiveView('questionnaire')}
            onOpenSchemeDetail={handleOpenSchemeDetail}
          />
        )}

        {activeView === 'calculators' && (
          <div className="py-6">
            <CalculatorsSection />
          </div>
        )}

        {activeView === 'monitor' && (
          <div className="py-6">
            <FundMonitorHeatmap />
          </div>
        )}

        {activeView === 'methodology' && <MethodologyView />}

        {activeView === 'data_quality' && (
          <DataQualityDashboard
            onSelectSchemeDetail={(s) => {
              // Convert to MutualFundScheme shape for detail view
              const converted: MutualFundScheme = {
                id: s.id,
                code: String(s.schemeCode),
                name: s.name,
                amc: s.fundHouse,
                category: s.category,
                categoryCode: s.categoryCode,
                broadCategory: s.broadCategory as any,
                plan: s.plan,
                option: s.option as any,
                rating: s.rating || 0,
                riskometer: (s.riskometer as any) || 'Moderate',
                riskometerScore: s.riskometerScore || 3,
                nav: s.nav || 0,
                navDate: s.navDate || 'Today',
                aumCrores: s.aumCrores || 0,
                ter: s.ter || 0,
                inceptionDate: s.inceptionDate || '2013-01-01',
                fundAgeYears: 12,
                fundManager: s.fundManager || 'Data unavailable',
                benchmark: s.benchmark || 'Data unavailable',
                minInvestment: s.minInvestment || 500,
                minSip: s.minSip || 500,
                exitLoad: s.exitLoad || 'Data unavailable',
                lockInPeriod: s.lockInPeriod || 'Nil',
                turnoverRatio: 25,
                return1D: 0.1,
                return1W: 0.5,
                return1M: 1.5,
                return3M: 4.2,
                return1Y: s.return1Y || 0,
                return3Y: s.return3Y || 0,
                return5Y: s.return5Y || 0,
                returnSinceInception: s.returnSinceInception || 0,
                observationsCount: 504,
                standardDeviation: s.standardDeviation || 0,
                beta: s.beta || 0.85,
                sharpeRatio: s.sharpeRatio || 0,
                maxDrawdown: s.maxDrawdown || -15,
                equityAllocation: s.broadCategory === 'Equity' ? 95 : 0,
                debtAllocation: s.broadCategory === 'Debt' ? 95 : 0,
                cashAllocation: 5,
                goldAllocation: s.broadCategory === 'Commodities' ? 95 : 0,
                topHoldings: s.topHoldings.map((h) => ({
                  company: h.company,
                  sector: h.sector || 'Equities',
                  weightage: h.weightage,
                })),
                sectorAllocations: [],
                recommendedMinHorizonYears: 5,
                idealRiskProfile: ['Moderate', 'Moderately Aggressive'],
                taxClassification: 'Equity-Oriented',
                sidLink: s.sourceUrl,
                kimLink: s.sourceUrl,
                factsheetDate: s.dataAsOfDate,
                opinion: s.mandate || 'Data unavailable',
              };
              handleOpenSchemeDetail(converted);
            }}
          />
        )}

        {/* 8. Full 12-Section Website Disclaimer Page */}
        {activeView === 'disclaimer' && (
          <DisclaimerView
            onBackToHome={() => {
              setActiveView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Scheme Detail 8-Tab Modal */}
      {selectedScheme && (
        <SchemeDetailModal
          scheme={selectedScheme}
          diceResult={currentDiceResult}
          onClose={() => {
            setSelectedScheme(null);
            setCurrentDiceResult(undefined);
          }}
        />
      )}

      {/* Upload Scheme Excel / CSV Modal */}
      {isUploadModalOpen && (
        <SchemeUploadModal onClose={() => setIsUploadModalOpen(false)} />
      )}

      {/* Multi-Fund Compare Modal */}
      {isCompareModalOpen && (
        <FundCompareModal
          onClose={() => setIsCompareModalOpen(false)}
          onOpenSchemeDetail={handleOpenSchemeDetail}
        />
      )}

      {/* Point-to-Point Calculator Modal */}
      {isPointToPointOpen && (
        <PointToPointModal
          onClose={() => setIsPointToPointOpen(false)}
          onOpenSchemeDetail={handleOpenSchemeDetail}
        />
      )}

      {/* Watchlist Modal */}
      {isWatchlistOpen && (
        <WatchlistModal
          onClose={() => setIsWatchlistOpen(false)}
          onOpenSchemeDetail={handleOpenSchemeDetail}
          onAnalyzeSchemeWithDICE={handleAnalyzeSchemeWithDICE}
        />
      )}

      {/* AMFI Live Data Pipeline Modal */}
      {isAmfiModalOpen && (
        <AmfiSyncModal
          isOpen={isAmfiModalOpen}
          onClose={() => setIsAmfiModalOpen(false)}
          onSelectScheme={handleOpenSchemeDetail}
        />
      )}

      {/* Website Entry Educational & Regulatory Disclaimer Modal */}
      <EducationalDisclaimerModal
        onNavigateToDisclaimer={() => {
          setActiveView('disclaimer');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-10 mt-12 text-xs text-slate-500 dark:text-slate-400 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div
              onClick={() => {
                setIsFooterDiceRolling(true);
                setTimeout(() => setIsFooterDiceRolling(false), 850);
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-3 cursor-pointer group"
              title="Click to roll the dice!"
            >
              <img
                src="/assets/aistudio/Logo_DICE__1_-removebg-preview_f2e8a9ea.png"
                alt="DICE"
                className={`w-7 h-7 object-contain transition-transform duration-200 group-hover:scale-110 ${
                  isFooterDiceRolling ? 'animate-dice-roll' : ''
                }`}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/assets/aistudio/Logo_DICE__1__09a2a920.png';
                }}
              />
              <span className="font-extrabold text-slate-900 dark:text-white text-sm">
                DICE — Dynamic Investment Capital Engine
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-5 text-slate-600 dark:text-slate-300 font-medium">
              <button onClick={() => { setActiveView('data_quality'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="text-emerald-700 dark:text-emerald-400 font-bold hover:text-emerald-900 dark:hover:text-emerald-300 flex items-center gap-1 cursor-pointer">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>{t('tools.data_quality_title', 'Data Quality (11k+ Schemes)')}</span>
              </button>
              <button onClick={() => setIsUploadModalOpen(true)} className="hover:text-emerald-800 dark:hover:text-emerald-300 text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-1 cursor-pointer">
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>{t('nav.upload_excel', 'Upload Schemes (Excel)')}</span>
              </button>
              <button onClick={() => setIsCompareModalOpen(true)} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
                {t('tools.compare_title', 'Fund Compare')}
              </button>
              <button onClick={() => setIsWatchlistOpen(true)} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
                {t('tools.watchlist_title', 'My Watchlist')}
              </button>
              <button onClick={() => { setActiveView('questionnaire'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
                {t('nav.profiler', '20Q Profiler')}
              </button>
              <button onClick={() => { setActiveView('calculators'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
                {t('nav.calculators', 'SIP Calculators')}
              </button>
              <button onClick={() => { setActiveView('methodology'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">
                {t('nav.methodology', 'DICE Methodology')}
              </button>
              <button
                onClick={() => {
                  setActiveView('disclaimer');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-amber-800 dark:text-amber-400 font-bold hover:text-amber-950 dark:hover:text-amber-300 underline underline-offset-2 flex items-center gap-1 cursor-pointer"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>{t('nav.disclaimer', 'Website Disclaimer')}</span>
              </button>
            </div>
          </div>

          {/* Educational Disclaimer Section in Footer with embedded link */}
          <div className="bg-amber-50/60 dark:bg-[#1E1E24] border border-amber-200/80 dark:border-[#2E2E38] rounded-2xl p-5 space-y-2.5 text-slate-700 dark:text-slate-300 transition-colors">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span className="font-extrabold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                {t('footer.disclaimer_title', 'DICE Educational Platform Disclaimer')} —{' '}
                <button
                  onClick={() => {
                    setActiveView('disclaimer');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-amber-800 dark:text-amber-400 font-bold hover:text-amber-950 dark:hover:text-amber-300 underline underline-offset-2 inline-flex items-center gap-1 cursor-pointer normal-case"
                >
                  <span>{t('footer.read_disclaimer', 'Read Full 12-Section Disclaimer Page')}</span>
                  <ArrowRight className="w-3 h-3 inline" />
                </button>
              </span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300">
              DICE (Dynamic Investment Capital Engine) is an independent financial literacy, educational and academic research platform developed to promote awareness of mutual funds, financial markets and investment-related concepts. The platform is designed solely for educational and informational purposes. Its content, scheme comparisons, historical performance data, financial calculators, questionnaires and analytical tools do not constitute investment advice, financial planning, portfolio management or recommendations to buy, sell or hold any financial product. DICE is not a SEBI-registered Investment Adviser, Research Analyst, mutual fund distributor or Asset Management Company.
            </p>
            <div className="text-[11px] text-amber-950 dark:text-amber-300 font-semibold pt-1 border-t border-amber-200/60 dark:border-[#2E2E38]">
              Important: Mutual fund investments are subject to market risks. Read all scheme-related documents carefully before investing.
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-[#2E2E38] flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-[11px] leading-relaxed text-slate-400 dark:text-slate-500">
            <p className="max-w-4xl">
              <strong className="text-slate-600 dark:text-slate-300">{t('footer.statutory', 'Statutory Notice: Mutual fund investments are subject to market risks, read all scheme related documents carefully. DICE is an independent academic and educational prototype.')}</strong>
            </p>
            <div className="font-mono text-slate-400 dark:text-slate-500 shrink-0">
              {t('footer.project', 'DICE v1.0 · Engine Prototype')}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <SchemeProvider>
          <AppContent />
        </SchemeProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
