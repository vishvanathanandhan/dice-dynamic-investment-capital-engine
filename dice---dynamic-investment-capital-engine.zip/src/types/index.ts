/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * DICE - Dynamic Investment Capital Engine Types
 */

export type RiskLevel = 'Low' | 'Low to Moderate' | 'Moderate' | 'Moderately High' | 'High' | 'Very High';

export type MatchLabel = 'High Match' | 'Medium Match' | 'Low Match' | 'Not recommended';

export type BroadAssetCategory = 'Equity' | 'Debt' | 'Hybrid' | 'Commodities';

export interface SchemeHolding {
  company: string;
  sector: string;
  weightage: number; // percentage
}

export interface SchemeSector {
  sector: string;
  weightage: number; // percentage
}

export interface MutualFundScheme {
  id: string;
  code: string;
  isin?: string;
  name: string;
  amc: string;
  category: string; // e.g. "Flexi Cap Fund", "Large Cap Fund", "Liquid Fund"
  categoryCode: string; // e.g. "EQ-FLX", "EQ-LC", "DB-LIQ", "HY-AGG"
  broadCategory: BroadAssetCategory;
  plan: 'Direct' | 'Regular';
  option: 'Growth' | 'IDCW';
  rating: number; // 1 to 5 stars
  riskometer: RiskLevel;
  riskometerScore: number; // 1 to 6
  nav: number; // in INR
  navDate: string;
  aumCrores: number; // in Rs. Crores
  ter: number; // Total Expense Ratio in %
  inceptionDate: string;
  fundAgeYears: number;
  fundManager: string;
  benchmark: string; // e.g. "Nifty 500 TRI", "Nifty 50 TRI", "CRISIL Liquid Debt A-I Index"
  minInvestment: number; // INR
  minSip: number; // INR
  exitLoad: string;
  lockInPeriod: string; // e.g. "3 Years (ELSS)" or "Nil"
  turnoverRatio: number; // %
  
  // Performance returns (%)
  return1D: number;
  return1W: number;
  return1M: number;
  return3M: number;
  return1Y: number;
  return3Y?: number; // CAGR
  return5Y?: number; // CAGR
  returnSinceInception: number;
  
  // Risk metrics (derived from ~500 trading days)
  observationsCount: number; // e.g. 504 trading days (~2 yrs)
  standardDeviation: number; // % annualized
  beta: number;
  sharpeRatio: number;
  treynorRatio?: number;
  alpha?: number;
  maxDrawdown: number; // %
  trackingError?: number;
  
  // Debt specific metrics (if applicable)
  modifiedDuration?: number; // in years
  averageMaturity?: number; // in years
  creditQualityProfile?: string; // e.g., "85% AAA / Sov, 15% AA+"
  
  // Portfolio Composition
  equityAllocation: number; // %
  debtAllocation: number; // %
  cashAllocation: number; // %
  goldAllocation: number; // %
  topHoldings: SchemeHolding[];
  sectorAllocations: SchemeSector[];
  
  // Suitability flags
  recommendedMinHorizonYears: number;
  idealRiskProfile: ('Conservative' | 'Moderately Conservative' | 'Moderate' | 'Moderately Aggressive' | 'Aggressive')[];
  taxClassification: 'Equity-Oriented' | 'Debt-Oriented' | 'Hybrid-Equity' | 'Commodity-ETF';
  
  // Document Links
  sidLink: string;
  kimLink: string;
  factsheetDate: string;
  opinion: string;
  isUploaded?: boolean;
  benchmarkReturn1Y?: number;
}

export interface QuestionOption {
  id: string;
  label: string;
  subtext?: string;
  scoreImpact: {
    riskCapacity: number; // -2 to +2
    riskWillingness: number; // -2 to +2
    horizonYears?: number;
    liquidityNeed?: 'High' | 'Moderate' | 'Low';
    behavioralBiasDetected?: string;
  };
  holdingInsight: string;
  aiGuidance: string;
}

export interface Question {
  id: number;
  title: string;
  category: 'Context & Holdings' | 'Behavioral Biases' | 'Risk Capacity & Willingness' | 'Strategy & Discipline';
  question: string;
  explanationWhyAsked: string;
  behaviouralConcept: string; // NISM Chapter 1 / 10 reference
  holdingAspect: string; // Financial holding impact
  options: QuestionOption[];
}

export interface UserResponses {
  investorName: string;
  answers: Record<number, string>; // questionId -> optionId
}

export interface InvestorProfile {
  name: string;
  riskCapacityScore: number; // 0-100
  riskWillingnessScore: number; // 0-100
  overallRiskScore: number; // 0-100 (combination)
  riskProfileCategory: 'Conservative' | 'Moderately Conservative' | 'Moderate' | 'Moderately Aggressive' | 'Aggressive';
  goal: string;
  timeHorizonYears: number;
  investmentAmount: number;
  mode: 'SIP' | 'Lumpsum' | 'Both';
  liquidityNeed: 'High' | 'Moderate' | 'Low';
  detectedBiases: {
    bias: string;
    description: string;
    mitigationStrategy: string;
  }[];
  financialHoldingsSummary: {
    hasEmergencyFund: boolean;
    savingsRatePercentage: number;
    primaryExistingHolding: string;
    liabilityLevel: string;
  };
  targetAssetAllocation: {
    equity: number;
    debt: number;
    gold: number;
    cash: number;
  };
}

export interface SchemeDimensionScore {
  score: number; // 0 to 100
  weightedScore: number;
  status: 'High Match' | 'Medium Match' | 'Low Match' | 'Mismatch';
  summary: string;
}

export interface DICEScoringResult {
  scheme: MutualFundScheme;
  isEligible: boolean;
  ineligibilityReasons: string[];
  
  // 5 Dimensions
  suitabilityScore: SchemeDimensionScore; // 30% weight
  riskScore: SchemeDimensionScore; // 25% weight
  performanceScore: SchemeDimensionScore; // 20% weight
  returnScore: SchemeDimensionScore; // 15% weight
  taxAndExitScore: SchemeDimensionScore; // 10% weight
  
  totalScore: number; // 0 - 100
  matchLabel: MatchLabel;
  rank: number;
  
  whyMatches: string[];
  whyNotMatches: string[];
  exactMatches: string[];
  partialMatches: string[];
  mismatches: string[];
  
  futureValueProjections: {
    rateAssumption: number;
    investedAmount: number;
    projectedGain: number;
    projectedTotalValue: number;
  }[];
}

export interface MatchAnalysisResponse {
  investorProfile: InvestorProfile;
  topMatches: DICEScoringResult[];
  allEvaluations: DICEScoringResult[];
  executiveSummary: string;
  engineReasoning: string;
}
