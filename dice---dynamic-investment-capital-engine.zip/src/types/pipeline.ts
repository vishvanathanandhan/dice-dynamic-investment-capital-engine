/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Normalized Mutual Fund Scheme Database Schema & Pipeline Types
 * Grounded in AMFI Official, TIGZIG MF API & SEBI AMC Disclosures
 */

export type BroadAssetClass = 'Equity' | 'Debt' | 'Hybrid' | 'Commodities' | 'Solution Oriented' | 'Other';
export type SchemePlan = 'Direct' | 'Regular';
export type SchemeOption = 'Growth' | 'IDCW' | 'Bonus' | 'Other';
export type SchemeStatus = 'active' | 'inactive' | 'matured';
export type ValidationStatus = 'verified' | 'partial' | 'pending_validation';
export type RiskometerLevel =
  | 'Low'
  | 'Low to Moderate'
  | 'Moderate'
  | 'Moderately High'
  | 'High'
  | 'Very High'
  | null;

export interface HoldingRecord {
  company: string;
  weightage: number; // percentage
  sector?: string;
  disclosureDate?: string;
}

export interface CalculationAuditInfo {
  methodology: string;
  observationPeriod: string;
  benchmarkUsed: string | null;
  riskFreeRate: number; // e.g. 0.065 (6.5%)
  calculationDate: string;
  totalObservations?: number;
}

export interface RawSourceMeta {
  amfiDailyFundAum?: number | null;
  amfiDailyAumDate?: string | null;
  amfiDailyBenchmark?: string | null;
  amfiDailyRiskometer?: string | null;
  ssdDocDate?: string | null;
  ssdAllotmentDate?: string | null;
  ssdStatus?: string | null;
  ssdFundType?: string | null;
  terDate?: string | null;
  terRegular?: number | null;
  terDirect?: number | null;
  sourceProvider: string;
}

export interface NormalizedSchemeRecord {
  // Identifiers
  id: string; // usually string(schemeCode)
  schemeCode: number;
  isin: string | null;
  isinReinvestment: string | null;
  txicCode?: string | null;

  // Scheme Identity and Classification
  name: string;
  fundHouse: string; // AMC name
  category: string; // SEBI category e.g., "Flexi Cap Fund", "Large Cap Fund"
  categoryCode: string; // e.g. "EQ-FLX", "EQ-LC", "DB-LIQ"
  broadCategory: BroadAssetClass; // Derived & clearly identified
  plan: SchemePlan; // Direct / Regular
  option: SchemeOption; // Growth / IDCW
  status: SchemeStatus; // active, inactive, matured

  // Risk and Fund Metrics
  rating: number | null; // Stars (1 to 5) only if verified identifiable provider, else null
  ratingProvider: string | null; // e.g., "CRISIL" or null
  riskometer: RiskometerLevel;
  riskometerScore: number | null; // 1 to 6 or null
  nav: number | null; // Current NAV in INR
  navDate: string | null;
  aumCrores: number | null; // in Rs. Crores
  aumDate: string | null;
  ter: number | null; // Total Expense Ratio in %
  terDate: string | null;
  fundManager: string | null; // e.g. "Rajeev Thakkar"
  benchmark: string | null; // e.g. "NIFTY 500 TRI"

  // Performance and Returns (all null if incomplete/insufficient)
  return1Y: number | null; // 1-Year Return %
  return3Y: number | null; // 3-Year Annualized CAGR %
  return5Y: number | null; // 5-Year Annualized CAGR %
  returnSinceInception: number | null; // Inception Return %
  inceptionReturnKind: 'annualized' | 'cumulative' | 'unavailable';
  inceptionDate: string | null;

  // Risk-Adjusted Analytics
  sharpeRatio: number | null;
  beta: number | null;
  standardDeviation: number | null; // % Annualized Volatility
  maxDrawdown: number | null; // % Peak-to-trough drop

  // Investment Terms and Portfolio
  minSip: number | null; // in INR
  minInvestment: number | null;
  exitLoad: string | null;
  lockInPeriod: string | null; // "3 Years (ELSS)" or "Nil" or null
  topHolding1: string | null; // "Company: Weight%"
  topHolding2: string | null;
  topHoldings: HoldingRecord[];
  mandate: string | null; // Investment Mandate / Objective

  // Metadata, Source Links & Validation Audit
  sourceUrl: string;
  sourceDocument: string;
  dataAsOfDate: string;
  retrievalTimestamp: string;
  validationStatus: ValidationStatus;
  missingFields: string[];
  calculationAudit: CalculationAuditInfo;
  rawSourceData: RawSourceMeta;
}

export interface PipelineStats {
  totalSchemes: number;
  activeSchemes: number;
  inactiveSchemes: number;
  maturedSchemes: number;
  directPlans: number;
  regularPlans: number;
  latestNavUpdateDate: string | null;
  latestTerDate: string | null;
  latestPortfolioDate: string | null;
  lastIngestionTimestamp: string | null;
  ingestionStatus: 'idle' | 'running' | 'completed' | 'error';
  lastError: string | null;

  // Field Coverage Percentages (0 to 100)
  fieldCompleteness: {
    nav: number;
    aum: number;
    ter: number;
    fundManager: number;
    benchmark: number;
    riskometer: number;
    return1Y: number;
    return3Y: number;
    return5Y: number;
    sharpeRatio: number;
    standardDeviation: number;
    maxDrawdown: number;
    minSip: number;
    exitLoad: number;
    lockInPeriod: number;
    mandate: number;
    topHoldings: number;
    starRating: number;
  };

  // Stale and Quality Anomaly Counts
  staleNavCount: number; // NAV older than 5 days for active schemes
  staleTerCount: number; // TER older than 45 days
  missingMandateCount: number;
  benchmarkMismatchesCount: number;
}

export interface DataQualityIssue {
  id: string;
  schemeCode: number | null;
  schemeName: string;
  category: string;
  source: string;
  issueCode: string;
  issue: string;
  detail: string;
  severity: 'high' | 'medium' | 'low';
  asOf: string;
}

export interface PaginatedSchemesResponse {
  total: number;
  offset: number;
  limit: number;
  hasMore: boolean;
  filtersApplied: {
    search?: string;
    amc?: string;
    category?: string;
    broadCategory?: string;
    plan?: string;
    option?: string;
    status?: string;
    onlyWithAum?: boolean;
    onlyWithTer?: boolean;
    onlyWithReturns?: boolean;
  };
  schemes: NormalizedSchemeRecord[];
}
