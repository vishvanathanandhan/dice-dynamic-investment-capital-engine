/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Theme Context & Custom Toggle Switch
 * Supports Light & Dark mode with smooth transitions, persisting to localStorage
 * Slider design accurately reflects the user's reference image (image_8fff0741.png)
 */

import React, { createContext, useContext, useEffect, useState } from 'react';

type ThemeMode = 'light' | 'dark';

interface ThemeContextType {
  theme: ThemeMode;
  isDark: boolean;
  toggleTheme: () => void;
  setTheme: (theme: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'dice_theme_mode_v1';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
    } catch {
      // fallback
    }
    return 'light';
  });

  const isDark = theme === 'dark';

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }

    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // ignore
    }
  }, [theme, isDark]);

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, isDark, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

/**
 * Custom Theme Toggle Switch modeled precisely on user attachment image_8fff0741.png:
 * - In Light Mode: Smooth light-gray pill (#D4D4D8 / bg-slate-300) with circle knob positioned on right/left
 * - In Dark Mode: Stark black pill with crisp white outer border ring and inset white circular knob
 * - Smooth CSS glide transition on the knob and track
 */
export const ThemeToggleSwitch: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { isDark, toggleTheme } = useTheme();

  return (
    <button
      type="button"
      role="switch"
      aria-checked={isDark}
      aria-label={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      onClick={toggleTheme}
      title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      className={`relative inline-flex items-center h-7 w-14 rounded-full transition-all duration-300 ease-in-out cursor-pointer select-none focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
        isDark
          ? 'bg-black border-2 border-white shadow-xs'
          : 'bg-[#D6D9DD] border border-slate-300/80 shadow-inner'
      } ${className}`}
    >
      {/* Sliding Circle Knob */}
      <span
        className={`pointer-events-none inline-block h-5 w-5 rounded-full transform transition-transform duration-300 ease-in-out shadow-sm ${
          isDark
            ? 'translate-x-7 bg-white'
            : 'translate-x-1 bg-white'
        }`}
      />
    </button>
  );
};
