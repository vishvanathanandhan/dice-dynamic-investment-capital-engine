/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SchemeContext: Real-time global mutual fund state linked across all views & calculations
 * Now features live AMFI synchronization and automated quantitative calculation updates
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { MutualFundScheme } from '../types';
import { MUTUAL_FUND_SCHEMES } from '../data/schemes';
import { getFullFundData } from '../utils/amfiPipeline';

interface SchemeContextType {
  schemes: MutualFundScheme[];
  uploadedCount: number;
  addUploadedSchemes: (newSchemes: MutualFundScheme[], replaceExisting?: boolean) => void;
  resetToDefaults: () => void;
  deleteScheme: (id: string) => void;
  getSchemeById: (id: string) => MutualFundScheme | undefined;
  
  // Live AMFI Pipeline Integration
  isSyncingAmfi: boolean;
  lastSyncTime: string | null;
  amfiStatus: 'connected' | 'syncing' | 'idle' | 'error';
  syncSchemeWithLiveAmfi: (schemeCodeOrId: string) => Promise<boolean>;
  syncAllWithLiveAmfi: () => Promise<{ updated: number; failed: number }>;
  importAmfiScheme: (schemeCode: number | string) => Promise<MutualFundScheme | null>;

  // Categorical filtered sets linked in real-time
  wealthGrowFunds: MutualFundScheme[];
  taxSaverFunds: MutualFundScheme[];
  regularIncomeFunds: MutualFundScheme[];
  equitySchemes: MutualFundScheme[];
  debtSchemes: MutualFundScheme[];
  hybridSchemes: MutualFundScheme[];
  commoditySchemes: MutualFundScheme[];
}

const SchemeContext = createContext<SchemeContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'dice_custom_schemes_v1';
const LAST_SYNC_KEY = 'dice_last_amfi_sync';

export const SchemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [schemes, setSchemes] = useState<MutualFundScheme[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read saved schemes from localStorage', e);
    }
    return MUTUAL_FUND_SCHEMES;
  });

  const [isSyncingAmfi, setIsSyncingAmfi] = useState<boolean>(false);
  const [amfiStatus, setAmfiStatus] = useState<'connected' | 'syncing' | 'idle' | 'error'>('connected');
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem(LAST_SYNC_KEY) || null;
  });

  // Persist customized schemes
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(schemes));
    } catch (e) {
      console.warn('Could not save schemes to localStorage', e);
    }
  }, [schemes]);

  const addUploadedSchemes = (newSchemes: MutualFundScheme[], replaceExisting = false) => {
    if (replaceExisting) {
      setSchemes(newSchemes);
    } else {
      // Append unique by name or ID
      setSchemes((prev) => {
        const existingNames = new Set(prev.map((s) => s.name.toLowerCase()));
        const uniqueNew = newSchemes.filter((s) => !existingNames.has(s.name.toLowerCase()));
        return [...uniqueNew, ...prev];
      });
    }
  };

  const resetToDefaults = () => {
    setSchemes(MUTUAL_FUND_SCHEMES);
    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      localStorage.removeItem(LAST_SYNC_KEY);
    } catch (e) {
      // ignore
    }
  };

  const deleteScheme = (id: string) => {
    setSchemes((prev) => prev.filter((s) => s.id !== id));
  };

  const getSchemeById = (id: string) => {
    return schemes.find((s) => s.id === id);
  };

  /**
   * Sync a single scheme with live AMFI data & recompute quantitative metrics
   */
  const syncSchemeWithLiveAmfi = useCallback(
    async (schemeCodeOrId: string): Promise<boolean> => {
      const target = schemes.find((s) => s.id === schemeCodeOrId || s.code === schemeCodeOrId);
      if (!target) return false;

      const codeToFetch = target.code || target.id;
      if (!codeToFetch) return false;

      try {
        setIsSyncingAmfi(true);
        setAmfiStatus('syncing');

        const updated = await getFullFundData(codeToFetch, target);
        if (updated) {
          setSchemes((prev) => prev.map((s) => (s.id === target.id ? updated : s)));
          const now = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
          setLastSyncTime(now);
          localStorage.setItem(LAST_SYNC_KEY, now);
          setAmfiStatus('connected');
          return true;
        }
        setAmfiStatus('connected');
        return false;
      } catch (err) {
        console.error('Error syncing scheme with AMFI:', err);
        setAmfiStatus('error');
        return false;
      } finally {
        setIsSyncingAmfi(false);
      }
    },
    [schemes]
  );

  /**
   * Sync all schemes with live AMFI daily NAV feeds in sequence or batch
   */
  const syncAllWithLiveAmfi = useCallback(async (): Promise<{ updated: number; failed: number }> => {
    setIsSyncingAmfi(true);
    setAmfiStatus('syncing');
    let updatedCount = 0;
    let failedCount = 0;

    const newSchemes = [...schemes];

    for (let i = 0; i < newSchemes.length; i++) {
      const s = newSchemes[i];
      // Only sync if code exists and is numeric (AMFI scheme code)
      if (s.code && /^\d+$/.test(s.code)) {
        try {
          const fresh = await getFullFundData(s.code, s);
          if (fresh) {
            newSchemes[i] = fresh;
            updatedCount++;
          } else {
            failedCount++;
          }
        } catch (e) {
          failedCount++;
        }
      }
    }

    setSchemes(newSchemes);
    const now = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    setLastSyncTime(now);
    localStorage.setItem(LAST_SYNC_KEY, now);
    setAmfiStatus('connected');
    setIsSyncingAmfi(false);

    return { updated: updatedCount, failed: failedCount };
  }, [schemes]);

  /**
   * Import an arbitrary mutual fund from AMFI via code
   */
  const importAmfiScheme = useCallback(async (schemeCode: number | string): Promise<MutualFundScheme | null> => {
    try {
      setIsSyncingAmfi(true);
      const newFund = await getFullFundData(schemeCode);
      if (newFund) {
        setSchemes((prev) => {
          const filtered = prev.filter((p) => p.code !== String(schemeCode) && p.name !== newFund.name);
          return [newFund, ...filtered];
        });
        return newFund;
      }
      return null;
    } catch (err) {
      console.error('Error importing scheme from AMFI:', err);
      return null;
    } finally {
      setIsSyncingAmfi(false);
    }
  }, []);

  // Categorical subsets automatically kept in sync
  const wealthGrowFunds = schemes.filter(
    (s) =>
      s.broadCategory === 'Equity' &&
      !s.categoryCode.includes('ELSS') &&
      !s.category.toLowerCase().includes('elss')
  );

  const taxSaverFunds = schemes.filter(
    (s) =>
      s.categoryCode === 'EQ-ELSS' ||
      s.category.toLowerCase().includes('elss') ||
      s.category.toLowerCase().includes('tax')
  );

  const regularIncomeFunds = schemes.filter(
    (s) =>
      s.broadCategory === 'Debt' ||
      s.categoryCode === 'HY-CON' ||
      s.category.toLowerCase().includes('conservative') ||
      s.categoryCode === 'HY-BAF' ||
      s.category.toLowerCase().includes('balanced advantage')
  );

  const equitySchemes = schemes.filter((s) => s.broadCategory === 'Equity');
  const debtSchemes = schemes.filter((s) => s.broadCategory === 'Debt');
  const hybridSchemes = schemes.filter((s) => s.broadCategory === 'Hybrid');
  const commoditySchemes = schemes.filter((s) => s.broadCategory === 'Commodities');

  const uploadedCount = schemes.filter((s) => s.id.startsWith('uploaded_') || s.isUploaded).length;

  return (
    <SchemeContext.Provider
      value={{
        schemes,
        uploadedCount,
        addUploadedSchemes,
        resetToDefaults,
        deleteScheme,
        getSchemeById,
        isSyncingAmfi,
        lastSyncTime,
        amfiStatus,
        syncSchemeWithLiveAmfi,
        syncAllWithLiveAmfi,
        importAmfiScheme,
        wealthGrowFunds,
        taxSaverFunds,
        regularIncomeFunds,
        equitySchemes,
        debtSchemes,
        hybridSchemes,
        commoditySchemes,
      }}
    >
      {children}
    </SchemeContext.Provider>
  );
};

export const useSchemes = (): SchemeContextType => {
  const context = useContext(SchemeContext);
  if (!context) {
    throw new Error('useSchemes must be used within a SchemeProvider');
  }
  return context;
};
