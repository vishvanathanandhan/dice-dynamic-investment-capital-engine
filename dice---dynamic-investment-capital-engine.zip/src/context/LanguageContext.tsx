/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Language Context for Bilingual English & Tamil (தமிழ்) Support
 * Provides complete localized strings and dynamic translation helper
 */

import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'ta';

interface LanguageContextType {
  language: Language;
  isTamil: boolean;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string, fallback?: string) => string;
}

const LANGUAGE_STORAGE_KEY = 'dice_language_pref_v1';

export const DICTIONARY: Record<string, { en: string; ta: string }> = {
  // Brand & Header
  'brand.name': { en: 'DICE', ta: 'DICE' },
  'brand.tagline': { en: 'Capital Engine', ta: 'மூலதன இயந்திரம்' },
  'nav.explorer': { en: 'Funds Explorer', ta: 'நிதித் தேடல்' },
  'nav.profiler': { en: '20Q Profiler', ta: '20 வினாக்கள் சுயவிவரம்' },
  'nav.matches': { en: 'DICE Matches', ta: 'DICE பொருத்தங்கள்' },
  'nav.calculators': { en: 'Calculators', ta: 'கணக்கீடுகள்' },
  'nav.monitor': { en: 'Fund Monitor', ta: 'நிதி கண்காணிப்பு' },
  'nav.methodology': { en: 'Methodology', ta: 'முறைமை' },
  'nav.data_quality': { en: 'Data Quality (11k+)', ta: 'தரவு தரம் (11k+)' },
  'nav.disclaimer': { en: 'Website Disclaimer', ta: 'வலைத்தள மறுப்புரை' },
  'nav.upload_excel': { en: 'Upload Excel', ta: 'எக்செல் பதிவேற்றம்' },
  'nav.start_20q': { en: 'Start 20Q Matcher', ta: '20Q தொடங்கு' },
  'nav.retake_20q': { en: 'Retake 20Q', ta: 'மீண்டும் 20Q செய்' },

  // Hero Section
  'hero.badge': { en: 'Dynamic Investment Capital Engine · March 2026 Edition', ta: 'டைனமிக் முதலீட்டு மூலதன இயந்திரம் · மார்ச் 2026 பதிப்பு' },
  'hero.title': { en: 'Intelligent Mutual Fund Discovery & Behavioral Profiling', ta: 'நுண்ணறிவு பரஸ்பர நிதி தேடல் & முதலீட்டாளர் நடத்தை சுயவிவரம்' },
  'hero.subtitle': { en: 'Grounded in verified regulatory filings and quantitative multi-factor modeling across 11,000+ mutual fund schemes in India.', ta: 'இந்தியாவில் உள்ள 11,000+ பரஸ்பர நிதித் திட்டங்களில் ஒழுங்குமுறைத் தாக்கல்கள் மற்றும் பல காரணி மாதிரியமைப்பு அடிப்படையில் உருவாக்கப்பட்டது.' },
  'hero.search_placeholder': { en: 'Search across 11,000+ mutual fund schemes (e.g. Parag Parikh, SBI, HDFC)...', ta: '11,000+ பரஸ்பர நிதித் திட்டங்களில் தேடுங்கள் (எ.கா. பராக் பாரிக், SBI, HDFC)...' },
  'hero.search_count': { en: 'Searching active mutual fund schemes in real-time', ta: 'செயலில் உள்ள பரஸ்பர நிதித் திட்டங்களை நிகழ்நேரத்தில் தேடுகிறது' },
  'hero.start_profiler': { en: 'Start 20-Question Profiler', ta: '20 வினாக்கள் சுயவிவரத்தைத் தொடங்கு' },

  // Solution Cards
  'card.wealth.title': { en: 'Wealth Builder Funds', ta: 'செல்வத்தை பெருக்கும் நிதிகள்' },
  'card.wealth.desc': { en: 'Long-term equity funds engineered for superior capital compounding and inflation-beating returns.', ta: 'மூலதனப் பெருக்கம் மற்றும் பணவீக்கத்தை வெல்லும் நீண்ட கால பங்குச் சந்தை நிதிகள்.' },
  'card.wealth.tag': { en: 'Equity Focus · 5+ Yr Horizon', ta: 'பங்கு கவனம் · 5+ ஆண்டுகள்' },
  
  'card.tax.title': { en: 'Funds to Save Tax', ta: 'வரி சேமிக்கும் நிதிகள்' },
  'card.tax.desc': { en: 'ELSS tax-saver schemes offering Section 80C deductions with the lowest lock-in period among tax instruments.', ta: 'வரி சேமிப்பு கருவிகளில் மிகக் குறைந்த லாக்-இன் காலத்துடன் கூடிய ELSS திட்டங்கள்.' },
  'card.tax.tag': { en: '80C Deductions · 3-Yr Lock-in', ta: 'பிரிவு 80C · 3 ஆண்டுகள் லாக்-இன்' },

  'card.income.title': { en: 'Funds to Get Regular Income', ta: 'வழக்கமான வருமானம் தரும் நிதிகள்' },
  'card.income.desc': { en: 'High-grade liquid, short duration, and conservative debt funds designed for steady liquidity and capital preservation.', ta: 'நிலையான பணப்புழக்கம் மற்றும் மூலதனப் பாதுகாப்பிற்காக வடிவமைக்கப்பட்ட கடன் நிதிகள்.' },
  'card.income.tag': { en: 'Debt & Liquid · Capital Safety', ta: 'கடன் & லிக்விட் · மூலதன பாதுகாப்பு' },

  // Top Funds in Categories
  'categories.heading': { en: 'Top Funds in Categories', ta: 'முக்கிய பிரிவுகளின் சிறந்த நிதிகள்' },
  'categories.subheading': { en: 'Top 5 funds by asset size and verified regulatory track record from 11,000+ database.', ta: '11,000+ தரவுத்தளத்தில் இருந்து சொத்து அளவு மற்றும் சாதனை அடிப்படையில் சிறந்த 5 நிதிகள்.' },
  'cat.equity': { en: 'Equity', ta: 'பங்கு (Equity)' },
  'cat.debt': { en: 'Debt', ta: 'கடன் (Debt)' },
  'cat.hybrid': { en: 'Hybrid', ta: 'கலப்பு (Hybrid)' },
  'cat.commodities': { en: 'Commodities', ta: 'பொருட்கள் (Commodities)' },

  // Calculators
  'calc.heading': { en: 'Financial Calculators', ta: 'நிதி கணக்கீடுகள்' },
  'calc.subheading': { en: 'Simulate your wealth growth, goal requirements, and compounding with mathematical precision across all schemes.', ta: 'அனைத்து திட்டங்களிலும் கணித துல்லியத்துடன் உங்கள் செல்வ வளர்ச்சி மற்றும் இலக்கு தேவைகளை கணக்கிடுங்கள்.' },
  'calc.sip': { en: 'SIP Return Calculator', ta: 'SIP வருமான கணக்கீடு' },
  'calc.goal': { en: 'Goal Planning Calculator', ta: 'இலக்கு திட்டமிடல் கணக்கீடு' },
  'calc.investment': { en: 'Lump Sum Investment Calculator', ta: 'மொத்த முதலீட்டு கணக்கீடு' },
  'calc.monthly_amount': { en: 'Monthly Investment Amount (₹)', ta: 'மாதாந்திர முதலீட்டுத் தொகை (₹)' },
  'calc.lump_sum_amount': { en: 'Lump Sum Investment Amount (₹)', ta: 'மொத்த முதலீட்டுத் தொகை (₹)' },
  'calc.time_period': { en: 'Investment Period (Years)', ta: 'முதலீட்டுக் காலம் (ஆண்டுகள்)' },
  'calc.expected_rate': { en: 'Assumed Return Rate (% p.a.)', ta: 'எதிர்பார்க்கப்படும் வருமான விகிதம் (% p.a.)' },
  'calc.annual_step_up': { en: 'Annual Step-Up (% per year)', ta: 'ஆண்டுதோறும் கூடுதல் முதலீடு (% per year)' },
  'calc.target_goal': { en: 'Target Goal Amount (₹)', ta: 'இலக்குத் தொகை (₹)' },
  'calc.required_sip': { en: 'Required Monthly SIP', ta: 'தேவையான மாதாந்திர SIP' },
  'calc.worth_title': { en: 'Worth of Investment', ta: 'முதலீட்டின் மதிப்பு' },
  'calc.total_invested': { en: 'Total Invested:', ta: 'மொத்த முதலீடு:' },
  'calc.estimated_gain': { en: 'Estimated Gain:', ta: 'மதிப்பிடப்பட்ட லாபம்:' },
  'calc.future_value': { en: 'Total Future Value:', ta: 'எதிர்கால மொத்த மதிப்பு:' },
  'calc.disclaimer_title': { en: 'Calculator Disclaimer', ta: 'கணக்கீட்டு மறுப்புரை' },
  'calc.disclaimer_text': { 
    en: 'Financial calculators use hypothetical assumptions and mathematical models for educational demonstrations. Their outputs are illustrative only and do not represent guaranteed returns, actual investment outcomes or a promise of achieving any financial goal.',
    ta: 'நிதி கணக்கீடுகள் கல்வி விளக்கத்திற்காக அனுமானங்கள் மற்றும் கணித மாதிரிகளைப் பயன்படுத்துகின்றன. அவற்றின் முடிவுகள் விளக்கத்திற்கு மட்டுமே, உறுதியான வருமானம் அல்லது முதலீட்டு முடிவுகளுக்கு உத்தரவாதம் அளிக்காது.'
  },

  // Fund Monitor & Heat Map
  'monitor.heading': { en: 'Fund Monitor & Category Heat Map', ta: 'நிதி கண்காணிப்பு & பிரிவு வெப்ப வரைபடம்' },
  'monitor.subheading': { en: 'Real-time category momentum across multi-year intervals and top performing mutual funds.', ta: 'பல்வேறு கால இடைவெளிகளில் நிகழ்நேர வகை செயல்திறன் மற்றும் சிறந்த பரஸ்பர நிதிகள்.' },
  'monitor.leaderboard_title': { en: 'Top 10 Schemes Leaderboard', ta: 'சிறந்த 10 நிதி திட்டங்கள் தரவரிசை' },
  'monitor.fund_count': { en: 'Schemes', ta: 'திட்டங்கள்' },
  'monitor.refresh': { en: 'Refresh Live Rates', ta: 'நிகழ்நேர விகிதங்களைப் புதுப்பி' },

  // Tools Grid
  'tools.heading': { en: 'Mutual Fund Research & Diagnostics', ta: 'பரஸ்பர நிதி ஆராய்ச்சி மற்றும் பகுப்பாய்வு கருவிகள்' },
  'tools.subheading': { en: 'Grounded analytical tools to inspect, compare, evaluate and diagnose fund portfolios.', ta: 'நிதி போர்ட்ஃபோலியோக்களை ஆராய, ஒப்பிட மற்றும் மதிப்பீடு செய்வதற்கான பகுப்பாய்வுக் கருவிகள்.' },
  'tools.compare_title': { en: 'Multi-Fund Compare', ta: 'பல நிதி ஒப்பீடு' },
  'tools.compare_desc': { en: 'Side-by-side metric diagnostics across up to 4 mutual fund schemes.', ta: '4 பரஸ்பர நிதி திட்டங்கள் வரை அருகருகே வைத்து அளவீட்டு ஒப்பீடு.' },
  'tools.p2p_title': { en: 'Point-to-Point Returns', ta: 'புள்ளி-க்கு-புள்ளி வருமானம்' },
  'tools.p2p_desc': { en: 'Simulate retrospective lump-sum compounding across historical periods.', ta: 'கடந்த கால இடைவெளிகளில் மொத்த முதலீட்டு கூட்டு வளர்ச்சியை உருவகப்படுத்துங்கள்.' },
  'tools.watchlist_title': { en: 'My Watchlist', ta: 'எனது கண்காணிப்பு பட்டியல்' },
  'tools.watchlist_desc': { en: 'Track favorite schemes with live NAV, 1-year returns, and instant DICE test.', ta: 'நிகழ்நேர NAV மற்றும் 1 ஆண்டு வருமானத்துடன் விருப்பமான திட்டங்களை கண்காணிக்கவும்.' },
  'tools.data_quality_title': { en: 'Data Quality & Audit Dashboard', ta: 'தரவு தரம் & தணிக்கை கட்டுப்பாட்டு அறை' },
  'tools.data_quality_desc': { en: 'Inspect pipeline completeness, AMFI sync health, and field audit statistics.', ta: 'தரவு முழுமை, AMFI ஒத்திசைவு நிலை மற்றும் கள தணிக்கை புள்ளிவிவரங்களை ஆய்வு செய்யுங்கள்.' },
  'tools.20q_title': { en: 'DICE 20Q Risk Assessment', ta: 'DICE 20Q அபாய மதிப்பீடு' },
  'tools.20q_desc': { en: 'Diagnose your financial behavioral characters, loss aversion, and holdings suitability', ta: 'உங்கள் நிதி நடத்தை பண்புகள், இழப்பு பயம் மற்றும் இருப்பு பொருத்தத்தை கண்டறியவும்' },
  'tools.screener_title': { en: 'Wealth Builder Screener', ta: 'செல்வத்தை பெருக்கும் வடிகட்டி' },
  'tools.screener_desc': { en: 'Deep filter schemes across Equity, Debt, Hybrid, and Commodities with instant CSV export', ta: 'பங்கு, கடன், கலப்பு மற்றும் பொருட்களில் உடனடி CSV ஏற்றுமதியுடன் விரிவான வடிகட்டுதல்' },
  'tools.badge_diagnostic': { en: 'Diagnostic', ta: 'பகுப்பாய்வு' },
  'tools.badge_11k_universe': { en: '11,000+ Universe', ta: '11,000+ திட்டங்கள்' },
  'tools.badge_custom_import': { en: 'Custom Import', ta: 'தனிப்பயன் இறக்குமதி' },
  'tools.badge_11k': { en: '11k+ Schemes', ta: '11k+ திட்டங்கள்' },
  'tools.badge_compounding': { en: 'Compounding', ta: 'கூட்டு வளர்ச்சி' },
  'tools.badge_live_tracker': { en: 'Live Tracker', ta: 'நேரலை கண்காணிப்பு' },
  'tools.suite_subtitle': { en: 'Interactive Tools Suite', ta: 'ஊடாடும் பகுப்பாய்வு கருவிகள்' },
  'tools.count_label': { en: '9 Dedicated Analytical Tools', ta: '9 அர்ப்பணிக்கப்பட்ட பகுப்பாய்வுக் கருவிகள்' },
  'tools.import_desc': { en: 'Upload custom scheme data via Excel or CSV with instant app-wide linking and calculations', ta: 'முழு பயன்பாட்டு இணைப்புடன் Excel அல்லது CSV மூலம் தனிப்பயன் திட்ட தரவைப் பதிவேற்றவும்' },
  'tools.monitor_desc': { en: 'Live category performance matrix and top performing schemes leaderboard across India', ta: 'இந்தியா முழுவதுமுள்ள நேரலை வகை செயல்திறன் மற்றும் சிறந்த திட்டங்களின் தரவரிசை' },
  'tools.calc_desc': { en: 'Interactive SIP accumulation, lump sum compounding, and goal target planning calculators', ta: 'ஊடாடும் SIP சேமிப்பு, மொத்த முதலீட்டு கூட்டு வளர்ச்சி மற்றும் இலக்கு திட்டமிடல் கணக்கீடுகள்' },

  // Questionnaire & DICE Engine
  'quest.title': { en: 'Investor Suitability & Behavioral Diagnostic', ta: 'முதலீட்டாளர் பொருத்தம் & நடத்தை பகுப்பாய்வு' },
  'quest.subtitle': { en: 'Evaluates emotional biases and financial holdings to recommend up to 3 verified schemes.', ta: '3 சரிபார்க்கப்பட்ட திட்டங்களை பரிந்துரைக்க உணர்ச்சி சார்புகள் மற்றும் நிதி இருப்புகளை மதிப்பிடுகிறது.' },
  'quest.name_label': { en: 'Temporary Entry Name', ta: 'முதலீட்டாளர் பெயர்' },
  'quest.prev_btn': { en: 'Previous Question', ta: 'முந்தைய கேள்வி' },
  'quest.next_btn': { en: 'Next Question', ta: 'அடுத்த கேள்வி' },
  'quest.submit_btn': { en: 'Complete & Match Funds', ta: 'முடித்து பொருத்தமான நிதிகளை கண்டறியவும்' },
  'quest.why_dice': { en: 'Why DICE evaluates this: ', ta: 'DICE இதை ஏன் மதிப்பிடுகிறது: ' },
  'quest.ai_guidance': { en: 'AI Reason & DICE Engine Guidance', ta: 'AI காரணம் மற்றும் DICE வழிகாட்டுதல்' },

  // Wealth Builder Funds Table & Filters
  'wealth.title': { en: 'Wealth Builder Funds', ta: 'செல்வத்தை பெருக்கும் நிதிகள்' },
  'wealth.schemes': { en: 'Schemes', ta: 'திட்டங்கள்' },
  'wealth.desc': { en: 'Browse, filter, and inspect mutual fund schemes across all regulatory categories and asset classes.', ta: 'அனைத்து ஒழுங்குமுறை பிரிவுகள் மற்றும் சொத்து வகைகளில் உள்ள பரஸ்பர நிதி திட்டங்களை ஆய்வு செய்யுங்கள்.' },
  'wealth.import_excel': { en: 'Import Scheme Excel', ta: 'எக்செல் பதிவேற்றம்' },
  'wealth.export_csv': { en: 'Export Page CSV', ta: 'CSV பதிவிறக்கம்' },
  'wealth.all_funds': { en: 'All Funds (11k+)', ta: 'அனைத்து நிதிகள் (11k+)' },
  'wealth.wealth_growth': { en: 'Wealth Growth (Equity)', ta: 'செல்வ வளர்ச்சி (பங்கு)' },
  'wealth.tax_saver': { en: 'Tax Saver (ELSS 80C)', ta: 'வரி சேமிப்பு (ELSS 80C)' },
  'wealth.regular_income': { en: 'Regular Income (Debt)', ta: 'நிலையான வருமானம் (கடன்)' },
  'wealth.hybrid_balanced': { en: 'Hybrid & Balanced', ta: 'கலப்பு & சமநிலை' },
  'wealth.commodities': { en: 'Commodities (Gold/Silver)', ta: 'பொருட்கள் (தங்கம்/வெள்ளி)' },
  'wealth.tab_snapshot': { en: 'Snapshot', ta: 'சுருக்கம்' },
  'wealth.tab_returns': { en: 'Returns', ta: 'வருமானங்கள்' },
  'wealth.tab_portfolio': { en: 'Portfolio', ta: 'போர்ட்ஃபோலியோ' },
  'wealth.tab_risk': { en: 'Risk', ta: 'அபாயம்' },
  'wealth.tab_nav': { en: 'NAV Details', ta: 'NAV விவரங்கள்' },
  'wealth.tab_fees': { en: 'Fees & Details', ta: 'கட்டணங்கள் & விவரங்கள்' },
  'wealth.th_funds': { en: 'Funds', ta: 'திட்டங்கள்' },
  'wealth.th_1y_ret': { en: '1 Yr Ret (%)', ta: '1 ஆண்டு வருமானம் (%)' },
  'wealth.th_riskometer': { en: 'Riskometer', ta: 'அபாயமானி' },
  'wealth.th_category': { en: 'Category', ta: 'வகை' },
  'wealth.th_mandate': { en: 'Mandate / Objective', ta: 'நோக்கம் / கட்டளை' },
  'wealth.th_ter': { en: 'TER (%)', ta: 'செலவு விகிதம் (%)' },
  'wealth.th_plan': { en: 'Plan', ta: 'திட்டம்' },
  'wealth.th_aum': { en: 'Net Assets (Cr)', ta: 'நிகர சொத்துக்கள் (ரூ. கோடி)' },
  'wealth.th_action': { en: 'Action', ta: 'செயல்' },

  // Footer & Notices
  'footer.statutory': { 
    en: 'Statutory Notice: Mutual fund investments are subject to market risks, read all scheme related documents carefully. DICE is an independent academic and educational prototype.',
    ta: 'சட்டரீதியான அறிவிப்பு: பரஸ்பர நிதி முதலீடுகள் சந்தை அபாயங்களுக்கு உட்பட்டவை, அனைத்து திட்டம் தொடர்பான ஆவணங்களையும் கவனமாக படிக்கவும். DICE ஒரு சுயாதீன கல்வி மற்றும் ஆராய்ச்சி முன்மாதிரி ஆகும்.'
  },
  'footer.project': { en: 'DICE v1.0 · Engine Prototype', ta: 'DICE v1.0 · இயந்திர முன்மாதிரி' },
  'footer.disclaimer_title': { en: 'DICE Educational Platform Disclaimer', ta: 'DICE கல்வி தள மறுப்புரை' },
  'footer.read_disclaimer': { en: 'Read Full 12-Section Disclaimer Page', ta: 'முழு 12-பிரிவு மறுப்புரையை வாசிக்கவும்' },
  'common.view_details': { en: 'View Details', ta: 'விவரங்களை காண்க' },
  'common.close': { en: 'Close', ta: 'மூடு' },
  'common.back': { en: 'Back', ta: 'பின்செல்' },
  'common.loading': { en: 'Loading...', ta: 'ஏற்றுகிறது...' },
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY);
      if (saved === 'ta' || saved === 'en') return saved;
    } catch {
      // ignore
    }
    return 'en';
  });

  const isTamil = language === 'ta';

  useEffect(() => {
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
    } catch {
      // ignore
    }
    // Update html lang attribute
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const toggleLanguage = () => {
    setLanguageState((prev) => (prev === 'en' ? 'ta' : 'en'));
  };

  const t = (key: string, fallback?: string): string => {
    const entry = DICTIONARY[key];
    if (entry) {
      return language === 'ta' ? entry.ta : entry.en;
    }
    return fallback || key;
  };

  return (
    <LanguageContext.Provider value={{ language, isTamil, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

/**
 * E/த Language Toggle Button (Switch between English E and Tamil த)
 * Clean, compact toggle button placed in Header top-right
 */
export const LanguageToggleButton: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { language, toggleLanguage } = useLanguage();
  const isTamil = language === 'ta';

  return (
    <button
      type="button"
      onClick={toggleLanguage}
      aria-label={isTamil ? 'Switch to English' : 'தமிழுக்கு மாறவும் (Switch to Tamil)'}
      title={isTamil ? 'English மொழிக்கு மாறவும்' : 'Switch to தமிழ் (Tamil)'}
      className={`inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all duration-200 cursor-pointer shadow-2xs select-none ${
        isTamil
          ? 'bg-amber-600 border-amber-600 text-white hover:bg-amber-700'
          : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-100 dark:hover:bg-slate-800'
      } ${className}`}
    >
      <span className={!isTamil ? 'text-amber-600 dark:text-amber-400 font-extrabold' : 'opacity-70'}>
        E
      </span>
      <span className="opacity-40">/</span>
      <span className={isTamil ? 'text-white font-extrabold' : 'opacity-70 font-semibold'}>
        த
      </span>
    </button>
  );
};

