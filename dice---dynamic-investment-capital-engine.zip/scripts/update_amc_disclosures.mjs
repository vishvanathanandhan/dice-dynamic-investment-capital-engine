/**
 * Automated script to verify and refresh public/funds_master.json
 * Invoked by GitHub Actions on the 11th of every month.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const masterPath = path.resolve(__dirname, '../public/funds_master.json');

console.log('Reading master JSON from:', masterPath);
try {
  const content = fs.readFileSync(masterPath, 'utf-8');
  const db = JSON.parse(content);
  const schemeCount = Object.keys(db).length;
  console.log(`Successfully verified ${schemeCount} schemes in funds_master.json`);
} catch (err) {
  console.error('Error verifying funds_master.json:', err);
}
